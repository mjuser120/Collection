﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ID_GENERATOR
{
    public partial class BAIW : Form
    {
        public BAIW()
        {
            InitializeComponent();
        }

        private void BTN_Generate_Click(object sender, EventArgs e)
        {
            String StringFullname = TXTB_FullName.Text.ToUpper();
            String StringPosition = TXTB_Position.Text.ToUpper();
            String StringID = TXTB_ID.Text.ToUpper();
            String StringDateIssued = TXTB_DateIssued.Text.ToUpper();
            String StringExpirationDate = TXTB_ExpirationDate.Text.ToUpper();
            String StringIDNew = "ID NO: " + StringID;
            LBL_Fullname.Text = StringFullname;
            LBL_Position.Text = StringPosition;
            LBL_ID.Text = StringIDNew;
            LBL_DateIssued.Text = StringDateIssued;
            LBL_ExpirationDate.Text = StringExpirationDate;
        }

        private void TXTB_FullName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Position.Focus();
            }
        }

        private void TXTB_Position_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ID.Focus();
            }
        }

        private void TXTB_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_DateIssued.Focus();
            }
        }

        private void TXTB_DateIssued_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ExpirationDate.Focus();
            }
        }

        private void TXTB_ExpirationDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_Generate.PerformClick();
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            string StringFileName = TXTB_FullName.Text.ToUpper();
            int width = 644;
            int height = 507;
            Bitmap bitMap = new Bitmap(width, height);
            bitMap.SetResolution(150, 150);
            Rectangle rec = new Rectangle(0, 0, width, height);
            PNL_IDpreview.DrawToBitmap(bitMap, rec);
            bitMap.Save(StringPathSave + "BAI WORKERS\\" + StringFileName + ".png", ImageFormat.Png);
            MessageBox.Show("ID GENERATED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            System.Diagnostics.Process.Start(StringPathSave + "BAI WORKERS\\");
            LBL_Fullname.Text = "FULL NAME";
            LBL_Position.Text = "POSITION";
            LBL_ID.Text = "0000-00";
            LBL_DateIssued.Text = "DATE";
            LBL_ExpirationDate.Text = "DATE";
            TXTB_FullName.Text = "";
            TXTB_Position.Text = "";
            TXTB_ID.Text = "";
            TXTB_DateIssued.Text = "";
            TXTB_ExpirationDate.Text = "";
        }

        private void BAIW_Load(object sender, EventArgs e)
        {

        }
    }
}
