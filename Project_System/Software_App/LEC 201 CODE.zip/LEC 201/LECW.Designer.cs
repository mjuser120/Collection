﻿namespace ID_GENERATOR
{
    partial class LECW
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LECW));
            this.PNL_IDpreview = new System.Windows.Forms.Panel();
            this.LBL_Fullname = new System.Windows.Forms.Label();
            this.PICB_QR = new System.Windows.Forms.PictureBox();
            this.TXTB_LECWName = new System.Windows.Forms.TextBox();
            this.TXTB_LECWQr = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.BTN_LECWOk = new System.Windows.Forms.Button();
            this.BTN_LECWSave = new System.Windows.Forms.Button();
            this.PNL_IDpreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_QR)).BeginInit();
            this.SuspendLayout();
            // 
            // PNL_IDpreview
            // 
            this.PNL_IDpreview.BackgroundImage = global::LEC_201.Properties.Resources.LECWORKERS;
            this.PNL_IDpreview.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PNL_IDpreview.Controls.Add(this.LBL_Fullname);
            this.PNL_IDpreview.Controls.Add(this.PICB_QR);
            this.PNL_IDpreview.Location = new System.Drawing.Point(5, 132);
            this.PNL_IDpreview.Name = "PNL_IDpreview";
            this.PNL_IDpreview.Size = new System.Drawing.Size(300, 420);
            this.PNL_IDpreview.TabIndex = 0;
            // 
            // LBL_Fullname
            // 
            this.LBL_Fullname.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Fullname.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Fullname.Location = new System.Drawing.Point(20, 357);
            this.LBL_Fullname.Name = "LBL_Fullname";
            this.LBL_Fullname.Size = new System.Drawing.Size(260, 41);
            this.LBL_Fullname.TabIndex = 1;
            this.LBL_Fullname.Text = "FULL NAME";
            this.LBL_Fullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PICB_QR
            // 
            this.PICB_QR.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.PICB_QR.Location = new System.Drawing.Point(86, 135);
            this.PICB_QR.Name = "PICB_QR";
            this.PICB_QR.Size = new System.Drawing.Size(130, 130);
            this.PICB_QR.TabIndex = 0;
            this.PICB_QR.TabStop = false;
            // 
            // TXTB_LECWName
            // 
            this.TXTB_LECWName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_LECWName.Location = new System.Drawing.Point(155, 27);
            this.TXTB_LECWName.Name = "TXTB_LECWName";
            this.TXTB_LECWName.Size = new System.Drawing.Size(150, 25);
            this.TXTB_LECWName.TabIndex = 1;
            this.TXTB_LECWName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_LECWName_KeyPress);
            // 
            // TXTB_LECWQr
            // 
            this.TXTB_LECWQr.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_LECWQr.Location = new System.Drawing.Point(155, 58);
            this.TXTB_LECWQr.Name = "TXTB_LECWQr";
            this.TXTB_LECWQr.Size = new System.Drawing.Size(150, 25);
            this.TXTB_LECWQr.TabIndex = 2;
            this.TXTB_LECWQr.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_LECWQr_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(21, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "ENTER FULL NAME:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(11, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(138, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "ENTER QR CONTEXT:";
            // 
            // BTN_LECWOk
            // 
            this.BTN_LECWOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_LECWOk.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LECWOk.Location = new System.Drawing.Point(155, 89);
            this.BTN_LECWOk.Name = "BTN_LECWOk";
            this.BTN_LECWOk.Size = new System.Drawing.Size(70, 23);
            this.BTN_LECWOk.TabIndex = 5;
            this.BTN_LECWOk.Text = "GENERATE";
            this.BTN_LECWOk.UseVisualStyleBackColor = true;
            this.BTN_LECWOk.Click += new System.EventHandler(this.BTN_LECWOk_Click);
            // 
            // BTN_LECWSave
            // 
            this.BTN_LECWSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_LECWSave.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LECWSave.Location = new System.Drawing.Point(235, 89);
            this.BTN_LECWSave.Name = "BTN_LECWSave";
            this.BTN_LECWSave.Size = new System.Drawing.Size(70, 23);
            this.BTN_LECWSave.TabIndex = 6;
            this.BTN_LECWSave.Text = "SAVE";
            this.BTN_LECWSave.UseVisualStyleBackColor = true;
            this.BTN_LECWSave.Click += new System.EventHandler(this.BTN_LECWSave_Click);
            // 
            // LECW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(311, 558);
            this.Controls.Add(this.BTN_LECWSave);
            this.Controls.Add(this.BTN_LECWOk);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTB_LECWQr);
            this.Controls.Add(this.TXTB_LECWName);
            this.Controls.Add(this.PNL_IDpreview);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "LECW";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ID GENERATOR | LEC Workers";
            this.Load += new System.EventHandler(this.LECW_Load);
            this.PNL_IDpreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PICB_QR)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_IDpreview;
        private System.Windows.Forms.PictureBox PICB_QR;
        private System.Windows.Forms.TextBox TXTB_LECWName;
        private System.Windows.Forms.TextBox TXTB_LECWQr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTN_LECWOk;
        private System.Windows.Forms.Button BTN_LECWSave;
        private System.Windows.Forms.Label LBL_Fullname;
    }
}