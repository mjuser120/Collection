﻿namespace ID_GENERATOR
{
    partial class LECO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LECO));
            this.COMBOB_Company = new System.Windows.Forms.ComboBox();
            this.TXTB_Fullname = new System.Windows.Forms.TextBox();
            this.TXTB_Position = new System.Windows.Forms.TextBox();
            this.TXTB_ID = new System.Windows.Forms.TextBox();
            this.TXTB_Birthday = new System.Windows.Forms.TextBox();
            this.TXTB_Address = new System.Windows.Forms.RichTextBox();
            this.TXTB_PicturePath = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.BTN_Browse = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.BTN_Generate = new System.Windows.Forms.Button();
            this.TXTB_ExpirationDate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.PNL_IDpreview = new System.Windows.Forms.Panel();
            this.LBL_ExpirationDate = new System.Windows.Forms.Label();
            this.LBL_CompanyBack = new System.Windows.Forms.Label();
            this.LBL_CompanyInitials = new System.Windows.Forms.Label();
            this.LBL_Signatory = new System.Windows.Forms.Label();
            this.LBL_Birthday = new System.Windows.Forms.Label();
            this.LBL_ID = new System.Windows.Forms.Label();
            this.LBL_Position = new System.Windows.Forms.Label();
            this.LBL_Fullname = new System.Windows.Forms.Label();
            this.PICB_Photo = new System.Windows.Forms.PictureBox();
            this.PICB_Signature = new System.Windows.Forms.PictureBox();
            this.LBL_Address = new System.Windows.Forms.Label();
            this.TEXTB_SearchEmployeeNumber = new System.Windows.Forms.TextBox();
            this.BTN_EmployeeNumber = new System.Windows.Forms.Button();
            this.lecDataSet = new LEC_201.LecDataSet();
            this.employeeListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeListTableAdapter = new LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter();
            this.tableAdapterManager = new LEC_201.LecDataSetTableAdapters.TableAdapterManager();
            this.employeeListBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNL_IDpreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Photo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Signature)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).BeginInit();
            this.employeeListBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // COMBOB_Company
            // 
            this.COMBOB_Company.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.COMBOB_Company.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_Company.FormattingEnabled = true;
            this.COMBOB_Company.Items.AddRange(new object[] {
            "NA - Nilo Abanggan",
            "JE - Joel Espares",
            "JS - Jover Salaquin",
            "MP -Mariano Panganiban",
            "LEC - LEC Steel"});
            this.COMBOB_Company.Location = new System.Drawing.Point(115, 130);
            this.COMBOB_Company.Name = "COMBOB_Company";
            this.COMBOB_Company.Size = new System.Drawing.Size(150, 25);
            this.COMBOB_Company.TabIndex = 1;
            this.COMBOB_Company.Visible = false;
            // 
            // TXTB_Fullname
            // 
            this.TXTB_Fullname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Fullname.Location = new System.Drawing.Point(115, 161);
            this.TXTB_Fullname.Name = "TXTB_Fullname";
            this.TXTB_Fullname.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Fullname.TabIndex = 2;
            this.TXTB_Fullname.Visible = false;
            // 
            // TXTB_Position
            // 
            this.TXTB_Position.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Position.Location = new System.Drawing.Point(115, 192);
            this.TXTB_Position.Name = "TXTB_Position";
            this.TXTB_Position.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Position.TabIndex = 3;
            this.TXTB_Position.Visible = false;
            // 
            // TXTB_ID
            // 
            this.TXTB_ID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ID.Location = new System.Drawing.Point(115, 223);
            this.TXTB_ID.Name = "TXTB_ID";
            this.TXTB_ID.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ID.TabIndex = 4;
            this.TXTB_ID.Visible = false;
            // 
            // TXTB_Birthday
            // 
            this.TXTB_Birthday.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Birthday.Location = new System.Drawing.Point(115, 254);
            this.TXTB_Birthday.Name = "TXTB_Birthday";
            this.TXTB_Birthday.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Birthday.TabIndex = 5;
            this.TXTB_Birthday.Visible = false;
            // 
            // TXTB_Address
            // 
            this.TXTB_Address.Location = new System.Drawing.Point(115, 285);
            this.TXTB_Address.Name = "TXTB_Address";
            this.TXTB_Address.Size = new System.Drawing.Size(150, 114);
            this.TXTB_Address.TabIndex = 6;
            this.TXTB_Address.Text = "";
            this.TXTB_Address.Visible = false;
            // 
            // TXTB_PicturePath
            // 
            this.TXTB_PicturePath.Enabled = false;
            this.TXTB_PicturePath.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_PicturePath.Location = new System.Drawing.Point(115, 436);
            this.TXTB_PicturePath.Name = "TXTB_PicturePath";
            this.TXTB_PicturePath.Size = new System.Drawing.Size(150, 25);
            this.TXTB_PicturePath.TabIndex = 7;
            this.TXTB_PicturePath.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(33, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(76, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "COMPANY:";
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(29, 164);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 17);
            this.label2.TabIndex = 9;
            this.label2.Text = "FULLNAME:";
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(36, 195);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 17);
            this.label3.TabIndex = 10;
            this.label3.Text = "POSITION:";
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(59, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "ID NO:";
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(33, 257);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(76, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "BIRTHDAY:";
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(39, 285);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(70, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "ADDRESS:";
            this.label6.Visible = false;
            // 
            // BTN_Browse
            // 
            this.BTN_Browse.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Browse.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Browse.Location = new System.Drawing.Point(115, 467);
            this.BTN_Browse.Name = "BTN_Browse";
            this.BTN_Browse.Size = new System.Drawing.Size(150, 25);
            this.BTN_Browse.TabIndex = 14;
            this.BTN_Browse.Text = "BROWSE PICTURE";
            this.BTN_Browse.UseVisualStyleBackColor = true;
            this.BTN_Browse.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(8, 439);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "PICTURE PATH:";
            this.label7.Visible = false;
            // 
            // BTN_Generate
            // 
            this.BTN_Generate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Generate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Generate.Location = new System.Drawing.Point(115, 497);
            this.BTN_Generate.Name = "BTN_Generate";
            this.BTN_Generate.Size = new System.Drawing.Size(70, 25);
            this.BTN_Generate.TabIndex = 16;
            this.BTN_Generate.Text = "GENERATE";
            this.BTN_Generate.UseVisualStyleBackColor = true;
            this.BTN_Generate.Visible = false;
            // 
            // TXTB_ExpirationDate
            // 
            this.TXTB_ExpirationDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ExpirationDate.Location = new System.Drawing.Point(115, 405);
            this.TXTB_ExpirationDate.Name = "TXTB_ExpirationDate";
            this.TXTB_ExpirationDate.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ExpirationDate.TabIndex = 17;
            this.TXTB_ExpirationDate.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(21, 407);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(88, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "EXPIRATION:";
            this.label8.Visible = false;
            // 
            // BTN_Save
            // 
            this.BTN_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Save.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Save.Location = new System.Drawing.Point(11, 591);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(643, 50);
            this.BTN_Save.TabIndex = 19;
            this.BTN_Save.Text = "SAVE";
            this.BTN_Save.UseVisualStyleBackColor = true;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // PNL_IDpreview
            // 
            this.PNL_IDpreview.BackgroundImage = global::LEC_201.Properties.Resources.LECOFFICE;
            this.PNL_IDpreview.Controls.Add(this.LBL_ExpirationDate);
            this.PNL_IDpreview.Controls.Add(this.LBL_CompanyBack);
            this.PNL_IDpreview.Controls.Add(this.LBL_CompanyInitials);
            this.PNL_IDpreview.Controls.Add(this.LBL_Signatory);
            this.PNL_IDpreview.Controls.Add(this.LBL_Birthday);
            this.PNL_IDpreview.Controls.Add(this.LBL_ID);
            this.PNL_IDpreview.Controls.Add(this.LBL_Position);
            this.PNL_IDpreview.Controls.Add(this.LBL_Fullname);
            this.PNL_IDpreview.Controls.Add(this.PICB_Photo);
            this.PNL_IDpreview.Controls.Add(this.PICB_Signature);
            this.PNL_IDpreview.Controls.Add(this.LBL_Address);
            this.PNL_IDpreview.Location = new System.Drawing.Point(11, 79);
            this.PNL_IDpreview.Name = "PNL_IDpreview";
            this.PNL_IDpreview.Size = new System.Drawing.Size(643, 506);
            this.PNL_IDpreview.TabIndex = 0;
            // 
            // LBL_ExpirationDate
            // 
            this.LBL_ExpirationDate.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ExpirationDate.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ExpirationDate.ForeColor = System.Drawing.Color.Blue;
            this.LBL_ExpirationDate.Location = new System.Drawing.Point(432, 461);
            this.LBL_ExpirationDate.Name = "LBL_ExpirationDate";
            this.LBL_ExpirationDate.Size = new System.Drawing.Size(187, 26);
            this.LBL_ExpirationDate.TabIndex = 24;
            this.LBL_ExpirationDate.Text = "EXPIRATION DATE";
            this.LBL_ExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_CompanyBack
            // 
            this.LBL_CompanyBack.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.LBL_CompanyBack.Font = new System.Drawing.Font("Arial", 30F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_CompanyBack.ForeColor = System.Drawing.Color.White;
            this.LBL_CompanyBack.Location = new System.Drawing.Point(346, 20);
            this.LBL_CompanyBack.Name = "LBL_CompanyBack";
            this.LBL_CompanyBack.Size = new System.Drawing.Size(55, 467);
            this.LBL_CompanyBack.TabIndex = 17;
            this.LBL_CompanyBack.Text = "C O M P A N Y";
            this.LBL_CompanyBack.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_CompanyInitials
            // 
            this.LBL_CompanyInitials.BackColor = System.Drawing.Color.Transparent;
            this.LBL_CompanyInitials.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_CompanyInitials.ForeColor = System.Drawing.Color.White;
            this.LBL_CompanyInitials.Location = new System.Drawing.Point(18, 461);
            this.LBL_CompanyInitials.Name = "LBL_CompanyInitials";
            this.LBL_CompanyInitials.Size = new System.Drawing.Size(121, 26);
            this.LBL_CompanyInitials.TabIndex = 23;
            this.LBL_CompanyInitials.Text = "-";
            this.LBL_CompanyInitials.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Signatory
            // 
            this.LBL_Signatory.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Signatory.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Signatory.ForeColor = System.Drawing.Color.Black;
            this.LBL_Signatory.Location = new System.Drawing.Point(407, 292);
            this.LBL_Signatory.Name = "LBL_Signatory";
            this.LBL_Signatory.Size = new System.Drawing.Size(233, 26);
            this.LBL_Signatory.TabIndex = 22;
            this.LBL_Signatory.Text = "MARIANO PANGANIBAN";
            this.LBL_Signatory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Birthday
            // 
            this.LBL_Birthday.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Birthday.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Birthday.ForeColor = System.Drawing.Color.Black;
            this.LBL_Birthday.Location = new System.Drawing.Point(502, 111);
            this.LBL_Birthday.Name = "LBL_Birthday";
            this.LBL_Birthday.Size = new System.Drawing.Size(127, 26);
            this.LBL_Birthday.TabIndex = 19;
            this.LBL_Birthday.Text = "01-01-2023";
            this.LBL_Birthday.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LBL_ID
            // 
            this.LBL_ID.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ID.ForeColor = System.Drawing.Color.Black;
            this.LBL_ID.Location = new System.Drawing.Point(54, 299);
            this.LBL_ID.Name = "LBL_ID";
            this.LBL_ID.Size = new System.Drawing.Size(219, 26);
            this.LBL_ID.TabIndex = 18;
            this.LBL_ID.Text = "ID NO:";
            this.LBL_ID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Position
            // 
            this.LBL_Position.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Position.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Position.ForeColor = System.Drawing.Color.Black;
            this.LBL_Position.Location = new System.Drawing.Point(52, 243);
            this.LBL_Position.Name = "LBL_Position";
            this.LBL_Position.Size = new System.Drawing.Size(219, 26);
            this.LBL_Position.TabIndex = 17;
            this.LBL_Position.Text = "POSITION";
            this.LBL_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Fullname
            // 
            this.LBL_Fullname.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Fullname.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Fullname.ForeColor = System.Drawing.Color.Black;
            this.LBL_Fullname.Location = new System.Drawing.Point(15, 180);
            this.LBL_Fullname.Name = "LBL_Fullname";
            this.LBL_Fullname.Size = new System.Drawing.Size(288, 26);
            this.LBL_Fullname.TabIndex = 16;
            this.LBL_Fullname.Text = "FULL NAME";
            this.LBL_Fullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PICB_Photo
            // 
            this.PICB_Photo.BackColor = System.Drawing.Color.White;
            this.PICB_Photo.ErrorImage = global::LEC_201.Properties.Resources.LECDEFAULTPHOTO;
            this.PICB_Photo.Image = global::LEC_201.Properties.Resources.LECDEFAULTPHOTO;
            this.PICB_Photo.InitialImage = global::LEC_201.Properties.Resources.LECDEFAULTPHOTO;
            this.PICB_Photo.Location = new System.Drawing.Point(94, 20);
            this.PICB_Photo.Name = "PICB_Photo";
            this.PICB_Photo.Size = new System.Drawing.Size(130, 130);
            this.PICB_Photo.TabIndex = 0;
            this.PICB_Photo.TabStop = false;
            // 
            // PICB_Signature
            // 
            this.PICB_Signature.BackColor = System.Drawing.Color.Transparent;
            this.PICB_Signature.Location = new System.Drawing.Point(484, 214);
            this.PICB_Signature.Name = "PICB_Signature";
            this.PICB_Signature.Size = new System.Drawing.Size(80, 80);
            this.PICB_Signature.TabIndex = 21;
            this.PICB_Signature.TabStop = false;
            // 
            // LBL_Address
            // 
            this.LBL_Address.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Address.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Address.ForeColor = System.Drawing.Color.Black;
            this.LBL_Address.Location = new System.Drawing.Point(434, 169);
            this.LBL_Address.Name = "LBL_Address";
            this.LBL_Address.Size = new System.Drawing.Size(195, 58);
            this.LBL_Address.TabIndex = 20;
            this.LBL_Address.Text = "A. Bonifacio Ave. Cor. Ligaya St. Balintawak, Quezon City";
            // 
            // TEXTB_SearchEmployeeNumber
            // 
            this.TEXTB_SearchEmployeeNumber.Location = new System.Drawing.Point(11, 12);
            this.TEXTB_SearchEmployeeNumber.Name = "TEXTB_SearchEmployeeNumber";
            this.TEXTB_SearchEmployeeNumber.Size = new System.Drawing.Size(120, 20);
            this.TEXTB_SearchEmployeeNumber.TabIndex = 20;
            this.TEXTB_SearchEmployeeNumber.Click += new System.EventHandler(this.TEXTB_SearchEmployeeNumber_Click);
            this.TEXTB_SearchEmployeeNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXTB_SearchEmployeeNumber_KeyPress);
            // 
            // BTN_EmployeeNumber
            // 
            this.BTN_EmployeeNumber.Location = new System.Drawing.Point(11, 38);
            this.BTN_EmployeeNumber.Name = "BTN_EmployeeNumber";
            this.BTN_EmployeeNumber.Size = new System.Drawing.Size(120, 23);
            this.BTN_EmployeeNumber.TabIndex = 21;
            this.BTN_EmployeeNumber.Text = "SEARCH";
            this.BTN_EmployeeNumber.UseVisualStyleBackColor = true;
            this.BTN_EmployeeNumber.Click += new System.EventHandler(this.BTN_EmployeeNumber_Click);
            // 
            // lecDataSet
            // 
            this.lecDataSet.DataSetName = "LecDataSet";
            this.lecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeListBindingSource
            // 
            this.employeeListBindingSource.DataMember = "EmployeeList";
            this.employeeListBindingSource.DataSource = this.lecDataSet;
            // 
            // employeeListTableAdapter
            // 
            this.employeeListTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeeListTableAdapter = this.employeeListTableAdapter;
            this.tableAdapterManager.UpdateOrder = LEC_201.LecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeListBindingNavigator
            // 
            this.employeeListBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeListBindingNavigator.BindingSource = this.employeeListBindingSource;
            this.employeeListBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeListBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeListBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.employeeListBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeeListBindingNavigatorSaveItem});
            this.employeeListBindingNavigator.Location = new System.Drawing.Point(150, 12);
            this.employeeListBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeListBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeListBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeListBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeListBindingNavigator.Name = "employeeListBindingNavigator";
            this.employeeListBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeListBindingNavigator.Size = new System.Drawing.Size(278, 25);
            this.employeeListBindingNavigator.TabIndex = 22;
            this.employeeListBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // employeeListBindingNavigatorSaveItem
            // 
            this.employeeListBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeListBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeeListBindingNavigatorSaveItem.Image")));
            this.employeeListBindingNavigatorSaveItem.Name = "employeeListBindingNavigatorSaveItem";
            this.employeeListBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.employeeListBindingNavigatorSaveItem.Text = "Save Data";
            this.employeeListBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeeListBindingNavigatorSaveItem_Click);
            // 
            // employeeListDataGridView
            // 
            this.employeeListDataGridView.AutoGenerateColumns = false;
            this.employeeListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.employeeListDataGridView.DataSource = this.employeeListBindingSource;
            this.employeeListDataGridView.Enabled = false;
            this.employeeListDataGridView.Location = new System.Drawing.Point(150, 11);
            this.employeeListDataGridView.Name = "employeeListDataGridView";
            this.employeeListDataGridView.RowHeadersVisible = false;
            this.employeeListDataGridView.Size = new System.Drawing.Size(504, 62);
            this.employeeListDataGridView.TabIndex = 23;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.HeaderText = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn2.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn3.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MiddleName";
            this.dataGridViewTextBoxColumn4.HeaderText = "MiddleName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NickName";
            this.dataGridViewTextBoxColumn5.HeaderText = "NickName";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "BirthDate";
            this.dataGridViewTextBoxColumn6.HeaderText = "BirthDate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "BirthPlace";
            this.dataGridViewTextBoxColumn7.HeaderText = "BirthPlace";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn8.HeaderText = "Address";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ContactNumber";
            this.dataGridViewTextBoxColumn9.HeaderText = "ContactNumber";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CivilStatus";
            this.dataGridViewTextBoxColumn10.HeaderText = "CivilStatus";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Mother";
            this.dataGridViewTextBoxColumn11.HeaderText = "Mother";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Father";
            this.dataGridViewTextBoxColumn12.HeaderText = "Father";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Company";
            this.dataGridViewTextBoxColumn13.HeaderText = "Company";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn14.HeaderText = "Department";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "SubDepartment";
            this.dataGridViewTextBoxColumn15.HeaderText = "SubDepartment";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn16.HeaderText = "Position";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "DateHired";
            this.dataGridViewTextBoxColumn17.HeaderText = "DateHired";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.HeaderText = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "DateSeparated";
            this.dataGridViewTextBoxColumn19.HeaderText = "DateSeparated";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Salary";
            this.dataGridViewTextBoxColumn20.HeaderText = "Salary";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "SalaryType";
            this.dataGridViewTextBoxColumn21.HeaderText = "SalaryType";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "TIN";
            this.dataGridViewTextBoxColumn22.HeaderText = "TIN";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "SSS";
            this.dataGridViewTextBoxColumn23.HeaderText = "SSS";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Philhealth";
            this.dataGridViewTextBoxColumn24.HeaderText = "Philhealth";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Pagibig";
            this.dataGridViewTextBoxColumn25.HeaderText = "Pagibig";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // LECO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(666, 650);
            this.Controls.Add(this.PNL_IDpreview);
            this.Controls.Add(this.employeeListDataGridView);
            this.Controls.Add(this.employeeListBindingNavigator);
            this.Controls.Add(this.BTN_EmployeeNumber);
            this.Controls.Add(this.TEXTB_SearchEmployeeNumber);
            this.Controls.Add(this.BTN_Save);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.TXTB_ExpirationDate);
            this.Controls.Add(this.BTN_Generate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.BTN_Browse);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTB_PicturePath);
            this.Controls.Add(this.TXTB_Address);
            this.Controls.Add(this.TXTB_Birthday);
            this.Controls.Add(this.TXTB_ID);
            this.Controls.Add(this.TXTB_Position);
            this.Controls.Add(this.TXTB_Fullname);
            this.Controls.Add(this.COMBOB_Company);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "LECO";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ID GENERATOR | LEC - Office";
            this.Load += new System.EventHandler(this.LECO_Load);
            this.PNL_IDpreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Photo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Signature)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).EndInit();
            this.employeeListBindingNavigator.ResumeLayout(false);
            this.employeeListBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_IDpreview;
        private System.Windows.Forms.PictureBox PICB_Photo;
        private System.Windows.Forms.ComboBox COMBOB_Company;
        private System.Windows.Forms.TextBox TXTB_Fullname;
        private System.Windows.Forms.TextBox TXTB_Position;
        private System.Windows.Forms.TextBox TXTB_ID;
        private System.Windows.Forms.TextBox TXTB_Birthday;
        private System.Windows.Forms.RichTextBox TXTB_Address;
        private System.Windows.Forms.TextBox TXTB_PicturePath;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button BTN_Browse;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label LBL_Position;
        private System.Windows.Forms.Label LBL_Fullname;
        private System.Windows.Forms.Label LBL_Birthday;
        private System.Windows.Forms.Label LBL_ID;
        private System.Windows.Forms.Label LBL_Address;
        private System.Windows.Forms.PictureBox PICB_Signature;
        private System.Windows.Forms.Label LBL_CompanyInitials;
        private System.Windows.Forms.Label LBL_Signatory;
        private System.Windows.Forms.Label LBL_CompanyBack;
        private System.Windows.Forms.Button BTN_Generate;
        private System.Windows.Forms.TextBox TXTB_ExpirationDate;
        private System.Windows.Forms.Label LBL_ExpirationDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.TextBox TEXTB_SearchEmployeeNumber;
        private System.Windows.Forms.Button BTN_EmployeeNumber;
        private LEC_201.LecDataSet lecDataSet;
        private System.Windows.Forms.BindingSource employeeListBindingSource;
        private LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter employeeListTableAdapter;
        private LEC_201.LecDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeListBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton employeeListBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView employeeListDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
    }
}