﻿using Microsoft.Win32;
using QRCoder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace ID_GENERATOR
{
    public partial class LECW : Form
    {
        //private object plotPrinter;
        //private object saveFileDialog;

        public LECW()
        {
            InitializeComponent();
        }

        private void LECW_Load(object sender, EventArgs e)
        {

        }

        private void BTN_LECWOk_Click(object sender, EventArgs e)
        {
            string StringFullName = TXTB_LECWName.Text.ToUpper();
            string StringQr = TXTB_LECWQr.Text;
            LBL_Fullname.Text = StringFullName;
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(StringQr, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(150);
            PICB_QR.Image = qrCodeImage;
            PICB_QR.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void BTN_LECWSave_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            string StringFileName = TXTB_LECWQr.Text.ToUpper();
            int width = 300;
            int height = 420;
            Bitmap bitMap = new Bitmap(width, height);
            bitMap.SetResolution(120, 120);
            Rectangle rec = new Rectangle(0, 0, width, height);
            PNL_IDpreview.DrawToBitmap(bitMap, rec);
            bitMap.Save(StringPathSave + "LEC WORKERS\\" + StringFileName + ".png", ImageFormat.Png);
            MessageBox.Show("ID GENERATED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            System.Diagnostics.Process.Start(StringPathSave + "LEC WORKERS\\");
            LBL_Fullname.Text = "FULL NAME";
            TXTB_LECWName.Text = "";
            TXTB_LECWQr.Text = "";
            string StringQr = TXTB_LECWQr.Text;
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(StringQr, QRCodeGenerator.ECCLevel.Q);
            QRCode qrCode = new QRCode(qrCodeData);
            Bitmap qrCodeImage = qrCode.GetGraphic(150);
            PICB_QR.Image = qrCodeImage;
            PICB_QR.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        private void TXTB_LECWName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_LECWQr.Focus();
            }
        }

        private void TXTB_LECWQr_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_LECWOk.PerformClick();
            }
        }
    }
}
