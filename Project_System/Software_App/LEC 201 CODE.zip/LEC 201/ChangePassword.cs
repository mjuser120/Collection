﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LEC_201
{
    public partial class ChangePassword : Form
    {
        public ChangePassword()
        {
            InitializeComponent();
        }

        private void BTN_ChangePasswordCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTN_ChangePasswordOk_Click(object sender, EventArgs e)
        {
            string StringOldPassword = TXTB_OldPassword.Text;
            string StringNewPassword1 = TXTB_NewPassword1.Text;
            string StringNewPassword2 = TXTB_NewPassword2.Text;
            string StringPath = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            string StringOldPasswordReader = File.ReadAllText(StringPath + "p.c");
            if (StringOldPassword == StringOldPasswordReader)
            {
                if(StringNewPassword1 == StringNewPassword2)
                {
                    File.WriteAllText(StringPath + "p.c", StringNewPassword1);
                    MessageBox.Show("Password Changed! ", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Password do not match!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                MessageBox.Show("Invalid Password!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void ChangePassword_Load(object sender, EventArgs e)
        {
            TXTB_OldPassword.Text = "";
            TXTB_NewPassword1.Text = "";
            TXTB_NewPassword2.Text = "";
            TXTB_OldPassword.Focus();
        }

        private void TXTB_OldPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_NewPassword1.Focus();
            }
        }

        private void TXTB_NewPassword1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_NewPassword2.Focus();
            }
        }

        private void TXTB_NewPassword2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_ChangePasswordOk.PerformClick();
            }
        }
    }
}