﻿namespace ID_GENERATOR
{
    partial class BAIO
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAIO));
            this.PNL_IDpreview = new System.Windows.Forms.Panel();
            this.LBL_ExpirationDate = new System.Windows.Forms.Label();
            this.LBL_ContactNumber = new System.Windows.Forms.Label();
            this.LBL_ContactPerson = new System.Windows.Forms.Label();
            this.LBL_Address = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.LBL_ID = new System.Windows.Forms.Label();
            this.LBL_Nickname = new System.Windows.Forms.Label();
            this.LBL_Position = new System.Windows.Forms.Label();
            this.LBL_Fullname = new System.Windows.Forms.Label();
            this.PICB_Photo = new System.Windows.Forms.PictureBox();
            this.TXTB_Fullname = new System.Windows.Forms.TextBox();
            this.TXTB_Position = new System.Windows.Forms.TextBox();
            this.TXTB_Nickname = new System.Windows.Forms.TextBox();
            this.TXTB_ID = new System.Windows.Forms.TextBox();
            this.TXTB_ContactPerson = new System.Windows.Forms.TextBox();
            this.TXTB_ContactNumber = new System.Windows.Forms.TextBox();
            this.TXTB_Address = new System.Windows.Forms.RichTextBox();
            this.TXTB_ExpirationDate = new System.Windows.Forms.TextBox();
            this.TXTB_PicturePath = new System.Windows.Forms.TextBox();
            this.BTN_Browse = new System.Windows.Forms.Button();
            this.BTN_Generate = new System.Windows.Forms.Button();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.TEXTB_SearchEmployeeNumber = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lecDataSet = new LEC_201.LecDataSet();
            this.employeeListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.employeeListTableAdapter = new LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter();
            this.tableAdapterManager = new LEC_201.LecDataSetTableAdapters.TableAdapterManager();
            this.employeeListBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.employeeListBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNL_IDpreview.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Photo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).BeginInit();
            this.employeeListBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // PNL_IDpreview
            // 
            this.PNL_IDpreview.BackgroundImage = global::LEC_201.Properties.Resources.BAIOFFICE;
            this.PNL_IDpreview.Controls.Add(this.LBL_ExpirationDate);
            this.PNL_IDpreview.Controls.Add(this.LBL_ContactNumber);
            this.PNL_IDpreview.Controls.Add(this.LBL_ContactPerson);
            this.PNL_IDpreview.Controls.Add(this.LBL_Address);
            this.PNL_IDpreview.Controls.Add(this.label3);
            this.PNL_IDpreview.Controls.Add(this.label2);
            this.PNL_IDpreview.Controls.Add(this.label1);
            this.PNL_IDpreview.Controls.Add(this.LBL_ID);
            this.PNL_IDpreview.Controls.Add(this.LBL_Nickname);
            this.PNL_IDpreview.Controls.Add(this.LBL_Position);
            this.PNL_IDpreview.Controls.Add(this.LBL_Fullname);
            this.PNL_IDpreview.Controls.Add(this.PICB_Photo);
            this.PNL_IDpreview.Location = new System.Drawing.Point(10, 73);
            this.PNL_IDpreview.Name = "PNL_IDpreview";
            this.PNL_IDpreview.Size = new System.Drawing.Size(755, 555);
            this.PNL_IDpreview.TabIndex = 0;
            // 
            // LBL_ExpirationDate
            // 
            this.LBL_ExpirationDate.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ExpirationDate.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ExpirationDate.ForeColor = System.Drawing.Color.Black;
            this.LBL_ExpirationDate.Location = new System.Drawing.Point(384, 84);
            this.LBL_ExpirationDate.Name = "LBL_ExpirationDate";
            this.LBL_ExpirationDate.Size = new System.Drawing.Size(370, 24);
            this.LBL_ExpirationDate.TabIndex = 11;
            this.LBL_ExpirationDate.Text = "This ID is valid until";
            this.LBL_ExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_ContactNumber
            // 
            this.LBL_ContactNumber.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ContactNumber.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ContactNumber.ForeColor = System.Drawing.Color.White;
            this.LBL_ContactNumber.Location = new System.Drawing.Point(544, 226);
            this.LBL_ContactNumber.Name = "LBL_ContactNumber";
            this.LBL_ContactNumber.Size = new System.Drawing.Size(200, 24);
            this.LBL_ContactNumber.TabIndex = 10;
            this.LBL_ContactNumber.Text = "CONTACT NUMBER";
            this.LBL_ContactNumber.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LBL_ContactPerson
            // 
            this.LBL_ContactPerson.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ContactPerson.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ContactPerson.ForeColor = System.Drawing.Color.White;
            this.LBL_ContactPerson.Location = new System.Drawing.Point(544, 202);
            this.LBL_ContactPerson.Name = "LBL_ContactPerson";
            this.LBL_ContactPerson.Size = new System.Drawing.Size(200, 24);
            this.LBL_ContactPerson.TabIndex = 9;
            this.LBL_ContactPerson.Text = "CONTACT PERSON";
            this.LBL_ContactPerson.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LBL_Address
            // 
            this.LBL_Address.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Address.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Address.ForeColor = System.Drawing.Color.White;
            this.LBL_Address.Location = new System.Drawing.Point(544, 253);
            this.LBL_Address.Name = "LBL_Address";
            this.LBL_Address.Size = new System.Drawing.Size(161, 91);
            this.LBL_Address.TabIndex = 8;
            this.LBL_Address.Text = "A.Bonifacio Ave. Cor. Ligaya St. Balintawak, Quezon City";
            // 
            // label3
            // 
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(442, 250);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 24);
            this.label3.TabIndex = 7;
            this.label3.Text = "ADDRESS   :";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label2
            // 
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(442, 226);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 24);
            this.label2.TabIndex = 6;
            this.label2.Text = "CONTACT   :";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(442, 202);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(96, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "NAME        :";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // LBL_ID
            // 
            this.LBL_ID.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ID.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ID.ForeColor = System.Drawing.Color.White;
            this.LBL_ID.Location = new System.Drawing.Point(4, 531);
            this.LBL_ID.Name = "LBL_ID";
            this.LBL_ID.Size = new System.Drawing.Size(370, 24);
            this.LBL_ID.TabIndex = 4;
            this.LBL_ID.Text = "ID NO:";
            this.LBL_ID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Nickname
            // 
            this.LBL_Nickname.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Nickname.Font = new System.Drawing.Font("Calibri", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Nickname.ForeColor = System.Drawing.Color.White;
            this.LBL_Nickname.Location = new System.Drawing.Point(3, 422);
            this.LBL_Nickname.Name = "LBL_Nickname";
            this.LBL_Nickname.Size = new System.Drawing.Size(370, 60);
            this.LBL_Nickname.TabIndex = 3;
            this.LBL_Nickname.Text = "NICKNAME";
            this.LBL_Nickname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Position
            // 
            this.LBL_Position.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Position.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Position.ForeColor = System.Drawing.Color.White;
            this.LBL_Position.Location = new System.Drawing.Point(3, 398);
            this.LBL_Position.Name = "LBL_Position";
            this.LBL_Position.Size = new System.Drawing.Size(370, 24);
            this.LBL_Position.TabIndex = 2;
            this.LBL_Position.Text = "POSITION";
            this.LBL_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Fullname
            // 
            this.LBL_Fullname.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Fullname.Font = new System.Drawing.Font("Calibri", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Fullname.ForeColor = System.Drawing.Color.White;
            this.LBL_Fullname.Location = new System.Drawing.Point(3, 365);
            this.LBL_Fullname.Name = "LBL_Fullname";
            this.LBL_Fullname.Size = new System.Drawing.Size(370, 33);
            this.LBL_Fullname.TabIndex = 1;
            this.LBL_Fullname.Text = "FULL NAME";
            this.LBL_Fullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PICB_Photo
            // 
            this.PICB_Photo.BackColor = System.Drawing.Color.White;
            this.PICB_Photo.ErrorImage = global::LEC_201.Properties.Resources.BAIDEFAULTPHOTO;
            this.PICB_Photo.Image = global::LEC_201.Properties.Resources.BAIDEFAULTPHOTO;
            this.PICB_Photo.InitialImage = global::LEC_201.Properties.Resources.BAIDEFAULTPHOTO;
            this.PICB_Photo.Location = new System.Drawing.Point(104, 192);
            this.PICB_Photo.Name = "PICB_Photo";
            this.PICB_Photo.Size = new System.Drawing.Size(170, 170);
            this.PICB_Photo.TabIndex = 0;
            this.PICB_Photo.TabStop = false;
            // 
            // TXTB_Fullname
            // 
            this.TXTB_Fullname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Fullname.Location = new System.Drawing.Point(923, 120);
            this.TXTB_Fullname.Name = "TXTB_Fullname";
            this.TXTB_Fullname.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Fullname.TabIndex = 21;
            this.TXTB_Fullname.Visible = false;
            this.TXTB_Fullname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_Fullname_KeyPress);
            // 
            // TXTB_Position
            // 
            this.TXTB_Position.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Position.Location = new System.Drawing.Point(923, 151);
            this.TXTB_Position.Name = "TXTB_Position";
            this.TXTB_Position.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Position.TabIndex = 5;
            this.TXTB_Position.Visible = false;
            this.TXTB_Position.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_Position_KeyPress);
            // 
            // TXTB_Nickname
            // 
            this.TXTB_Nickname.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Nickname.Location = new System.Drawing.Point(923, 182);
            this.TXTB_Nickname.Name = "TXTB_Nickname";
            this.TXTB_Nickname.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Nickname.TabIndex = 6;
            this.TXTB_Nickname.Visible = false;
            this.TXTB_Nickname.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_Nickname_KeyPress);
            // 
            // TXTB_ID
            // 
            this.TXTB_ID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ID.Location = new System.Drawing.Point(923, 213);
            this.TXTB_ID.Name = "TXTB_ID";
            this.TXTB_ID.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ID.TabIndex = 4;
            this.TXTB_ID.Visible = false;
            this.TXTB_ID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ID_KeyPress);
            // 
            // TXTB_ContactPerson
            // 
            this.TXTB_ContactPerson.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ContactPerson.Location = new System.Drawing.Point(384, 12);
            this.TXTB_ContactPerson.Name = "TXTB_ContactPerson";
            this.TXTB_ContactPerson.Size = new System.Drawing.Size(100, 22);
            this.TXTB_ContactPerson.TabIndex = 2;
            this.TXTB_ContactPerson.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ContactPerson_KeyPress);
            // 
            // TXTB_ContactNumber
            // 
            this.TXTB_ContactNumber.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ContactNumber.Location = new System.Drawing.Point(664, 12);
            this.TXTB_ContactNumber.Name = "TXTB_ContactNumber";
            this.TXTB_ContactNumber.Size = new System.Drawing.Size(100, 22);
            this.TXTB_ContactNumber.TabIndex = 3;
            this.TXTB_ContactNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ContactNumber_KeyPress);
            // 
            // TXTB_Address
            // 
            this.TXTB_Address.Location = new System.Drawing.Point(923, 242);
            this.TXTB_Address.Name = "TXTB_Address";
            this.TXTB_Address.Size = new System.Drawing.Size(150, 96);
            this.TXTB_Address.TabIndex = 7;
            this.TXTB_Address.Text = "";
            this.TXTB_Address.Visible = false;
            this.TXTB_Address.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_Address_KeyPress);
            // 
            // TXTB_ExpirationDate
            // 
            this.TXTB_ExpirationDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ExpirationDate.Location = new System.Drawing.Point(923, 344);
            this.TXTB_ExpirationDate.Name = "TXTB_ExpirationDate";
            this.TXTB_ExpirationDate.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ExpirationDate.TabIndex = 8;
            this.TXTB_ExpirationDate.Visible = false;
            this.TXTB_ExpirationDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ExpirationDate_KeyPress);
            // 
            // TXTB_PicturePath
            // 
            this.TXTB_PicturePath.Enabled = false;
            this.TXTB_PicturePath.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_PicturePath.Location = new System.Drawing.Point(923, 375);
            this.TXTB_PicturePath.Name = "TXTB_PicturePath";
            this.TXTB_PicturePath.Size = new System.Drawing.Size(150, 25);
            this.TXTB_PicturePath.TabIndex = 9;
            this.TXTB_PicturePath.Visible = false;
            this.TXTB_PicturePath.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_PicturePath_KeyPress);
            // 
            // BTN_Browse
            // 
            this.BTN_Browse.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Browse.Location = new System.Drawing.Point(923, 406);
            this.BTN_Browse.Name = "BTN_Browse";
            this.BTN_Browse.Size = new System.Drawing.Size(150, 23);
            this.BTN_Browse.TabIndex = 10;
            this.BTN_Browse.Text = "BROWSE";
            this.BTN_Browse.UseVisualStyleBackColor = true;
            this.BTN_Browse.Visible = false;
            this.BTN_Browse.Click += new System.EventHandler(this.BTN_Browse_Click);
            // 
            // BTN_Generate
            // 
            this.BTN_Generate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Generate.Location = new System.Drawing.Point(9, 40);
            this.BTN_Generate.Name = "BTN_Generate";
            this.BTN_Generate.Size = new System.Drawing.Size(755, 30);
            this.BTN_Generate.TabIndex = 11;
            this.BTN_Generate.Text = "GENERATE";
            this.BTN_Generate.UseVisualStyleBackColor = true;
            this.BTN_Generate.Click += new System.EventHandler(this.BTN_Generate_Click);
            // 
            // BTN_Save
            // 
            this.BTN_Save.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Save.Location = new System.Drawing.Point(9, 630);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(756, 30);
            this.BTN_Save.TabIndex = 12;
            this.BTN_Save.Text = "SAVE";
            this.BTN_Save.UseVisualStyleBackColor = true;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(833, 123);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 17);
            this.label6.TabIndex = 13;
            this.label6.Text = "FULL NAME:";
            this.label6.Visible = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(844, 154);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 17);
            this.label7.TabIndex = 14;
            this.label7.Text = "POSITION:";
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(837, 185);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(80, 17);
            this.label8.TabIndex = 15;
            this.label8.Text = "NICKNAME:";
            this.label8.Visible = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(867, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(50, 17);
            this.label9.TabIndex = 16;
            this.label9.Text = "ID NO:";
            this.label9.Visible = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(252, 15);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(126, 17);
            this.label10.TabIndex = 17;
            this.label10.Text = "CONTACT PERSON:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(528, 15);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(130, 17);
            this.label11.TabIndex = 18;
            this.label11.Text = "CONTACT NUMBER:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(847, 248);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(70, 17);
            this.label12.TabIndex = 14;
            this.label12.Text = "ADDRESS:";
            this.label12.Visible = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(792, 347);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(125, 17);
            this.label13.TabIndex = 19;
            this.label13.Text = "EXPIRATION DATE:";
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(816, 378);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(101, 17);
            this.label14.TabIndex = 20;
            this.label14.Text = "PICTURE PATH:";
            this.label14.Visible = false;
            // 
            // TEXTB_SearchEmployeeNumber
            // 
            this.TEXTB_SearchEmployeeNumber.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TEXTB_SearchEmployeeNumber.Location = new System.Drawing.Point(105, 12);
            this.TEXTB_SearchEmployeeNumber.Name = "TEXTB_SearchEmployeeNumber";
            this.TEXTB_SearchEmployeeNumber.Size = new System.Drawing.Size(100, 22);
            this.TEXTB_SearchEmployeeNumber.TabIndex = 1;
            this.TEXTB_SearchEmployeeNumber.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(9, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(90, 17);
            this.label4.TabIndex = 22;
            this.label4.Text = "EMPLOYEE #:";
            // 
            // lecDataSet
            // 
            this.lecDataSet.DataSetName = "LecDataSet";
            this.lecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeListBindingSource
            // 
            this.employeeListBindingSource.DataMember = "EmployeeList";
            this.employeeListBindingSource.DataSource = this.lecDataSet;
            // 
            // employeeListTableAdapter
            // 
            this.employeeListTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EmployeeListTableAdapter = this.employeeListTableAdapter;
            this.tableAdapterManager.UpdateOrder = LEC_201.LecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // employeeListBindingNavigator
            // 
            this.employeeListBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeListBindingNavigator.BindingSource = this.employeeListBindingSource;
            this.employeeListBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeListBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeListBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.employeeListBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeeListBindingNavigatorSaveItem});
            this.employeeListBindingNavigator.Location = new System.Drawing.Point(23, 100);
            this.employeeListBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeListBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeListBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeListBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeListBindingNavigator.Name = "employeeListBindingNavigator";
            this.employeeListBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeListBindingNavigator.Size = new System.Drawing.Size(278, 25);
            this.employeeListBindingNavigator.TabIndex = 23;
            this.employeeListBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // employeeListBindingNavigatorSaveItem
            // 
            this.employeeListBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeListBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeeListBindingNavigatorSaveItem.Image")));
            this.employeeListBindingNavigatorSaveItem.Name = "employeeListBindingNavigatorSaveItem";
            this.employeeListBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.employeeListBindingNavigatorSaveItem.Text = "Save Data";
            this.employeeListBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeeListBindingNavigatorSaveItem_Click);
            // 
            // employeeListDataGridView
            // 
            this.employeeListDataGridView.AutoGenerateColumns = false;
            this.employeeListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.employeeListDataGridView.DataSource = this.employeeListBindingSource;
            this.employeeListDataGridView.Enabled = false;
            this.employeeListDataGridView.Location = new System.Drawing.Point(10, 73);
            this.employeeListDataGridView.Name = "employeeListDataGridView";
            this.employeeListDataGridView.Size = new System.Drawing.Size(754, 62);
            this.employeeListDataGridView.TabIndex = 25;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.HeaderText = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn2.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn3.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MiddleName";
            this.dataGridViewTextBoxColumn4.HeaderText = "MiddleName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NickName";
            this.dataGridViewTextBoxColumn5.HeaderText = "NickName";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "BirthDate";
            this.dataGridViewTextBoxColumn6.HeaderText = "BirthDate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "BirthPlace";
            this.dataGridViewTextBoxColumn7.HeaderText = "BirthPlace";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn8.HeaderText = "Address";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ContactNumber";
            this.dataGridViewTextBoxColumn9.HeaderText = "ContactNumber";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CivilStatus";
            this.dataGridViewTextBoxColumn10.HeaderText = "CivilStatus";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Mother";
            this.dataGridViewTextBoxColumn11.HeaderText = "Mother";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Father";
            this.dataGridViewTextBoxColumn12.HeaderText = "Father";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Company";
            this.dataGridViewTextBoxColumn13.HeaderText = "Company";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn14.HeaderText = "Department";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "SubDepartment";
            this.dataGridViewTextBoxColumn15.HeaderText = "SubDepartment";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn16.HeaderText = "Position";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "DateHired";
            this.dataGridViewTextBoxColumn17.HeaderText = "DateHired";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.HeaderText = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "DateSeparated";
            this.dataGridViewTextBoxColumn19.HeaderText = "DateSeparated";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Salary";
            this.dataGridViewTextBoxColumn20.HeaderText = "Salary";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "SalaryType";
            this.dataGridViewTextBoxColumn21.HeaderText = "SalaryType";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "TIN";
            this.dataGridViewTextBoxColumn22.HeaderText = "TIN";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "SSS";
            this.dataGridViewTextBoxColumn23.HeaderText = "SSS";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Philhealth";
            this.dataGridViewTextBoxColumn24.HeaderText = "Philhealth";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Pagibig";
            this.dataGridViewTextBoxColumn25.HeaderText = "Pagibig";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // BAIO
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(774, 662);
            this.Controls.Add(this.PNL_IDpreview);
            this.Controls.Add(this.employeeListDataGridView);
            this.Controls.Add(this.employeeListBindingNavigator);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.TEXTB_SearchEmployeeNumber);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.BTN_Save);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.BTN_Generate);
            this.Controls.Add(this.BTN_Browse);
            this.Controls.Add(this.TXTB_PicturePath);
            this.Controls.Add(this.TXTB_ExpirationDate);
            this.Controls.Add(this.TXTB_Address);
            this.Controls.Add(this.TXTB_ContactNumber);
            this.Controls.Add(this.TXTB_ContactPerson);
            this.Controls.Add(this.TXTB_ID);
            this.Controls.Add(this.TXTB_Nickname);
            this.Controls.Add(this.TXTB_Position);
            this.Controls.Add(this.TXTB_Fullname);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "BAIO";
            this.Text = "ID GENERATOR | BAI Office";
            this.Load += new System.EventHandler(this.BAIO_Load);
            this.PNL_IDpreview.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PICB_Photo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).EndInit();
            this.employeeListBindingNavigator.ResumeLayout(false);
            this.employeeListBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_IDpreview;
        private System.Windows.Forms.PictureBox PICB_Photo;
        private System.Windows.Forms.Label LBL_Fullname;
        private System.Windows.Forms.Label LBL_Address;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label LBL_ID;
        private System.Windows.Forms.Label LBL_Nickname;
        private System.Windows.Forms.Label LBL_Position;
        private System.Windows.Forms.Label LBL_ContactNumber;
        private System.Windows.Forms.Label LBL_ContactPerson;
        private System.Windows.Forms.Label LBL_ExpirationDate;
        private System.Windows.Forms.TextBox TXTB_Fullname;
        private System.Windows.Forms.TextBox TXTB_Position;
        private System.Windows.Forms.TextBox TXTB_Nickname;
        private System.Windows.Forms.TextBox TXTB_ID;
        private System.Windows.Forms.TextBox TXTB_ContactPerson;
        private System.Windows.Forms.TextBox TXTB_ContactNumber;
        private System.Windows.Forms.RichTextBox TXTB_Address;
        private System.Windows.Forms.TextBox TXTB_ExpirationDate;
        private System.Windows.Forms.TextBox TXTB_PicturePath;
        private System.Windows.Forms.Button BTN_Browse;
        private System.Windows.Forms.Button BTN_Generate;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TEXTB_SearchEmployeeNumber;
        private System.Windows.Forms.Label label4;
        private LEC_201.LecDataSet lecDataSet;
        private System.Windows.Forms.BindingSource employeeListBindingSource;
        private LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter employeeListTableAdapter;
        private LEC_201.LecDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeListBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton employeeListBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView employeeListDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
    }
}