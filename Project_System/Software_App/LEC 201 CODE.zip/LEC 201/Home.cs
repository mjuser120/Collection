﻿using ID_GENERATOR;
using LECHIRING;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace LEC_201
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }
        private void Home_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lecDataSet.EmployeeList' table. You can move, or remove it, as needed.
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
            PNL_HomeMenu.Enabled = true;
            PNL_HomeLogin.Visible = false;
            PNL_HomeEmployee.Visible = false;
            BTN_HomeLogin.Text = "LOGIN";
            BTN_HomeLogin.Enabled = true;
            BTN_HomeEmployee.Enabled = false;
            BTN_HomeID.Enabled = false;
            BTN_Hiring.Enabled = false;
        }
        private void BTN_HomeExit_Click(object sender, EventArgs e)
        {
            if (BTN_HomeLogin.Text == "LOGIN")
            {
                this.Close();
            }
            else
            {
                BTN_HomeLogin.PerformClick();
                BTN_HomeExit.PerformClick();
            }
        }
        private void BTN_HomeLogin_Click(object sender, EventArgs e)
        {
            if (BTN_HomeLogin.Text == "LOGIN")
            {
                PNL_HomeLogin.Visible = true;
                TXTB_LoginUsername.Text = "";
                TXTB_LoginPassword.Text = "";
                TXTB_LoginUsername.Focus();
            }
            else
            {
                PNL_HomeMenu.Enabled = true;
                PNL_HomeLogin.Visible = false;
                PNL_HomeEmployee.Visible = false;
                BTN_HomeLogin.Text = "LOGIN";
                BTN_HomeLogin.Enabled = true;
                BTN_HomeEmployee.Enabled = false;
                BTN_HomeID.Enabled = false;
                BTN_Hiring.Enabled = false;
            }
        }
        private void BTN_LoginCancel_Click(object sender, EventArgs e)
        {
            PNL_HomeLogin.Visible = false;
        }

        private void BTN_LoginOk_Click(object sender, EventArgs e)
        {
            string StringUsername = TXTB_LoginUsername.Text.ToUpper();
            string StringPassword = TXTB_LoginPassword.Text;
            if (StringUsername == "ADMIN")
            {
                string StringPathAdmin = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
                string StringPasswordReaderAdmin = File.ReadAllText(StringPathAdmin + "pp.c", Encoding.UTF8);
                if (StringPasswordReaderAdmin == StringPassword)
                {
                    MessageBox.Show("ADMIN!", "LOGIN", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                    PNL_HomeLogin.Visible = false;
                    BTN_HomeLogin.Text = "LOGOUT";
                    BTN_HomeEmployee.Enabled = true;
                    BTN_HomeID.Enabled = true;
                    BTN_Hiring.Enabled = true;
                }
                else
                {
                    MessageBox.Show("INVALID ADMIN PASSWORD", "LOGIN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                string StringPathUser = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
                string StringUsernameReader = File.ReadAllText(StringPathUser + "u.c", Encoding.UTF8);
                string StringPasswordReader = File.ReadAllText(StringPathUser + "p.c", Encoding.UTF8);
                if (StringUsernameReader == StringUsername)
                {
                    if (StringPasswordReader == StringPassword)
                    {
                        MessageBox.Show("WELCOME TO LEC STEEL 201", "LOGIN", MessageBoxButtons.OK, MessageBoxIcon.Asterisk);
                        PNL_HomeLogin.Visible = false;
                        BTN_HomeLogin.Text = "LOGOUT";
                        BTN_HomeEmployee.Enabled = true;
                        BTN_HomeID.Enabled = true;
                        BTN_Hiring.Enabled = true;
                    }
                    else
                    {
                        MessageBox.Show("INVALID PASSWORD", "LOGIN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("INVALID USERNAME", "LOGIN", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void TXTB_LoginUsername_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_LoginPassword.Focus();
            }
        }
        private void TXTB_LoginPassword_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_LoginOk.PerformClick();
            }
        }
        private void BTN_HomeEmployee_Click(object sender, EventArgs e)
        {
            PNL_HomeEmployee.Visible = true;
            COMBOB_EmployeeCompany.Text = "Choose Company..";
            COMBOB_EmployeeDepartment.Text = "Choose Department..";
            COMBOB_EmployeeSubDepartment.Text = "Choose SubDepartment..";
            TXTB_EmployeeSearch.Text = "Enter Surname..";
            COMBOB_BirthdaySearch.Text = "Search Birth Month..";
            string StringPath = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            string[] StringCompanyReader = File.ReadAllLines(StringPath + "CompanyList.c", Encoding.UTF8);
            COMBOB_EmployeeCompany.Items.Clear();
            COMBOB_EmployeeCompany.Items.Add("ALL");
            COMBOB_EmployeeCompany.Items.AddRange(StringCompanyReader);
            RefreshData();
            PNL_DGVcolumns.Visible = false;
            BTN_DGVcolumns.Text = "CHANGE COLUMNS";
            //CHECKBOX
            CB_MiddleName.Checked = true;
            CB_NickName.Checked = true;
            CB_BirthDate.Checked = true;
            CB_BirthPlace.Checked = true;
            CB_Address.Checked = true;
            CB_ContactNumber.Checked = true;
            CB_CivilStatus.Checked = true;
            CB_Mother.Checked = true;
            CB_Father.Checked = true;
            CB_Company.Checked = true;
            CB_Department.Checked = true;
            CB_SubDepartment.Checked = true;
            CB_Position.Checked = true;
            CB_DateHired.Checked = true;
            CB_EmploymentStatus.Checked = true;
            CB_DateSeparated.Checked = true;
            CB_Salary.Checked = true;
            CB_SalaryType.Checked = true;
            CB_Tin.Checked = true;
            CB_Sss.Checked = true;
            CB_Philhealth.Checked = true;
            CB_Pagibig.Checked = true;
            //DGV
            this.dataGridViewTextBoxColumn1.Visible = true;
            this.dataGridViewTextBoxColumn2.Visible = true;
            this.dataGridViewTextBoxColumn3.Visible = true;
            this.dataGridViewTextBoxColumn4.Visible = true;
            this.dataGridViewTextBoxColumn5.Visible = true;
            this.dataGridViewTextBoxColumn6.Visible = true;
            this.dataGridViewTextBoxColumn7.Visible = true;
            this.dataGridViewTextBoxColumn8.Visible = true;
            this.dataGridViewTextBoxColumn9.Visible = true;
            this.dataGridViewTextBoxColumn10.Visible = true;
            this.dataGridViewTextBoxColumn11.Visible = true;
            this.dataGridViewTextBoxColumn12.Visible = true;
            this.dataGridViewTextBoxColumn13.Visible = true;
            this.dataGridViewTextBoxColumn14.Visible = true;
            this.dataGridViewTextBoxColumn15.Visible = true;
            this.dataGridViewTextBoxColumn16.Visible = true;
            this.dataGridViewTextBoxColumn17.Visible = true;
            this.dataGridViewTextBoxColumn18.Visible = true;
            this.dataGridViewTextBoxColumn19.Visible = true;
            this.dataGridViewTextBoxColumn20.Visible = true;
            this.dataGridViewTextBoxColumn21.Visible = true;
            this.dataGridViewTextBoxColumn22.Visible = true;
            this.dataGridViewTextBoxColumn23.Visible = true;
            this.dataGridViewTextBoxColumn24.Visible = true;
            this.dataGridViewTextBoxColumn25.Visible = true;
        }
        private void BTN_EmployeeClose_Click(object sender, EventArgs e)
        {
            PNL_HomeEmployee.Visible = false;
        }
        private void COMBOB_EmployeeCompany_SelectedValueChanged(object sender, EventArgs e)
        {
            string StringPathCompany = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            if (COMBOB_EmployeeCompany.Text == "ALL")
            {
                COMBOB_EmployeeDepartment.Items.Clear();
                COMBOB_EmployeeSubDepartment.Items.Clear();
                COMBOB_EmployeeDepartment.Text = "Choose Department..";
                COMBOB_EmployeeSubDepartment.Text = "Choose SubDepartment..";
                RefreshData();
            }
            else
            {
                COMBOB_EmployeeDepartment.Items.Clear();
                COMBOB_EmployeeSubDepartment.Items.Clear();
                COMBOB_EmployeeDepartment.Text = "Choose Department..";
                COMBOB_EmployeeSubDepartment.Text = "Choose SubDepartment..";
                string StringCompany = COMBOB_EmployeeCompany.Text;
                string StringDepartment = COMBOB_EmployeeCompany.Text + "List.c";
                string[] StringDepartmentReader = File.ReadAllLines(StringPathCompany + StringCompany + "\\" + StringDepartment, Encoding.UTF8);
                COMBOB_EmployeeDepartment.Items.Add("ALL");
                COMBOB_EmployeeDepartment.Items.AddRange(StringDepartmentReader);
                //QUERY START
                string companySearch = this.COMBOB_EmployeeCompany.Text.Replace("'", "''");
                string queryByCompany = "(Company LIKE '%" + companySearch + "%')";
                StringBuilder joinQuery = new StringBuilder();
                joinQuery.Append(queryByCompany);
                this.employeeListBindingSource.Filter = joinQuery.ToString();
                //QUERY END
            }
        }
        private void COMBOB_EmployeeDepartment_SelectedValueChanged(object sender, EventArgs e)
        {
            string StringPathDepartment = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            if (COMBOB_EmployeeDepartment.Text == "ALL")
            {
                COMBOB_EmployeeSubDepartment.Items.Clear();
                COMBOB_EmployeeSubDepartment.Text = "Choose SubDepartment..";
                //QUERY START
                string companySearch = this.COMBOB_EmployeeCompany.Text.Replace("'", "''");
                string queryByCompany = "(Company LIKE '%" + companySearch + "%')";
                StringBuilder joinQuery = new StringBuilder();
                joinQuery.Append(queryByCompany);
                this.employeeListBindingSource.Filter = joinQuery.ToString();
                //QUERY END
            }
            else
            {
                COMBOB_EmployeeSubDepartment.Items.Clear();
                COMBOB_EmployeeSubDepartment.Text = "Choose SubDepartment..";
                string StringCompany = COMBOB_EmployeeCompany.Text;
                string StringSubDepartment = StringCompany + COMBOB_EmployeeDepartment.Text + "List.c";
                string[] StringSubDepartmentReader = File.ReadAllLines(StringPathDepartment + StringCompany + "\\" + StringSubDepartment, Encoding.UTF8);
                COMBOB_EmployeeSubDepartment.Items.Add("ALL");
                COMBOB_EmployeeSubDepartment.Items.AddRange(StringSubDepartmentReader);
                //QUERY START
                string companySearch = this.COMBOB_EmployeeCompany.Text.Replace("'", "''");
                string departmentSearch = this.COMBOB_EmployeeDepartment.Text.Replace("'", "''");
                string queryByDepartment = "(company LIKE '%" + companySearch + "%') AND (department LIKE '%" + departmentSearch + "%')";
                StringBuilder joinQuery = new StringBuilder();
                joinQuery.Append(queryByDepartment);
                this.employeeListBindingSource.Filter = joinQuery.ToString();
                //QUERY END
            }
        }
        private void Home_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.Shift && e.KeyCode == Keys.P)
            {
                DialogResult ChangePassword = MessageBox.Show("Do you want to change Password?", "Change Password", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (ChangePassword == DialogResult.Yes)
                {
                    ChangePassword ChangePasswordForm = new ChangePassword();
                    ChangePasswordForm.ShowDialog();
                }
            }
        }
        private void TXTB_EmployeeSearch_Click(object sender, EventArgs e)
        {
            if (TXTB_EmployeeSearch.Text == "Enter Surname..")
            {
                TXTB_EmployeeSearch.Text = "";
            }
        }
        private void TXTB_EmployeeSearch_Leave(object sender, EventArgs e)
        {
            TXTB_EmployeeSearch.Text = "Enter Surname..";
        }
        private void BTN_HomeID_Click(object sender, EventArgs e)
        {
            IDGEN IDGENform = new IDGEN();
            IDGENform.Show();
        }

        private void BTN_Hiring_Click(object sender, EventArgs e)
        {
            Hiring HIRINGform = new Hiring();
            HIRINGform.Show();
        }

        private void EmployeeListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            DialogResult ContinueSave = MessageBox.Show("ARE YOU SURE YOU WANT TO SAVE CHANGES?", "SAVE CHANGES", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            if (ContinueSave == DialogResult.Yes)
            {
                this.Validate();
                this.employeeListBindingSource.EndEdit();
                this.tableAdapterManager.UpdateAll(this.lecDataSet);
            }
        }

        private void COMBOB_EmployeeSubDepartment_SelectedValueChanged(object sender, EventArgs e)
        {
            if (COMBOB_EmployeeSubDepartment.Text == "ALL")
            {
                //QUERY START
                string companySearch = this.COMBOB_EmployeeCompany.Text.Replace("'", "''");
                string departmentSearch = this.COMBOB_EmployeeDepartment.Text.Replace("'", "''");
                string queryByDepartment = "(company LIKE '%" + companySearch + "%') AND (department LIKE '%" + departmentSearch + "%')";
                StringBuilder joinQuery = new StringBuilder();
                joinQuery.Append(queryByDepartment);
                this.employeeListBindingSource.Filter = joinQuery.ToString();
                //QUERY END
            }
            else
            {
                //QUERY START
                string companySearch = this.COMBOB_EmployeeCompany.Text.Replace("'", "''");
                string departmentSearch = this.COMBOB_EmployeeDepartment.Text.Replace("'", "''");
                string subDepartmentSearch = this.COMBOB_EmployeeSubDepartment.Text.Replace("'", "''");
                string queryByDepartment = "(company LIKE '%" + companySearch + "%') AND (department LIKE '%" + departmentSearch + "%') AND (subdepartment LIKE '%" + subDepartmentSearch + "%')";
                StringBuilder joinQuery = new StringBuilder();
                joinQuery.Append(queryByDepartment);
                this.employeeListBindingSource.Filter = joinQuery.ToString();
                //QUERY END
            }
        }

        private void BTN_AddEmployee_Click(object sender, EventArgs e)
        {
            BTN_EmployeeClose.PerformClick();
            AddEmployee addEmployeeForm = new AddEmployee();
            addEmployeeForm.ShowDialog();
        }
        private void RefreshData()
        {
            this.employeeListBindingSource.Filter = null;
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
        }

        private void BTN_EmployeeSearch_Click(object sender, EventArgs e)
        {
            //QUERY START
            string LastNameSearch = this.TXTB_EmployeeSearch.Text.Replace("'", "''");
            string queryByDepartment = "(LastName LIKE '%" + LastNameSearch + "%')";
            //string queryByDepartment = "(EmployeeNumber LIKE '" + LastNameSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }

        private void BTN_DGVcolumns_Click(object sender, EventArgs e)
        {
            if (BTN_DGVcolumns.Text == "CHANGE COLUMNS")
            {
                BTN_DGVcolumns.Text = "SAVE CHANGES";
                PNL_DGVcolumns.Visible = true;
            }
            else
            {
                if (CB_MiddleName.Checked == true)
                {
                    dataGridViewTextBoxColumn4.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn4.Visible = false;
                }
                if (CB_NickName.Checked == true)
                {
                    dataGridViewTextBoxColumn5.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn5.Visible = false;
                }
                if (CB_BirthDate.Checked == true)
                {
                    dataGridViewTextBoxColumn6.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn6.Visible = false;
                }
                if (CB_BirthPlace.Checked == true)
                {
                    dataGridViewTextBoxColumn7.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn7.Visible = false;
                }
                if (CB_Address.Checked == true)
                {
                    dataGridViewTextBoxColumn8.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn8.Visible = false;
                }
                if (CB_ContactNumber.Checked == true)
                {
                    dataGridViewTextBoxColumn9.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn9.Visible = false;
                }
                if (CB_CivilStatus.Checked == true)
                {
                    dataGridViewTextBoxColumn10.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn10.Visible = false;
                }
                if (CB_Mother.Checked == true)
                {
                    dataGridViewTextBoxColumn11.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn11.Visible = false;
                }
                if (CB_Father.Checked == true)
                {
                    dataGridViewTextBoxColumn12.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn12.Visible = false;
                }
                if (CB_Company.Checked == true)
                {
                    dataGridViewTextBoxColumn13.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn13.Visible = false;
                }
                if (CB_Department.Checked == true)
                {
                    dataGridViewTextBoxColumn14.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn14.Visible = false;
                }
                if (CB_SubDepartment.Checked == true)
                {
                    dataGridViewTextBoxColumn15.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn15.Visible = false;
                }
                if (CB_Position.Checked == true)
                {
                    dataGridViewTextBoxColumn16.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn16.Visible = false;
                }
                if (CB_DateHired.Checked == true)
                {
                    dataGridViewTextBoxColumn17.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn17.Visible = false;
                }
                if (CB_EmploymentStatus.Checked == true)
                {
                    dataGridViewTextBoxColumn18.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn18.Visible = false;
                }
                if (CB_DateSeparated.Checked == true)
                {
                    dataGridViewTextBoxColumn19.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn19.Visible = false;
                }
                if (CB_Salary.Checked == true)
                {
                    dataGridViewTextBoxColumn20.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn20.Visible = false;
                }
                if (CB_SalaryType.Checked == true)
                {
                    dataGridViewTextBoxColumn21.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn21.Visible = false;
                }
                if (CB_Tin.Checked == true)
                {
                    dataGridViewTextBoxColumn22.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn22.Visible = false;
                }
                if (CB_Sss.Checked == true)
                {
                    dataGridViewTextBoxColumn23.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn23.Visible = false;
                }
                if (CB_Philhealth.Checked == true)
                {
                    dataGridViewTextBoxColumn24.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn24.Visible = false;
                }
                if (CB_Pagibig.Checked == true)
                {
                    dataGridViewTextBoxColumn25.Visible = true;
                }
                else
                {
                    dataGridViewTextBoxColumn25.Visible = false;
                }
                BTN_DGVcolumns.Text = "CHANGE COLUMNS";
                PNL_DGVcolumns.Visible = false;
            }
        }

        private void CopyAlltoClipboard()
        {
            employeeListDataGridView.RowHeadersVisible = false;
            employeeListDataGridView.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableAlwaysIncludeHeaderText;
            employeeListDataGridView.MultiSelect = true;
            employeeListDataGridView.SelectAll();
            DataObject dataObj = employeeListDataGridView.GetClipboardContent();
            if (dataObj != null)
                Clipboard.SetDataObject(dataObj);
        }

        private void BTN_DGVexport_Click(object sender, EventArgs e)
        {
            CopyAlltoClipboard();
            Microsoft.Office.Interop.Excel.Application xlexcel;
            Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
            Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
            object misValue = System.Reflection.Missing.Value;
            xlexcel = new Microsoft.Office.Interop.Excel.Application();
            xlexcel.Visible = true;
            xlWorkBook = xlexcel.Workbooks.Add(misValue);
            xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);
            Microsoft.Office.Interop.Excel.Range CR = (Microsoft.Office.Interop.Excel.Range)xlWorkSheet.Cells[1, 1];
            CR.Select();
            xlWorkSheet.PasteSpecial(CR, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, true);
            var xlDate = DateTime.Now;
            xlDate = xlDate.Date;
            string xlDateString = xlDate.ToString("MM-dd-yy");
            xlWorkSheet.Name = "EMPLOYEE LIST " + xlDateString;
            xlWorkSheet.Columns.AutoFit();
            employeeListDataGridView.RowHeadersVisible = true;
        }

        private void COMBOB_BirthdaySearch_SelectedValueChanged(object sender, EventArgs e)
        {
            string SearchBirthMonth = "NULL";
            if (COMBOB_BirthdaySearch.Text == "JANUARY")
            {
                SearchBirthMonth = "JAN";
            }
            if (COMBOB_BirthdaySearch.Text == "FEBRUARY")
            {
                SearchBirthMonth = "FEB";
            }
            if (COMBOB_BirthdaySearch.Text == "MARCH")
            {
                SearchBirthMonth = "MAR";
            }
            if (COMBOB_BirthdaySearch.Text == "APRIL")
            {
                SearchBirthMonth = "APR";
            }
            if (COMBOB_BirthdaySearch.Text == "MAY")
            {
                SearchBirthMonth = "MAY";
            }
            if (COMBOB_BirthdaySearch.Text == "JUNE")
            {
                SearchBirthMonth = "JUN";
            }
            if (COMBOB_BirthdaySearch.Text == "JULY")
            {
                SearchBirthMonth = "JUL";
            }
            if (COMBOB_BirthdaySearch.Text == "AUGUST")
            {
                SearchBirthMonth = "AUG";
            }
            if (COMBOB_BirthdaySearch.Text == "SEPTEMBER")
            {
                SearchBirthMonth = "SEP";
            }
            if (COMBOB_BirthdaySearch.Text == "OCTOBER")
            {
                SearchBirthMonth = "OCT";
            }
            if (COMBOB_BirthdaySearch.Text == "NOVEMBER")
            {
                SearchBirthMonth = "NOV";
            }
            if (COMBOB_BirthdaySearch.Text == "DECEMBER")
            {
                SearchBirthMonth = "DEC";
            }
            //QUERY START
            string queryByDepartment = "(BirthDate LIKE '%" + SearchBirthMonth + "%')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }

        private void COMBOB_BirthdaySearch_Leave(object sender, EventArgs e)
        {
            COMBOB_BirthdaySearch.Text = "Search Birth Month..";
        }

        private void TXTB_EmployeeSearch_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_EmployeeSearch.PerformClick();
            }
        }

        private void BTN_EditEmployee_Click(object sender, EventArgs e)
        {
            BTN_EmployeeClose.PerformClick();
            EditEmployee EditEmployeeForm = new EditEmployee();
            EditEmployeeForm.ShowDialog();
        }
    }
}