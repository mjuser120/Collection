﻿namespace LEC_201
{
    partial class AddEmployee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AddEmployee));
            this.PNL_EmployeeDetails = new System.Windows.Forms.Panel();
            this.earningsDeductionDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.earningsDeductionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lecDataSet = new LEC_201.LecDataSet();
            this.employeeListDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.employeeListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.LBL_PicturePath = new System.Windows.Forms.Label();
            this.COMBOB_EmployeeStatus = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.COMBOB_SalaryType = new System.Windows.Forms.ComboBox();
            this.label25 = new System.Windows.Forms.Label();
            this.TEXTB_addFather = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.TEXTB_addMother = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.BTN_Cancel = new System.Windows.Forms.Button();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.TEXTB_addDateHired = new System.Windows.Forms.DateTimePicker();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.TEXTB_addSalary = new System.Windows.Forms.TextBox();
            this.PNL_GovernmentID = new System.Windows.Forms.Panel();
            this.TEXTB_addPhilhealthNumber = new System.Windows.Forms.TextBox();
            this.TEXTB_addSssNumber = new System.Windows.Forms.TextBox();
            this.TEXTB_addPagibigNumber = new System.Windows.Forms.TextBox();
            this.TEXTB_addTinNumber = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.PICB_addPicture = new System.Windows.Forms.PictureBox();
            this.BTN_addPicturePath = new System.Windows.Forms.Button();
            this.TEXTB_addCivilStatus = new System.Windows.Forms.TextBox();
            this.TEXTB_addPlaceOfBirth = new System.Windows.Forms.TextBox();
            this.TEXTB_addDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.TEXTB_addContact = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.TEXTB_addPresentAddress = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.TEXTB_addNickName = new System.Windows.Forms.TextBox();
            this.TEXTB_addMiddleName = new System.Windows.Forms.TextBox();
            this.TEXTB_addGivenName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.TEXTB_addSurname = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.PNL_EmploymentDetails = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.BTN_GenerateEmployeeNumber = new System.Windows.Forms.Button();
            this.COMBOB_SubDepartment = new System.Windows.Forms.ComboBox();
            this.COMBOB_Department = new System.Windows.Forms.ComboBox();
            this.COMBOB_Company = new System.Windows.Forms.ComboBox();
            this.TEXTB_Position = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.LBL_EmployeeNumber = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.employeeListBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.employeeListBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListTableAdapter = new LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter();
            this.tableAdapterManager = new LEC_201.LecDataSetTableAdapters.TableAdapterManager();
            this.earningsDeductionTableAdapter = new LEC_201.LecDataSetTableAdapters.EarningsDeductionTableAdapter();
            this.PNL_EmployeeDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.earningsDeductionDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.earningsDeductionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).BeginInit();
            this.PNL_GovernmentID.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_addPicture)).BeginInit();
            this.PNL_EmploymentDetails.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).BeginInit();
            this.employeeListBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNL_EmployeeDetails
            // 
            this.PNL_EmployeeDetails.BackColor = System.Drawing.Color.White;
            this.PNL_EmployeeDetails.Controls.Add(this.earningsDeductionDataGridView);
            this.PNL_EmployeeDetails.Controls.Add(this.employeeListDataGridView);
            this.PNL_EmployeeDetails.Controls.Add(this.LBL_PicturePath);
            this.PNL_EmployeeDetails.Controls.Add(this.COMBOB_EmployeeStatus);
            this.PNL_EmployeeDetails.Controls.Add(this.label26);
            this.PNL_EmployeeDetails.Controls.Add(this.COMBOB_SalaryType);
            this.PNL_EmployeeDetails.Controls.Add(this.label25);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addFather);
            this.PNL_EmployeeDetails.Controls.Add(this.label23);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addMother);
            this.PNL_EmployeeDetails.Controls.Add(this.label11);
            this.PNL_EmployeeDetails.Controls.Add(this.BTN_Cancel);
            this.PNL_EmployeeDetails.Controls.Add(this.BTN_Save);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addDateHired);
            this.PNL_EmployeeDetails.Controls.Add(this.label22);
            this.PNL_EmployeeDetails.Controls.Add(this.label21);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addSalary);
            this.PNL_EmployeeDetails.Controls.Add(this.PNL_GovernmentID);
            this.PNL_EmployeeDetails.Controls.Add(this.PICB_addPicture);
            this.PNL_EmployeeDetails.Controls.Add(this.BTN_addPicturePath);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addCivilStatus);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addPlaceOfBirth);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addDateOfBirth);
            this.PNL_EmployeeDetails.Controls.Add(this.label17);
            this.PNL_EmployeeDetails.Controls.Add(this.label15);
            this.PNL_EmployeeDetails.Controls.Add(this.label14);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addContact);
            this.PNL_EmployeeDetails.Controls.Add(this.label12);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addPresentAddress);
            this.PNL_EmployeeDetails.Controls.Add(this.label13);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addNickName);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addMiddleName);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addGivenName);
            this.PNL_EmployeeDetails.Controls.Add(this.label7);
            this.PNL_EmployeeDetails.Controls.Add(this.TEXTB_addSurname);
            this.PNL_EmployeeDetails.Controls.Add(this.label8);
            this.PNL_EmployeeDetails.Controls.Add(this.label9);
            this.PNL_EmployeeDetails.Controls.Add(this.label10);
            this.PNL_EmployeeDetails.Controls.Add(this.label6);
            this.PNL_EmployeeDetails.Location = new System.Drawing.Point(12, 94);
            this.PNL_EmployeeDetails.Name = "PNL_EmployeeDetails";
            this.PNL_EmployeeDetails.Size = new System.Drawing.Size(866, 343);
            this.PNL_EmployeeDetails.TabIndex = 3;
            // 
            // earningsDeductionDataGridView
            // 
            this.earningsDeductionDataGridView.AutoGenerateColumns = false;
            this.earningsDeductionDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.earningsDeductionDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36});
            this.earningsDeductionDataGridView.DataSource = this.earningsDeductionBindingSource;
            this.earningsDeductionDataGridView.Location = new System.Drawing.Point(416, 77);
            this.earningsDeductionDataGridView.Name = "earningsDeductionDataGridView";
            this.earningsDeductionDataGridView.Size = new System.Drawing.Size(215, 130);
            this.earningsDeductionDataGridView.TabIndex = 77;
            this.earningsDeductionDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "EmployeeNumber";
            this.dataGridViewTextBoxColumn26.HeaderText = "EmployeeNumber";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "FullName";
            this.dataGridViewTextBoxColumn27.HeaderText = "FullName";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn28.HeaderText = "Position";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "EarningsAllowance";
            this.dataGridViewTextBoxColumn29.HeaderText = "EarningsAllowance";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "EarningsOthers";
            this.dataGridViewTextBoxColumn30.HeaderText = "EarningsOthers";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "DeductionsContribution";
            this.dataGridViewTextBoxColumn31.HeaderText = "DeductionsContribution";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "DeductionsLoans";
            this.dataGridViewTextBoxColumn32.HeaderText = "DeductionsLoans";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "DeductionsCanteen";
            this.dataGridViewTextBoxColumn33.HeaderText = "DeductionsCanteen";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "DeductionsCoopLoan";
            this.dataGridViewTextBoxColumn34.HeaderText = "DeductionsCoopLoan";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "DeductionsPondo";
            this.dataGridViewTextBoxColumn35.HeaderText = "DeductionsPondo";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "DeductionsAssortedVale";
            this.dataGridViewTextBoxColumn36.HeaderText = "DeductionsAssortedVale";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // earningsDeductionBindingSource
            // 
            this.earningsDeductionBindingSource.DataMember = "EarningsDeduction";
            this.earningsDeductionBindingSource.DataSource = this.lecDataSet;
            // 
            // lecDataSet
            // 
            this.lecDataSet.DataSetName = "LecDataSet";
            this.lecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // employeeListDataGridView
            // 
            this.employeeListDataGridView.AutoGenerateColumns = false;
            this.employeeListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.employeeListDataGridView.DataSource = this.employeeListBindingSource;
            this.employeeListDataGridView.Location = new System.Drawing.Point(637, 77);
            this.employeeListDataGridView.Name = "employeeListDataGridView";
            this.employeeListDataGridView.Size = new System.Drawing.Size(209, 130);
            this.employeeListDataGridView.TabIndex = 4;
            this.employeeListDataGridView.Visible = false;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.HeaderText = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn2.HeaderText = "LastName";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn3.HeaderText = "FirstName";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MiddleName";
            this.dataGridViewTextBoxColumn4.HeaderText = "MiddleName";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NickName";
            this.dataGridViewTextBoxColumn5.HeaderText = "NickName";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "BirthDate";
            this.dataGridViewTextBoxColumn6.HeaderText = "BirthDate";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "BirthPlace";
            this.dataGridViewTextBoxColumn7.HeaderText = "BirthPlace";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn8.HeaderText = "Address";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ContactNumber";
            this.dataGridViewTextBoxColumn9.HeaderText = "ContactNumber";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CivilStatus";
            this.dataGridViewTextBoxColumn10.HeaderText = "CivilStatus";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Mother";
            this.dataGridViewTextBoxColumn11.HeaderText = "Mother";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Father";
            this.dataGridViewTextBoxColumn12.HeaderText = "Father";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Company";
            this.dataGridViewTextBoxColumn13.HeaderText = "Company";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn14.HeaderText = "Department";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "SubDepartment";
            this.dataGridViewTextBoxColumn15.HeaderText = "SubDepartment";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn16.HeaderText = "Position";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "DateHired";
            this.dataGridViewTextBoxColumn17.HeaderText = "DateHired";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.HeaderText = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "DateSeparated";
            this.dataGridViewTextBoxColumn19.HeaderText = "DateSeparated";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Salary";
            this.dataGridViewTextBoxColumn20.HeaderText = "Salary";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "SalaryType";
            this.dataGridViewTextBoxColumn21.HeaderText = "SalaryType";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "TIN";
            this.dataGridViewTextBoxColumn22.HeaderText = "TIN";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "SSS";
            this.dataGridViewTextBoxColumn23.HeaderText = "SSS";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Philhealth";
            this.dataGridViewTextBoxColumn24.HeaderText = "Philhealth";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Pagibig";
            this.dataGridViewTextBoxColumn25.HeaderText = "Pagibig";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // employeeListBindingSource
            // 
            this.employeeListBindingSource.DataMember = "EmployeeList";
            this.employeeListBindingSource.DataSource = this.lecDataSet;
            // 
            // LBL_PicturePath
            // 
            this.LBL_PicturePath.AutoSize = true;
            this.LBL_PicturePath.Location = new System.Drawing.Point(204, 10);
            this.LBL_PicturePath.Name = "LBL_PicturePath";
            this.LBL_PicturePath.Size = new System.Drawing.Size(86, 13);
            this.LBL_PicturePath.TabIndex = 77;
            this.LBL_PicturePath.Text = "PICTURE PATH";
            this.LBL_PicturePath.Visible = false;
            // 
            // COMBOB_EmployeeStatus
            // 
            this.COMBOB_EmployeeStatus.FormattingEnabled = true;
            this.COMBOB_EmployeeStatus.Items.AddRange(new object[] {
            "PROBATIONARY",
            "REGULAR",
            "CONTRACTUAL"});
            this.COMBOB_EmployeeStatus.Location = new System.Drawing.Point(462, 249);
            this.COMBOB_EmployeeStatus.Name = "COMBOB_EmployeeStatus";
            this.COMBOB_EmployeeStatus.Size = new System.Drawing.Size(139, 21);
            this.COMBOB_EmployeeStatus.TabIndex = 76;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(329, 252);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(128, 13);
            this.label26.TabIndex = 75;
            this.label26.Text = "EMPLOYMENT STATUS:";
            // 
            // COMBOB_SalaryType
            // 
            this.COMBOB_SalaryType.FormattingEnabled = true;
            this.COMBOB_SalaryType.Items.AddRange(new object[] {
            "MONTHLY",
            "DAILY"});
            this.COMBOB_SalaryType.Location = new System.Drawing.Point(150, 248);
            this.COMBOB_SalaryType.Name = "COMBOB_SalaryType";
            this.COMBOB_SalaryType.Size = new System.Drawing.Size(139, 21);
            this.COMBOB_SalaryType.TabIndex = 74;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(63, 248);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 13);
            this.label25.TabIndex = 73;
            this.label25.Text = "SALARY TYPE:";
            // 
            // TEXTB_addFather
            // 
            this.TEXTB_addFather.Location = new System.Drawing.Point(461, 133);
            this.TEXTB_addFather.Name = "TEXTB_addFather";
            this.TEXTB_addFather.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addFather.TabIndex = 71;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(362, 136);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(93, 13);
            this.label23.TabIndex = 70;
            this.label23.Text = "FATHER\'s NAME:";
            // 
            // TEXTB_addMother
            // 
            this.TEXTB_addMother.Location = new System.Drawing.Point(461, 107);
            this.TEXTB_addMother.Name = "TEXTB_addMother";
            this.TEXTB_addMother.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addMother.TabIndex = 69;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(355, 110);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(100, 13);
            this.label11.TabIndex = 68;
            this.label11.Text = "MOTHER\'s NAME:";
            // 
            // BTN_Cancel
            // 
            this.BTN_Cancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Cancel.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Cancel.ForeColor = System.Drawing.Color.Red;
            this.BTN_Cancel.Location = new System.Drawing.Point(670, 275);
            this.BTN_Cancel.Name = "BTN_Cancel";
            this.BTN_Cancel.Size = new System.Drawing.Size(143, 48);
            this.BTN_Cancel.TabIndex = 67;
            this.BTN_Cancel.Text = "CANCEL";
            this.BTN_Cancel.UseVisualStyleBackColor = true;
            this.BTN_Cancel.Click += new System.EventHandler(this.BTN_Cancel_Click);
            // 
            // BTN_Save
            // 
            this.BTN_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Save.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Save.Location = new System.Drawing.Point(27, 275);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(621, 48);
            this.BTN_Save.TabIndex = 66;
            this.BTN_Save.Text = "SAVE";
            this.BTN_Save.UseVisualStyleBackColor = true;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // TEXTB_addDateHired
            // 
            this.TEXTB_addDateHired.CustomFormat = "MMM-dd-yyyy";
            this.TEXTB_addDateHired.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TEXTB_addDateHired.Location = new System.Drawing.Point(462, 222);
            this.TEXTB_addDateHired.Name = "TEXTB_addDateHired";
            this.TEXTB_addDateHired.Size = new System.Drawing.Size(139, 20);
            this.TEXTB_addDateHired.TabIndex = 65;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(384, 225);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(72, 13);
            this.label22.TabIndex = 64;
            this.label22.Text = "DATE HIRED:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(92, 225);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(52, 13);
            this.label21.TabIndex = 63;
            this.label21.Text = "SALARY:";
            // 
            // TEXTB_addSalary
            // 
            this.TEXTB_addSalary.Location = new System.Drawing.Point(150, 222);
            this.TEXTB_addSalary.Name = "TEXTB_addSalary";
            this.TEXTB_addSalary.Size = new System.Drawing.Size(139, 20);
            this.TEXTB_addSalary.TabIndex = 62;
            this.TEXTB_addSalary.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TEXTB_addSalary_KeyPress);
            // 
            // PNL_GovernmentID
            // 
            this.PNL_GovernmentID.BackColor = System.Drawing.Color.Maroon;
            this.PNL_GovernmentID.Controls.Add(this.TEXTB_addPhilhealthNumber);
            this.PNL_GovernmentID.Controls.Add(this.TEXTB_addSssNumber);
            this.PNL_GovernmentID.Controls.Add(this.TEXTB_addPagibigNumber);
            this.PNL_GovernmentID.Controls.Add(this.TEXTB_addTinNumber);
            this.PNL_GovernmentID.Controls.Add(this.label20);
            this.PNL_GovernmentID.Controls.Add(this.label19);
            this.PNL_GovernmentID.Controls.Add(this.label18);
            this.PNL_GovernmentID.Controls.Add(this.label16);
            this.PNL_GovernmentID.Location = new System.Drawing.Point(27, 159);
            this.PNL_GovernmentID.Name = "PNL_GovernmentID";
            this.PNL_GovernmentID.Size = new System.Drawing.Size(621, 57);
            this.PNL_GovernmentID.TabIndex = 61;
            // 
            // TEXTB_addPhilhealthNumber
            // 
            this.TEXTB_addPhilhealthNumber.Location = new System.Drawing.Point(434, 31);
            this.TEXTB_addPhilhealthNumber.Name = "TEXTB_addPhilhealthNumber";
            this.TEXTB_addPhilhealthNumber.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addPhilhealthNumber.TabIndex = 42;
            // 
            // TEXTB_addSssNumber
            // 
            this.TEXTB_addSssNumber.Location = new System.Drawing.Point(434, 5);
            this.TEXTB_addSssNumber.Name = "TEXTB_addSssNumber";
            this.TEXTB_addSssNumber.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addSssNumber.TabIndex = 41;
            // 
            // TEXTB_addPagibigNumber
            // 
            this.TEXTB_addPagibigNumber.Location = new System.Drawing.Point(123, 31);
            this.TEXTB_addPagibigNumber.Name = "TEXTB_addPagibigNumber";
            this.TEXTB_addPagibigNumber.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addPagibigNumber.TabIndex = 40;
            // 
            // TEXTB_addTinNumber
            // 
            this.TEXTB_addTinNumber.Location = new System.Drawing.Point(123, 5);
            this.TEXTB_addTinNumber.Name = "TEXTB_addTinNumber";
            this.TEXTB_addTinNumber.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addTinNumber.TabIndex = 39;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(302, 35);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(126, 13);
            this.label20.TabIndex = 38;
            this.label20.Text = "PHILHEALTH NUMBER:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(349, 8);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(79, 13);
            this.label19.TabIndex = 37;
            this.label19.Text = "SSS NUMBER:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(11, 34);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(104, 13);
            this.label18.TabIndex = 36;
            this.label18.Text = "PAGIBIG NUMBER:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(37, 8);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(79, 13);
            this.label16.TabIndex = 35;
            this.label16.Text = "TIN NUMBER:";
            // 
            // PICB_addPicture
            // 
            this.PICB_addPicture.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.PICB_addPicture.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PICB_addPicture.Image = global::LEC_201.Properties.Resources.BAIDEFAULTPHOTO;
            this.PICB_addPicture.InitialImage = global::LEC_201.Properties.Resources.BAIDEFAULTPHOTO;
            this.PICB_addPicture.Location = new System.Drawing.Point(669, 55);
            this.PICB_addPicture.Name = "PICB_addPicture";
            this.PICB_addPicture.Size = new System.Drawing.Size(144, 144);
            this.PICB_addPicture.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.PICB_addPicture.TabIndex = 60;
            this.PICB_addPicture.TabStop = false;
            // 
            // BTN_addPicturePath
            // 
            this.BTN_addPicturePath.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_addPicturePath.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_addPicturePath.Location = new System.Drawing.Point(670, 210);
            this.BTN_addPicturePath.Name = "BTN_addPicturePath";
            this.BTN_addPicturePath.Size = new System.Drawing.Size(143, 30);
            this.BTN_addPicturePath.TabIndex = 59;
            this.BTN_addPicturePath.Text = "ADD PHOTO";
            this.BTN_addPicturePath.UseVisualStyleBackColor = true;
            this.BTN_addPicturePath.Click += new System.EventHandler(this.BTN_addPicturePath_Click);
            // 
            // TEXTB_addCivilStatus
            // 
            this.TEXTB_addCivilStatus.Location = new System.Drawing.Point(461, 81);
            this.TEXTB_addCivilStatus.Name = "TEXTB_addCivilStatus";
            this.TEXTB_addCivilStatus.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addCivilStatus.TabIndex = 55;
            // 
            // TEXTB_addPlaceOfBirth
            // 
            this.TEXTB_addPlaceOfBirth.Location = new System.Drawing.Point(150, 134);
            this.TEXTB_addPlaceOfBirth.Name = "TEXTB_addPlaceOfBirth";
            this.TEXTB_addPlaceOfBirth.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addPlaceOfBirth.TabIndex = 54;
            // 
            // TEXTB_addDateOfBirth
            // 
            this.TEXTB_addDateOfBirth.CustomFormat = "MMM-dd-yyyy";
            this.TEXTB_addDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.TEXTB_addDateOfBirth.Location = new System.Drawing.Point(150, 107);
            this.TEXTB_addDateOfBirth.Name = "TEXTB_addDateOfBirth";
            this.TEXTB_addDateOfBirth.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addDateOfBirth.TabIndex = 53;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(375, 84);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(77, 13);
            this.label17.TabIndex = 52;
            this.label17.Text = "CIVIL STATUS:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(47, 137);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(95, 13);
            this.label15.TabIndex = 51;
            this.label15.Text = "PLACE OF BIRTH:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(54, 110);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(88, 13);
            this.label14.TabIndex = 50;
            this.label14.Text = "DATE OF BIRTH:";
            // 
            // TEXTB_addContact
            // 
            this.TEXTB_addContact.Location = new System.Drawing.Point(150, 81);
            this.TEXTB_addContact.Name = "TEXTB_addContact";
            this.TEXTB_addContact.Size = new System.Drawing.Size(140, 20);
            this.TEXTB_addContact.TabIndex = 47;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(31, 84);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 13);
            this.label12.TabIndex = 46;
            this.label12.Text = "CONTACT NUMBER:";
            // 
            // TEXTB_addPresentAddress
            // 
            this.TEXTB_addPresentAddress.Location = new System.Drawing.Point(150, 55);
            this.TEXTB_addPresentAddress.Name = "TEXTB_addPresentAddress";
            this.TEXTB_addPresentAddress.Size = new System.Drawing.Size(451, 20);
            this.TEXTB_addPresentAddress.TabIndex = 18;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(28, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 13);
            this.label13.TabIndex = 17;
            this.label13.Text = "*PRESENT ADDRESS:";
            // 
            // TEXTB_addNickName
            // 
            this.TEXTB_addNickName.Location = new System.Drawing.Point(733, 29);
            this.TEXTB_addNickName.Name = "TEXTB_addNickName";
            this.TEXTB_addNickName.Size = new System.Drawing.Size(80, 20);
            this.TEXTB_addNickName.TabIndex = 16;
            // 
            // TEXTB_addMiddleName
            // 
            this.TEXTB_addMiddleName.Location = new System.Drawing.Point(528, 29);
            this.TEXTB_addMiddleName.Name = "TEXTB_addMiddleName";
            this.TEXTB_addMiddleName.Size = new System.Drawing.Size(120, 20);
            this.TEXTB_addMiddleName.TabIndex = 15;
            // 
            // TEXTB_addGivenName
            // 
            this.TEXTB_addGivenName.Location = new System.Drawing.Point(307, 29);
            this.TEXTB_addGivenName.Name = "TEXTB_addGivenName";
            this.TEXTB_addGivenName.Size = new System.Drawing.Size(120, 20);
            this.TEXTB_addGivenName.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(24, 32);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(70, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "*SURNAME:";
            // 
            // TEXTB_addSurname
            // 
            this.TEXTB_addSurname.Location = new System.Drawing.Point(95, 29);
            this.TEXTB_addSurname.Name = "TEXTB_addSurname";
            this.TEXTB_addSurname.Size = new System.Drawing.Size(120, 20);
            this.TEXTB_addSurname.TabIndex = 13;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(221, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(85, 13);
            this.label8.TabIndex = 10;
            this.label8.Text = "*GIVEN NAME:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(654, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(73, 13);
            this.label9.TabIndex = 12;
            this.label9.Text = "NICK NAME:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(433, 32);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(89, 13);
            this.label10.TabIndex = 11;
            this.label10.Text = "MIDDLE NAME:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(4, 9);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 17);
            this.label6.TabIndex = 0;
            this.label6.Text = "PERSONAL INFORMATION:";
            // 
            // PNL_EmploymentDetails
            // 
            this.PNL_EmploymentDetails.BackColor = System.Drawing.Color.Maroon;
            this.PNL_EmploymentDetails.Controls.Add(this.label5);
            this.PNL_EmploymentDetails.Controls.Add(this.label4);
            this.PNL_EmploymentDetails.Controls.Add(this.label3);
            this.PNL_EmploymentDetails.Controls.Add(this.BTN_GenerateEmployeeNumber);
            this.PNL_EmploymentDetails.Controls.Add(this.COMBOB_SubDepartment);
            this.PNL_EmploymentDetails.Controls.Add(this.COMBOB_Department);
            this.PNL_EmploymentDetails.Controls.Add(this.COMBOB_Company);
            this.PNL_EmploymentDetails.Controls.Add(this.TEXTB_Position);
            this.PNL_EmploymentDetails.Controls.Add(this.label2);
            this.PNL_EmploymentDetails.Controls.Add(this.LBL_EmployeeNumber);
            this.PNL_EmploymentDetails.Controls.Add(this.label1);
            this.PNL_EmploymentDetails.Location = new System.Drawing.Point(12, 12);
            this.PNL_EmploymentDetails.Name = "PNL_EmploymentDetails";
            this.PNL_EmploymentDetails.Size = new System.Drawing.Size(858, 71);
            this.PNL_EmploymentDetails.TabIndex = 2;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(606, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(119, 16);
            this.label5.TabIndex = 10;
            this.label5.Text = "Sub Department";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(451, 17);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 16);
            this.label4.TabIndex = 9;
            this.label4.Text = "Department";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(296, 17);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 16);
            this.label3.TabIndex = 8;
            this.label3.Text = "Company";
            // 
            // BTN_GenerateEmployeeNumber
            // 
            this.BTN_GenerateEmployeeNumber.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_GenerateEmployeeNumber.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_GenerateEmployeeNumber.Location = new System.Drawing.Point(768, 36);
            this.BTN_GenerateEmployeeNumber.Name = "BTN_GenerateEmployeeNumber";
            this.BTN_GenerateEmployeeNumber.Size = new System.Drawing.Size(78, 25);
            this.BTN_GenerateEmployeeNumber.TabIndex = 7;
            this.BTN_GenerateEmployeeNumber.Text = "GENERATE";
            this.BTN_GenerateEmployeeNumber.UseVisualStyleBackColor = true;
            this.BTN_GenerateEmployeeNumber.Click += new System.EventHandler(this.BTN_GenerateEmployeeNumber_Click);
            // 
            // COMBOB_SubDepartment
            // 
            this.COMBOB_SubDepartment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.COMBOB_SubDepartment.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.COMBOB_SubDepartment.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_SubDepartment.FormattingEnabled = true;
            this.COMBOB_SubDepartment.Location = new System.Drawing.Point(607, 36);
            this.COMBOB_SubDepartment.Name = "COMBOB_SubDepartment";
            this.COMBOB_SubDepartment.Size = new System.Drawing.Size(150, 25);
            this.COMBOB_SubDepartment.TabIndex = 6;
            // 
            // COMBOB_Department
            // 
            this.COMBOB_Department.Cursor = System.Windows.Forms.Cursors.Hand;
            this.COMBOB_Department.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.COMBOB_Department.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_Department.FormattingEnabled = true;
            this.COMBOB_Department.Location = new System.Drawing.Point(451, 36);
            this.COMBOB_Department.Name = "COMBOB_Department";
            this.COMBOB_Department.Size = new System.Drawing.Size(150, 25);
            this.COMBOB_Department.TabIndex = 5;
            this.COMBOB_Department.SelectedValueChanged += new System.EventHandler(this.COMBOB_Department_SelectedValueChanged);
            // 
            // COMBOB_Company
            // 
            this.COMBOB_Company.Cursor = System.Windows.Forms.Cursors.Hand;
            this.COMBOB_Company.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.COMBOB_Company.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_Company.FormattingEnabled = true;
            this.COMBOB_Company.Location = new System.Drawing.Point(295, 36);
            this.COMBOB_Company.Name = "COMBOB_Company";
            this.COMBOB_Company.Size = new System.Drawing.Size(150, 25);
            this.COMBOB_Company.TabIndex = 4;
            this.COMBOB_Company.SelectedValueChanged += new System.EventHandler(this.COMBOB_Company_SelectedValueChanged);
            // 
            // TEXTB_Position
            // 
            this.TEXTB_Position.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TEXTB_Position.Location = new System.Drawing.Point(89, 36);
            this.TEXTB_Position.Name = "TEXTB_Position";
            this.TEXTB_Position.Size = new System.Drawing.Size(200, 25);
            this.TEXTB_Position.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(4, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "POSITION:";
            // 
            // LBL_EmployeeNumber
            // 
            this.LBL_EmployeeNumber.AutoSize = true;
            this.LBL_EmployeeNumber.BackColor = System.Drawing.Color.Transparent;
            this.LBL_EmployeeNumber.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_EmployeeNumber.ForeColor = System.Drawing.Color.White;
            this.LBL_EmployeeNumber.Location = new System.Drawing.Point(133, 9);
            this.LBL_EmployeeNumber.Name = "LBL_EmployeeNumber";
            this.LBL_EmployeeNumber.Size = new System.Drawing.Size(118, 18);
            this.LBL_EmployeeNumber.TabIndex = 1;
            this.LBL_EmployeeNumber.Text = "0000-000-00";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(3, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 18);
            this.label1.TabIndex = 0;
            this.label1.Text = "EMPLOYEE # :";
            // 
            // employeeListBindingNavigator
            // 
            this.employeeListBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeListBindingNavigator.BindingSource = this.employeeListBindingSource;
            this.employeeListBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeListBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeListBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.employeeListBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.employeeListBindingNavigatorSaveItem});
            this.employeeListBindingNavigator.Location = new System.Drawing.Point(2, 447);
            this.employeeListBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeListBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeListBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeListBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeListBindingNavigator.Name = "employeeListBindingNavigator";
            this.employeeListBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeListBindingNavigator.Size = new System.Drawing.Size(278, 25);
            this.employeeListBindingNavigator.TabIndex = 4;
            this.employeeListBindingNavigator.Text = "bindingNavigator1";
            this.employeeListBindingNavigator.Visible = false;
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // employeeListBindingNavigatorSaveItem
            // 
            this.employeeListBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.employeeListBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("employeeListBindingNavigatorSaveItem.Image")));
            this.employeeListBindingNavigatorSaveItem.Name = "employeeListBindingNavigatorSaveItem";
            this.employeeListBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.employeeListBindingNavigatorSaveItem.Text = "Save Data";
            this.employeeListBindingNavigatorSaveItem.Click += new System.EventHandler(this.employeeListBindingNavigatorSaveItem_Click);
            // 
            // employeeListTableAdapter
            // 
            this.employeeListTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EarningsDeductionTableAdapter = null;
            this.tableAdapterManager.EmployeeListTableAdapter = this.employeeListTableAdapter;
            this.tableAdapterManager.UpdateOrder = LEC_201.LecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // earningsDeductionTableAdapter
            // 
            this.earningsDeductionTableAdapter.ClearBeforeFill = true;
            // 
            // AddEmployee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(884, 472);
            this.Controls.Add(this.PNL_EmployeeDetails);
            this.Controls.Add(this.PNL_EmploymentDetails);
            this.Controls.Add(this.employeeListBindingNavigator);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "AddEmployee";
            this.Text = "LEC 201 | Add Employee";
            this.Load += new System.EventHandler(this.AddEmployee_Load);
            this.PNL_EmployeeDetails.ResumeLayout(false);
            this.PNL_EmployeeDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.earningsDeductionDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.earningsDeductionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).EndInit();
            this.PNL_GovernmentID.ResumeLayout(false);
            this.PNL_GovernmentID.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PICB_addPicture)).EndInit();
            this.PNL_EmploymentDetails.ResumeLayout(false);
            this.PNL_EmploymentDetails.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).EndInit();
            this.employeeListBindingNavigator.ResumeLayout(false);
            this.employeeListBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_EmployeeDetails;
        private System.Windows.Forms.TextBox TEXTB_addFather;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox TEXTB_addMother;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button BTN_Cancel;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.DateTimePicker TEXTB_addDateHired;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox TEXTB_addSalary;
        private System.Windows.Forms.Panel PNL_GovernmentID;
        private System.Windows.Forms.TextBox TEXTB_addPhilhealthNumber;
        private System.Windows.Forms.TextBox TEXTB_addSssNumber;
        private System.Windows.Forms.TextBox TEXTB_addPagibigNumber;
        private System.Windows.Forms.TextBox TEXTB_addTinNumber;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.PictureBox PICB_addPicture;
        private System.Windows.Forms.Button BTN_addPicturePath;
        private System.Windows.Forms.TextBox TEXTB_addCivilStatus;
        private System.Windows.Forms.TextBox TEXTB_addPlaceOfBirth;
        private System.Windows.Forms.DateTimePicker TEXTB_addDateOfBirth;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox TEXTB_addContact;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox TEXTB_addPresentAddress;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TEXTB_addNickName;
        private System.Windows.Forms.TextBox TEXTB_addMiddleName;
        private System.Windows.Forms.TextBox TEXTB_addGivenName;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox TEXTB_addSurname;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel PNL_EmploymentDetails;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button BTN_GenerateEmployeeNumber;
        private System.Windows.Forms.ComboBox COMBOB_SubDepartment;
        private System.Windows.Forms.ComboBox COMBOB_Department;
        private System.Windows.Forms.ComboBox COMBOB_Company;
        private System.Windows.Forms.TextBox TEXTB_Position;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LBL_EmployeeNumber;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox COMBOB_EmployeeStatus;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.ComboBox COMBOB_SalaryType;
        private System.Windows.Forms.Label label25;
        private LecDataSet lecDataSet;
        private System.Windows.Forms.BindingSource employeeListBindingSource;
        private LecDataSetTableAdapters.EmployeeListTableAdapter employeeListTableAdapter;
        private LecDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeListBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton employeeListBindingNavigatorSaveItem;
        private System.Windows.Forms.DataGridView employeeListDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.Label LBL_PicturePath;
        private System.Windows.Forms.BindingSource earningsDeductionBindingSource;
        private LecDataSetTableAdapters.EarningsDeductionTableAdapter earningsDeductionTableAdapter;
        private System.Windows.Forms.DataGridView earningsDeductionDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
    }
}