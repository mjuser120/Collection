﻿namespace LEC_201
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.PNL_HomeMenu = new System.Windows.Forms.Panel();
            this.BTN_Hiring = new System.Windows.Forms.Button();
            this.BTN_HomeID = new System.Windows.Forms.Button();
            this.BTN_HomeEmployee = new System.Windows.Forms.Button();
            this.BTN_HomeExit = new System.Windows.Forms.Button();
            this.BTN_HomeLogin = new System.Windows.Forms.Button();
            this.PNL_HomeLogin = new System.Windows.Forms.Panel();
            this.BTN_LoginCancel = new System.Windows.Forms.Button();
            this.BTN_LoginOk = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TXTB_LoginPassword = new System.Windows.Forms.TextBox();
            this.TXTB_LoginUsername = new System.Windows.Forms.TextBox();
            this.PNL_HomeEmployee = new System.Windows.Forms.Panel();
            this.COMBOB_BirthdaySearch = new System.Windows.Forms.ComboBox();
            this.BTN_DGVexport = new System.Windows.Forms.Button();
            this.PNL_DGVcolumns = new System.Windows.Forms.Panel();
            this.CB_Pagibig = new System.Windows.Forms.CheckBox();
            this.CB_Philhealth = new System.Windows.Forms.CheckBox();
            this.CB_Sss = new System.Windows.Forms.CheckBox();
            this.CB_Tin = new System.Windows.Forms.CheckBox();
            this.CB_SalaryType = new System.Windows.Forms.CheckBox();
            this.CB_Salary = new System.Windows.Forms.CheckBox();
            this.CB_DateSeparated = new System.Windows.Forms.CheckBox();
            this.CB_EmploymentStatus = new System.Windows.Forms.CheckBox();
            this.CB_DateHired = new System.Windows.Forms.CheckBox();
            this.CB_Position = new System.Windows.Forms.CheckBox();
            this.CB_SubDepartment = new System.Windows.Forms.CheckBox();
            this.CB_Department = new System.Windows.Forms.CheckBox();
            this.CB_Company = new System.Windows.Forms.CheckBox();
            this.CB_Father = new System.Windows.Forms.CheckBox();
            this.CB_Mother = new System.Windows.Forms.CheckBox();
            this.CB_CivilStatus = new System.Windows.Forms.CheckBox();
            this.CB_ContactNumber = new System.Windows.Forms.CheckBox();
            this.CB_Address = new System.Windows.Forms.CheckBox();
            this.CB_BirthPlace = new System.Windows.Forms.CheckBox();
            this.CB_BirthDate = new System.Windows.Forms.CheckBox();
            this.CB_NickName = new System.Windows.Forms.CheckBox();
            this.CB_MiddleName = new System.Windows.Forms.CheckBox();
            this.BTN_DGVcolumns = new System.Windows.Forms.Button();
            this.employeeListBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lecDataSet = new LEC_201.LecDataSet();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.BTN_AddEmployee = new System.Windows.Forms.ToolStripButton();
            this.BTN_EditEmployee = new System.Windows.Forms.ToolStripButton();
            this.EmployeeListBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.employeeListDataGridView = new System.Windows.Forms.DataGridView();
            this.BTN_EmployeeClose = new System.Windows.Forms.Button();
            this.TXTB_EmployeeSearch = new System.Windows.Forms.TextBox();
            this.BTN_EmployeeSearch = new System.Windows.Forms.Button();
            this.COMBOB_EmployeeSubDepartment = new System.Windows.Forms.ComboBox();
            this.COMBOB_EmployeeDepartment = new System.Windows.Forms.ComboBox();
            this.COMBOB_EmployeeCompany = new System.Windows.Forms.ComboBox();
            this.employeeListTableAdapter = new LEC_201.LecDataSetTableAdapters.EmployeeListTableAdapter();
            this.tableAdapterManager = new LEC_201.LecDataSetTableAdapters.TableAdapterManager();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PNL_HomeMenu.SuspendLayout();
            this.PNL_HomeLogin.SuspendLayout();
            this.PNL_HomeEmployee.SuspendLayout();
            this.PNL_DGVcolumns.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).BeginInit();
            this.employeeListBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // PNL_HomeMenu
            // 
            this.PNL_HomeMenu.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PNL_HomeMenu.Controls.Add(this.BTN_Hiring);
            this.PNL_HomeMenu.Controls.Add(this.BTN_HomeID);
            this.PNL_HomeMenu.Controls.Add(this.BTN_HomeEmployee);
            this.PNL_HomeMenu.Controls.Add(this.BTN_HomeExit);
            this.PNL_HomeMenu.Controls.Add(this.BTN_HomeLogin);
            this.PNL_HomeMenu.Location = new System.Drawing.Point(12, 12);
            this.PNL_HomeMenu.Name = "PNL_HomeMenu";
            this.PNL_HomeMenu.Size = new System.Drawing.Size(150, 537);
            this.PNL_HomeMenu.TabIndex = 0;
            // 
            // BTN_Hiring
            // 
            this.BTN_Hiring.BackgroundImage = global::LEC_201.Properties.Resources.BTN_hiring;
            this.BTN_Hiring.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BTN_Hiring.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Hiring.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_Hiring.Location = new System.Drawing.Point(3, 344);
            this.BTN_Hiring.Name = "BTN_Hiring";
            this.BTN_Hiring.Size = new System.Drawing.Size(144, 144);
            this.BTN_Hiring.TabIndex = 4;
            this.BTN_Hiring.UseVisualStyleBackColor = true;
            this.BTN_Hiring.Click += new System.EventHandler(this.BTN_Hiring_Click);
            // 
            // BTN_HomeID
            // 
            this.BTN_HomeID.BackgroundImage = global::LEC_201.Properties.Resources.BTN_generate;
            this.BTN_HomeID.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BTN_HomeID.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeID.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_HomeID.Location = new System.Drawing.Point(3, 194);
            this.BTN_HomeID.Name = "BTN_HomeID";
            this.BTN_HomeID.Size = new System.Drawing.Size(144, 144);
            this.BTN_HomeID.TabIndex = 3;
            this.BTN_HomeID.UseVisualStyleBackColor = true;
            this.BTN_HomeID.Click += new System.EventHandler(this.BTN_HomeID_Click);
            // 
            // BTN_HomeEmployee
            // 
            this.BTN_HomeEmployee.BackgroundImage = global::LEC_201.Properties.Resources.BTN_employee;
            this.BTN_HomeEmployee.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.BTN_HomeEmployee.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeEmployee.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_HomeEmployee.Location = new System.Drawing.Point(3, 44);
            this.BTN_HomeEmployee.Name = "BTN_HomeEmployee";
            this.BTN_HomeEmployee.Size = new System.Drawing.Size(144, 144);
            this.BTN_HomeEmployee.TabIndex = 2;
            this.BTN_HomeEmployee.UseVisualStyleBackColor = true;
            this.BTN_HomeEmployee.Click += new System.EventHandler(this.BTN_HomeEmployee_Click);
            // 
            // BTN_HomeExit
            // 
            this.BTN_HomeExit.BackColor = System.Drawing.Color.White;
            this.BTN_HomeExit.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_HomeExit.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_HomeExit.Location = new System.Drawing.Point(3, 504);
            this.BTN_HomeExit.Name = "BTN_HomeExit";
            this.BTN_HomeExit.Size = new System.Drawing.Size(144, 30);
            this.BTN_HomeExit.TabIndex = 1;
            this.BTN_HomeExit.Text = "EXIT";
            this.BTN_HomeExit.UseVisualStyleBackColor = false;
            this.BTN_HomeExit.Click += new System.EventHandler(this.BTN_HomeExit_Click);
            // 
            // BTN_HomeLogin
            // 
            this.BTN_HomeLogin.BackColor = System.Drawing.Color.White;
            this.BTN_HomeLogin.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_HomeLogin.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_HomeLogin.Location = new System.Drawing.Point(3, 3);
            this.BTN_HomeLogin.Name = "BTN_HomeLogin";
            this.BTN_HomeLogin.Size = new System.Drawing.Size(144, 30);
            this.BTN_HomeLogin.TabIndex = 0;
            this.BTN_HomeLogin.Text = "LOGIN";
            this.BTN_HomeLogin.UseVisualStyleBackColor = false;
            this.BTN_HomeLogin.Click += new System.EventHandler(this.BTN_HomeLogin_Click);
            // 
            // PNL_HomeLogin
            // 
            this.PNL_HomeLogin.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PNL_HomeLogin.Controls.Add(this.BTN_LoginCancel);
            this.PNL_HomeLogin.Controls.Add(this.BTN_LoginOk);
            this.PNL_HomeLogin.Controls.Add(this.label2);
            this.PNL_HomeLogin.Controls.Add(this.label1);
            this.PNL_HomeLogin.Controls.Add(this.TXTB_LoginPassword);
            this.PNL_HomeLogin.Controls.Add(this.TXTB_LoginUsername);
            this.PNL_HomeLogin.Location = new System.Drawing.Point(168, 12);
            this.PNL_HomeLogin.Name = "PNL_HomeLogin";
            this.PNL_HomeLogin.Size = new System.Drawing.Size(200, 105);
            this.PNL_HomeLogin.TabIndex = 1;
            // 
            // BTN_LoginCancel
            // 
            this.BTN_LoginCancel.BackColor = System.Drawing.Color.White;
            this.BTN_LoginCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_LoginCancel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LoginCancel.Location = new System.Drawing.Point(113, 70);
            this.BTN_LoginCancel.Name = "BTN_LoginCancel";
            this.BTN_LoginCancel.Size = new System.Drawing.Size(75, 23);
            this.BTN_LoginCancel.TabIndex = 5;
            this.BTN_LoginCancel.Text = "CANCEL";
            this.BTN_LoginCancel.UseVisualStyleBackColor = false;
            this.BTN_LoginCancel.Click += new System.EventHandler(this.BTN_LoginCancel_Click);
            // 
            // BTN_LoginOk
            // 
            this.BTN_LoginOk.BackColor = System.Drawing.Color.White;
            this.BTN_LoginOk.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_LoginOk.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_LoginOk.Location = new System.Drawing.Point(10, 70);
            this.BTN_LoginOk.Name = "BTN_LoginOk";
            this.BTN_LoginOk.Size = new System.Drawing.Size(75, 23);
            this.BTN_LoginOk.TabIndex = 4;
            this.BTN_LoginOk.Text = "OK";
            this.BTN_LoginOk.UseVisualStyleBackColor = false;
            this.BTN_LoginOk.Click += new System.EventHandler(this.BTN_LoginOk_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(15, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "PASSWORD:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(14, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(71, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "USERNAME:";
            // 
            // TXTB_LoginPassword
            // 
            this.TXTB_LoginPassword.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_LoginPassword.Location = new System.Drawing.Point(88, 41);
            this.TXTB_LoginPassword.Name = "TXTB_LoginPassword";
            this.TXTB_LoginPassword.PasswordChar = '*';
            this.TXTB_LoginPassword.Size = new System.Drawing.Size(100, 22);
            this.TXTB_LoginPassword.TabIndex = 1;
            this.TXTB_LoginPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_LoginPassword_KeyPress);
            // 
            // TXTB_LoginUsername
            // 
            this.TXTB_LoginUsername.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_LoginUsername.Location = new System.Drawing.Point(88, 13);
            this.TXTB_LoginUsername.Name = "TXTB_LoginUsername";
            this.TXTB_LoginUsername.Size = new System.Drawing.Size(100, 22);
            this.TXTB_LoginUsername.TabIndex = 0;
            this.TXTB_LoginUsername.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_LoginUsername_KeyPress);
            // 
            // PNL_HomeEmployee
            // 
            this.PNL_HomeEmployee.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.PNL_HomeEmployee.Controls.Add(this.COMBOB_BirthdaySearch);
            this.PNL_HomeEmployee.Controls.Add(this.BTN_DGVexport);
            this.PNL_HomeEmployee.Controls.Add(this.PNL_DGVcolumns);
            this.PNL_HomeEmployee.Controls.Add(this.BTN_DGVcolumns);
            this.PNL_HomeEmployee.Controls.Add(this.employeeListBindingNavigator);
            this.PNL_HomeEmployee.Controls.Add(this.employeeListDataGridView);
            this.PNL_HomeEmployee.Controls.Add(this.BTN_EmployeeClose);
            this.PNL_HomeEmployee.Controls.Add(this.TXTB_EmployeeSearch);
            this.PNL_HomeEmployee.Controls.Add(this.BTN_EmployeeSearch);
            this.PNL_HomeEmployee.Controls.Add(this.COMBOB_EmployeeSubDepartment);
            this.PNL_HomeEmployee.Controls.Add(this.COMBOB_EmployeeDepartment);
            this.PNL_HomeEmployee.Controls.Add(this.COMBOB_EmployeeCompany);
            this.PNL_HomeEmployee.Location = new System.Drawing.Point(175, 12);
            this.PNL_HomeEmployee.Name = "PNL_HomeEmployee";
            this.PNL_HomeEmployee.Size = new System.Drawing.Size(801, 537);
            this.PNL_HomeEmployee.TabIndex = 2;
            // 
            // COMBOB_BirthdaySearch
            // 
            this.COMBOB_BirthdaySearch.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_BirthdaySearch.FormattingEnabled = true;
            this.COMBOB_BirthdaySearch.Items.AddRange(new object[] {
            "JANUARY",
            "FEBRUARY",
            "MARCH",
            "APRIL",
            "MAY",
            "JUNE",
            "JULY",
            "AUGUST",
            "SEPTEMBER",
            "OCTOBER",
            "NOVEMBER",
            "DECEMBER"});
            this.COMBOB_BirthdaySearch.Location = new System.Drawing.Point(531, 9);
            this.COMBOB_BirthdaySearch.Name = "COMBOB_BirthdaySearch";
            this.COMBOB_BirthdaySearch.Size = new System.Drawing.Size(130, 21);
            this.COMBOB_BirthdaySearch.TabIndex = 10;
            this.COMBOB_BirthdaySearch.Text = "Search Birth Month..";
            this.COMBOB_BirthdaySearch.SelectedValueChanged += new System.EventHandler(this.COMBOB_BirthdaySearch_SelectedValueChanged);
            this.COMBOB_BirthdaySearch.Leave += new System.EventHandler(this.COMBOB_BirthdaySearch_Leave);
            // 
            // BTN_DGVexport
            // 
            this.BTN_DGVexport.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_DGVexport.Location = new System.Drawing.Point(566, 504);
            this.BTN_DGVexport.Name = "BTN_DGVexport";
            this.BTN_DGVexport.Size = new System.Drawing.Size(150, 25);
            this.BTN_DGVexport.TabIndex = 9;
            this.BTN_DGVexport.Text = "EXPORT TO EXCEL";
            this.BTN_DGVexport.UseVisualStyleBackColor = true;
            this.BTN_DGVexport.Click += new System.EventHandler(this.BTN_DGVexport_Click);
            // 
            // PNL_DGVcolumns
            // 
            this.PNL_DGVcolumns.BackColor = System.Drawing.Color.White;
            this.PNL_DGVcolumns.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PNL_DGVcolumns.Controls.Add(this.CB_Pagibig);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Philhealth);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Sss);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Tin);
            this.PNL_DGVcolumns.Controls.Add(this.CB_SalaryType);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Salary);
            this.PNL_DGVcolumns.Controls.Add(this.CB_DateSeparated);
            this.PNL_DGVcolumns.Controls.Add(this.CB_EmploymentStatus);
            this.PNL_DGVcolumns.Controls.Add(this.CB_DateHired);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Position);
            this.PNL_DGVcolumns.Controls.Add(this.CB_SubDepartment);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Department);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Company);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Father);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Mother);
            this.PNL_DGVcolumns.Controls.Add(this.CB_CivilStatus);
            this.PNL_DGVcolumns.Controls.Add(this.CB_ContactNumber);
            this.PNL_DGVcolumns.Controls.Add(this.CB_Address);
            this.PNL_DGVcolumns.Controls.Add(this.CB_BirthPlace);
            this.PNL_DGVcolumns.Controls.Add(this.CB_BirthDate);
            this.PNL_DGVcolumns.Controls.Add(this.CB_NickName);
            this.PNL_DGVcolumns.Controls.Add(this.CB_MiddleName);
            this.PNL_DGVcolumns.Location = new System.Drawing.Point(3, 3);
            this.PNL_DGVcolumns.Name = "PNL_DGVcolumns";
            this.PNL_DGVcolumns.Size = new System.Drawing.Size(150, 504);
            this.PNL_DGVcolumns.TabIndex = 8;
            // 
            // CB_Pagibig
            // 
            this.CB_Pagibig.AutoSize = true;
            this.CB_Pagibig.Location = new System.Drawing.Point(7, 482);
            this.CB_Pagibig.Name = "CB_Pagibig";
            this.CB_Pagibig.Size = new System.Drawing.Size(61, 17);
            this.CB_Pagibig.TabIndex = 21;
            this.CB_Pagibig.Text = "Pagibig";
            this.CB_Pagibig.UseVisualStyleBackColor = true;
            // 
            // CB_Philhealth
            // 
            this.CB_Philhealth.AutoSize = true;
            this.CB_Philhealth.Location = new System.Drawing.Point(7, 460);
            this.CB_Philhealth.Name = "CB_Philhealth";
            this.CB_Philhealth.Size = new System.Drawing.Size(72, 17);
            this.CB_Philhealth.TabIndex = 20;
            this.CB_Philhealth.Text = "Philhealth";
            this.CB_Philhealth.UseVisualStyleBackColor = true;
            // 
            // CB_Sss
            // 
            this.CB_Sss.AutoSize = true;
            this.CB_Sss.Location = new System.Drawing.Point(7, 438);
            this.CB_Sss.Name = "CB_Sss";
            this.CB_Sss.Size = new System.Drawing.Size(47, 17);
            this.CB_Sss.TabIndex = 19;
            this.CB_Sss.Text = "SSS";
            this.CB_Sss.UseVisualStyleBackColor = true;
            // 
            // CB_Tin
            // 
            this.CB_Tin.AutoSize = true;
            this.CB_Tin.Location = new System.Drawing.Point(7, 415);
            this.CB_Tin.Name = "CB_Tin";
            this.CB_Tin.Size = new System.Drawing.Size(44, 17);
            this.CB_Tin.TabIndex = 18;
            this.CB_Tin.Text = "TIN";
            this.CB_Tin.UseVisualStyleBackColor = true;
            // 
            // CB_SalaryType
            // 
            this.CB_SalaryType.AutoSize = true;
            this.CB_SalaryType.Location = new System.Drawing.Point(7, 392);
            this.CB_SalaryType.Name = "CB_SalaryType";
            this.CB_SalaryType.Size = new System.Drawing.Size(82, 17);
            this.CB_SalaryType.TabIndex = 17;
            this.CB_SalaryType.Text = "Salary Type";
            this.CB_SalaryType.UseVisualStyleBackColor = true;
            // 
            // CB_Salary
            // 
            this.CB_Salary.AutoSize = true;
            this.CB_Salary.Location = new System.Drawing.Point(7, 369);
            this.CB_Salary.Name = "CB_Salary";
            this.CB_Salary.Size = new System.Drawing.Size(55, 17);
            this.CB_Salary.TabIndex = 16;
            this.CB_Salary.Text = "Salary";
            this.CB_Salary.UseVisualStyleBackColor = true;
            // 
            // CB_DateSeparated
            // 
            this.CB_DateSeparated.AutoSize = true;
            this.CB_DateSeparated.Location = new System.Drawing.Point(7, 346);
            this.CB_DateSeparated.Name = "CB_DateSeparated";
            this.CB_DateSeparated.Size = new System.Drawing.Size(101, 17);
            this.CB_DateSeparated.TabIndex = 15;
            this.CB_DateSeparated.Text = "Date Separated";
            this.CB_DateSeparated.UseVisualStyleBackColor = true;
            // 
            // CB_EmploymentStatus
            // 
            this.CB_EmploymentStatus.AutoSize = true;
            this.CB_EmploymentStatus.Location = new System.Drawing.Point(7, 324);
            this.CB_EmploymentStatus.Name = "CB_EmploymentStatus";
            this.CB_EmploymentStatus.Size = new System.Drawing.Size(116, 17);
            this.CB_EmploymentStatus.TabIndex = 14;
            this.CB_EmploymentStatus.Text = "Employment Status";
            this.CB_EmploymentStatus.UseVisualStyleBackColor = true;
            // 
            // CB_DateHired
            // 
            this.CB_DateHired.AutoSize = true;
            this.CB_DateHired.Location = new System.Drawing.Point(7, 301);
            this.CB_DateHired.Name = "CB_DateHired";
            this.CB_DateHired.Size = new System.Drawing.Size(77, 17);
            this.CB_DateHired.TabIndex = 13;
            this.CB_DateHired.Text = "Date Hired";
            this.CB_DateHired.UseVisualStyleBackColor = true;
            // 
            // CB_Position
            // 
            this.CB_Position.AutoSize = true;
            this.CB_Position.Location = new System.Drawing.Point(7, 278);
            this.CB_Position.Name = "CB_Position";
            this.CB_Position.Size = new System.Drawing.Size(63, 17);
            this.CB_Position.TabIndex = 12;
            this.CB_Position.Text = "Position";
            this.CB_Position.UseVisualStyleBackColor = true;
            // 
            // CB_SubDepartment
            // 
            this.CB_SubDepartment.AutoSize = true;
            this.CB_SubDepartment.Location = new System.Drawing.Point(7, 255);
            this.CB_SubDepartment.Name = "CB_SubDepartment";
            this.CB_SubDepartment.Size = new System.Drawing.Size(103, 17);
            this.CB_SubDepartment.TabIndex = 11;
            this.CB_SubDepartment.Text = "Sub Department";
            this.CB_SubDepartment.UseVisualStyleBackColor = true;
            // 
            // CB_Department
            // 
            this.CB_Department.AutoSize = true;
            this.CB_Department.Location = new System.Drawing.Point(7, 232);
            this.CB_Department.Name = "CB_Department";
            this.CB_Department.Size = new System.Drawing.Size(81, 17);
            this.CB_Department.TabIndex = 10;
            this.CB_Department.Text = "Department";
            this.CB_Department.UseVisualStyleBackColor = true;
            // 
            // CB_Company
            // 
            this.CB_Company.AutoSize = true;
            this.CB_Company.Location = new System.Drawing.Point(7, 209);
            this.CB_Company.Name = "CB_Company";
            this.CB_Company.Size = new System.Drawing.Size(70, 17);
            this.CB_Company.TabIndex = 9;
            this.CB_Company.Text = "Company";
            this.CB_Company.UseVisualStyleBackColor = true;
            // 
            // CB_Father
            // 
            this.CB_Father.AutoSize = true;
            this.CB_Father.Location = new System.Drawing.Point(7, 187);
            this.CB_Father.Name = "CB_Father";
            this.CB_Father.Size = new System.Drawing.Size(56, 17);
            this.CB_Father.TabIndex = 8;
            this.CB_Father.Text = "Father";
            this.CB_Father.UseVisualStyleBackColor = true;
            // 
            // CB_Mother
            // 
            this.CB_Mother.AutoSize = true;
            this.CB_Mother.Location = new System.Drawing.Point(7, 164);
            this.CB_Mother.Name = "CB_Mother";
            this.CB_Mother.Size = new System.Drawing.Size(59, 17);
            this.CB_Mother.TabIndex = 7;
            this.CB_Mother.Text = "Mother";
            this.CB_Mother.UseVisualStyleBackColor = true;
            // 
            // CB_CivilStatus
            // 
            this.CB_CivilStatus.AutoSize = true;
            this.CB_CivilStatus.Location = new System.Drawing.Point(7, 141);
            this.CB_CivilStatus.Name = "CB_CivilStatus";
            this.CB_CivilStatus.Size = new System.Drawing.Size(78, 17);
            this.CB_CivilStatus.TabIndex = 6;
            this.CB_CivilStatus.Text = "Civil Status";
            this.CB_CivilStatus.UseVisualStyleBackColor = true;
            // 
            // CB_ContactNumber
            // 
            this.CB_ContactNumber.AutoSize = true;
            this.CB_ContactNumber.Location = new System.Drawing.Point(7, 118);
            this.CB_ContactNumber.Name = "CB_ContactNumber";
            this.CB_ContactNumber.Size = new System.Drawing.Size(103, 17);
            this.CB_ContactNumber.TabIndex = 5;
            this.CB_ContactNumber.Text = "Contact Number";
            this.CB_ContactNumber.UseVisualStyleBackColor = true;
            // 
            // CB_Address
            // 
            this.CB_Address.AutoSize = true;
            this.CB_Address.Location = new System.Drawing.Point(7, 95);
            this.CB_Address.Name = "CB_Address";
            this.CB_Address.Size = new System.Drawing.Size(64, 17);
            this.CB_Address.TabIndex = 4;
            this.CB_Address.Text = "Address";
            this.CB_Address.UseVisualStyleBackColor = true;
            // 
            // CB_BirthPlace
            // 
            this.CB_BirthPlace.AutoSize = true;
            this.CB_BirthPlace.Location = new System.Drawing.Point(7, 72);
            this.CB_BirthPlace.Name = "CB_BirthPlace";
            this.CB_BirthPlace.Size = new System.Drawing.Size(77, 17);
            this.CB_BirthPlace.TabIndex = 3;
            this.CB_BirthPlace.Text = "Birth Place";
            this.CB_BirthPlace.UseVisualStyleBackColor = true;
            // 
            // CB_BirthDate
            // 
            this.CB_BirthDate.AutoSize = true;
            this.CB_BirthDate.Location = new System.Drawing.Point(7, 49);
            this.CB_BirthDate.Name = "CB_BirthDate";
            this.CB_BirthDate.Size = new System.Drawing.Size(73, 17);
            this.CB_BirthDate.TabIndex = 2;
            this.CB_BirthDate.Text = "Birth Date";
            this.CB_BirthDate.UseVisualStyleBackColor = true;
            // 
            // CB_NickName
            // 
            this.CB_NickName.AutoSize = true;
            this.CB_NickName.Location = new System.Drawing.Point(7, 26);
            this.CB_NickName.Name = "CB_NickName";
            this.CB_NickName.Size = new System.Drawing.Size(79, 17);
            this.CB_NickName.TabIndex = 1;
            this.CB_NickName.Text = "Nick Name";
            this.CB_NickName.UseVisualStyleBackColor = true;
            // 
            // CB_MiddleName
            // 
            this.CB_MiddleName.AutoSize = true;
            this.CB_MiddleName.Location = new System.Drawing.Point(7, 3);
            this.CB_MiddleName.Name = "CB_MiddleName";
            this.CB_MiddleName.Size = new System.Drawing.Size(88, 17);
            this.CB_MiddleName.TabIndex = 0;
            this.CB_MiddleName.Text = "Middle Name";
            this.CB_MiddleName.UseVisualStyleBackColor = true;
            // 
            // BTN_DGVcolumns
            // 
            this.BTN_DGVcolumns.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_DGVcolumns.Location = new System.Drawing.Point(3, 504);
            this.BTN_DGVcolumns.Name = "BTN_DGVcolumns";
            this.BTN_DGVcolumns.Size = new System.Drawing.Size(150, 25);
            this.BTN_DGVcolumns.TabIndex = 7;
            this.BTN_DGVcolumns.Text = "CHANGE COLUMNS";
            this.BTN_DGVcolumns.UseVisualStyleBackColor = true;
            this.BTN_DGVcolumns.Click += new System.EventHandler(this.BTN_DGVcolumns_Click);
            // 
            // employeeListBindingNavigator
            // 
            this.employeeListBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.employeeListBindingNavigator.BindingSource = this.employeeListBindingSource;
            this.employeeListBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.employeeListBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.employeeListBindingNavigator.Dock = System.Windows.Forms.DockStyle.None;
            this.employeeListBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.BTN_AddEmployee,
            this.BTN_EditEmployee,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.EmployeeListBindingNavigatorSaveItem});
            this.employeeListBindingNavigator.Location = new System.Drawing.Point(3, 34);
            this.employeeListBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.employeeListBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.employeeListBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.employeeListBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.employeeListBindingNavigator.Name = "employeeListBindingNavigator";
            this.employeeListBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.employeeListBindingNavigator.Size = new System.Drawing.Size(255, 25);
            this.employeeListBindingNavigator.TabIndex = 3;
            this.employeeListBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Visible = false;
            // 
            // employeeListBindingSource
            // 
            this.employeeListBindingSource.DataMember = "EmployeeList";
            this.employeeListBindingSource.DataSource = this.lecDataSet;
            // 
            // lecDataSet
            // 
            this.lecDataSet.DataSetName = "LecDataSet";
            this.lecDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(35, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.Visible = false;
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // BTN_AddEmployee
            // 
            this.BTN_AddEmployee.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_AddEmployee.Image = global::LEC_201.Properties.Resources.AddEmployee;
            this.BTN_AddEmployee.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_AddEmployee.Name = "BTN_AddEmployee";
            this.BTN_AddEmployee.Size = new System.Drawing.Size(23, 22);
            this.BTN_AddEmployee.Text = "Add New Employee";
            this.BTN_AddEmployee.Click += new System.EventHandler(this.BTN_AddEmployee_Click);
            // 
            // BTN_EditEmployee
            // 
            this.BTN_EditEmployee.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.BTN_EditEmployee.Image = global::LEC_201.Properties.Resources.EditEmployee;
            this.BTN_EditEmployee.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.BTN_EditEmployee.Name = "BTN_EditEmployee";
            this.BTN_EditEmployee.Size = new System.Drawing.Size(23, 22);
            this.BTN_EditEmployee.Text = "Edit Employee Details";
            this.BTN_EditEmployee.Click += new System.EventHandler(this.BTN_EditEmployee_Click);
            // 
            // EmployeeListBindingNavigatorSaveItem
            // 
            this.EmployeeListBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.EmployeeListBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("EmployeeListBindingNavigatorSaveItem.Image")));
            this.EmployeeListBindingNavigatorSaveItem.Name = "EmployeeListBindingNavigatorSaveItem";
            this.EmployeeListBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.EmployeeListBindingNavigatorSaveItem.Text = "Save Data";
            this.EmployeeListBindingNavigatorSaveItem.Visible = false;
            this.EmployeeListBindingNavigatorSaveItem.Click += new System.EventHandler(this.EmployeeListBindingNavigatorSaveItem_Click);
            // 
            // employeeListDataGridView
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.employeeListDataGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.employeeListDataGridView.AutoGenerateColumns = false;
            this.employeeListDataGridView.BackgroundColor = System.Drawing.Color.White;
            this.employeeListDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.Maroon;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.employeeListDataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.employeeListDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeListDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.employeeListDataGridView.DataSource = this.employeeListBindingSource;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.employeeListDataGridView.DefaultCellStyle = dataGridViewCellStyle3;
            this.employeeListDataGridView.EnableHeadersVisualStyles = false;
            this.employeeListDataGridView.GridColor = System.Drawing.Color.Black;
            this.employeeListDataGridView.Location = new System.Drawing.Point(3, 62);
            this.employeeListDataGridView.Name = "employeeListDataGridView";
            this.employeeListDataGridView.ReadOnly = true;
            this.employeeListDataGridView.Size = new System.Drawing.Size(794, 436);
            this.employeeListDataGridView.TabIndex = 6;
            // 
            // BTN_EmployeeClose
            // 
            this.BTN_EmployeeClose.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_EmployeeClose.Location = new System.Drawing.Point(722, 504);
            this.BTN_EmployeeClose.Name = "BTN_EmployeeClose";
            this.BTN_EmployeeClose.Size = new System.Drawing.Size(75, 25);
            this.BTN_EmployeeClose.TabIndex = 5;
            this.BTN_EmployeeClose.Text = "CLOSE";
            this.BTN_EmployeeClose.UseVisualStyleBackColor = true;
            this.BTN_EmployeeClose.Click += new System.EventHandler(this.BTN_EmployeeClose_Click);
            // 
            // TXTB_EmployeeSearch
            // 
            this.TXTB_EmployeeSearch.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_EmployeeSearch.Location = new System.Drawing.Point(667, 8);
            this.TXTB_EmployeeSearch.Name = "TXTB_EmployeeSearch";
            this.TXTB_EmployeeSearch.Size = new System.Drawing.Size(130, 22);
            this.TXTB_EmployeeSearch.TabIndex = 4;
            this.TXTB_EmployeeSearch.Click += new System.EventHandler(this.TXTB_EmployeeSearch_Click);
            this.TXTB_EmployeeSearch.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_EmployeeSearch_KeyPress);
            this.TXTB_EmployeeSearch.Leave += new System.EventHandler(this.TXTB_EmployeeSearch_Leave);
            // 
            // BTN_EmployeeSearch
            // 
            this.BTN_EmployeeSearch.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_EmployeeSearch.Location = new System.Drawing.Point(739, 9);
            this.BTN_EmployeeSearch.Name = "BTN_EmployeeSearch";
            this.BTN_EmployeeSearch.Size = new System.Drawing.Size(58, 21);
            this.BTN_EmployeeSearch.TabIndex = 3;
            this.BTN_EmployeeSearch.Text = "SEARCH";
            this.BTN_EmployeeSearch.UseVisualStyleBackColor = true;
            this.BTN_EmployeeSearch.Click += new System.EventHandler(this.BTN_EmployeeSearch_Click);
            // 
            // COMBOB_EmployeeSubDepartment
            // 
            this.COMBOB_EmployeeSubDepartment.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_EmployeeSubDepartment.FormattingEnabled = true;
            this.COMBOB_EmployeeSubDepartment.Location = new System.Drawing.Point(315, 9);
            this.COMBOB_EmployeeSubDepartment.Name = "COMBOB_EmployeeSubDepartment";
            this.COMBOB_EmployeeSubDepartment.Size = new System.Drawing.Size(150, 21);
            this.COMBOB_EmployeeSubDepartment.TabIndex = 2;
            this.COMBOB_EmployeeSubDepartment.SelectedValueChanged += new System.EventHandler(this.COMBOB_EmployeeSubDepartment_SelectedValueChanged);
            // 
            // COMBOB_EmployeeDepartment
            // 
            this.COMBOB_EmployeeDepartment.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_EmployeeDepartment.FormattingEnabled = true;
            this.COMBOB_EmployeeDepartment.Location = new System.Drawing.Point(159, 9);
            this.COMBOB_EmployeeDepartment.Name = "COMBOB_EmployeeDepartment";
            this.COMBOB_EmployeeDepartment.Size = new System.Drawing.Size(150, 21);
            this.COMBOB_EmployeeDepartment.TabIndex = 1;
            this.COMBOB_EmployeeDepartment.SelectedValueChanged += new System.EventHandler(this.COMBOB_EmployeeDepartment_SelectedValueChanged);
            // 
            // COMBOB_EmployeeCompany
            // 
            this.COMBOB_EmployeeCompany.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.COMBOB_EmployeeCompany.FormattingEnabled = true;
            this.COMBOB_EmployeeCompany.Location = new System.Drawing.Point(3, 10);
            this.COMBOB_EmployeeCompany.Name = "COMBOB_EmployeeCompany";
            this.COMBOB_EmployeeCompany.Size = new System.Drawing.Size(150, 21);
            this.COMBOB_EmployeeCompany.TabIndex = 0;
            this.COMBOB_EmployeeCompany.SelectedValueChanged += new System.EventHandler(this.COMBOB_EmployeeCompany_SelectedValueChanged);
            // 
            // employeeListTableAdapter
            // 
            this.employeeListTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.EarningsDeductionTableAdapter = null;
            this.tableAdapterManager.EmployeeListTableAdapter = this.employeeListTableAdapter;
            this.tableAdapterManager.UpdateOrder = LEC_201.LecDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "EmployeeNumber";
            this.dataGridViewTextBoxColumn1.Frozen = true;
            this.dataGridViewTextBoxColumn1.HeaderText = "EMPLOYEE NUMBER";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 120;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "LastName";
            this.dataGridViewTextBoxColumn2.Frozen = true;
            this.dataGridViewTextBoxColumn2.HeaderText = "LAST NAME";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 120;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "FirstName";
            this.dataGridViewTextBoxColumn3.Frozen = true;
            this.dataGridViewTextBoxColumn3.HeaderText = "FIRST NAME";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 120;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "MiddleName";
            this.dataGridViewTextBoxColumn4.HeaderText = "MIDDLE NAME";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 120;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "NickName";
            this.dataGridViewTextBoxColumn5.HeaderText = "NICK NAME";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 120;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "BirthDate";
            this.dataGridViewTextBoxColumn6.HeaderText = "BIRTH DATE";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 120;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "BirthPlace";
            this.dataGridViewTextBoxColumn7.HeaderText = "BIRTH PLACE";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 120;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Address";
            this.dataGridViewTextBoxColumn8.HeaderText = "ADDRESS";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 250;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "ContactNumber";
            this.dataGridViewTextBoxColumn9.HeaderText = "CONTACT NUMBER";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 120;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "CivilStatus";
            this.dataGridViewTextBoxColumn10.HeaderText = "CIVIL STATUS";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 120;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Mother";
            this.dataGridViewTextBoxColumn11.HeaderText = "MOTHER\'s NAME";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 120;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Father";
            this.dataGridViewTextBoxColumn12.HeaderText = "FATHER\'s NAME";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 120;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Company";
            this.dataGridViewTextBoxColumn13.HeaderText = "COMPANY";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 120;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Department";
            this.dataGridViewTextBoxColumn14.HeaderText = "DEPARTMENT";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 120;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "SubDepartment";
            this.dataGridViewTextBoxColumn15.HeaderText = "SUB DEPARTMENT";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 120;
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "Position";
            this.dataGridViewTextBoxColumn16.HeaderText = "POSITION";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 120;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "DateHired";
            this.dataGridViewTextBoxColumn17.HeaderText = "DATE HIRED";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 120;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "EmploymentStatus";
            this.dataGridViewTextBoxColumn18.HeaderText = "EMPLOYMENT STATUS";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 120;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "DateSeparated";
            this.dataGridViewTextBoxColumn19.HeaderText = "DATE SEPARATED";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 120;
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Salary";
            this.dataGridViewTextBoxColumn20.HeaderText = "SALARY";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            this.dataGridViewTextBoxColumn20.Width = 120;
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "SalaryType";
            this.dataGridViewTextBoxColumn21.HeaderText = "SALARY TYPE";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            this.dataGridViewTextBoxColumn21.Width = 120;
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "TIN";
            this.dataGridViewTextBoxColumn22.HeaderText = "TIN";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            this.dataGridViewTextBoxColumn22.Width = 120;
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "SSS";
            this.dataGridViewTextBoxColumn23.HeaderText = "SSS";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            this.dataGridViewTextBoxColumn23.Width = 120;
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Philhealth";
            this.dataGridViewTextBoxColumn24.HeaderText = "PHILHEALTH";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            this.dataGridViewTextBoxColumn24.Width = 120;
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Pagibig";
            this.dataGridViewTextBoxColumn25.HeaderText = "PAGIBIG";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            this.dataGridViewTextBoxColumn25.Width = 120;
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Maroon;
            this.ClientSize = new System.Drawing.Size(989, 561);
            this.ControlBox = false;
            this.Controls.Add(this.PNL_HomeEmployee);
            this.Controls.Add(this.PNL_HomeLogin);
            this.Controls.Add(this.PNL_HomeMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.ImeMode = System.Windows.Forms.ImeMode.On;
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "Home";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LEC 201 | Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Home_KeyDown);
            this.PNL_HomeMenu.ResumeLayout(false);
            this.PNL_HomeLogin.ResumeLayout(false);
            this.PNL_HomeLogin.PerformLayout();
            this.PNL_HomeEmployee.ResumeLayout(false);
            this.PNL_HomeEmployee.PerformLayout();
            this.PNL_DGVcolumns.ResumeLayout(false);
            this.PNL_DGVcolumns.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingNavigator)).EndInit();
            this.employeeListBindingNavigator.ResumeLayout(false);
            this.employeeListBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lecDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeListDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel PNL_HomeMenu;
        private System.Windows.Forms.Button BTN_HomeLogin;
        private System.Windows.Forms.Button BTN_HomeExit;
        private System.Windows.Forms.Panel PNL_HomeLogin;
        private System.Windows.Forms.TextBox TXTB_LoginUsername;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox TXTB_LoginPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button BTN_LoginCancel;
        private System.Windows.Forms.Button BTN_LoginOk;
        private System.Windows.Forms.Panel PNL_HomeEmployee;
        private System.Windows.Forms.Button BTN_HomeEmployee;
        private System.Windows.Forms.ComboBox COMBOB_EmployeeCompany;
        private System.Windows.Forms.Button BTN_EmployeeSearch;
        private System.Windows.Forms.ComboBox COMBOB_EmployeeSubDepartment;
        private System.Windows.Forms.ComboBox COMBOB_EmployeeDepartment;
        private System.Windows.Forms.TextBox TXTB_EmployeeSearch;
        private System.Windows.Forms.Button BTN_EmployeeClose;
        private System.Windows.Forms.Button BTN_HomeID;
        private System.Windows.Forms.Button BTN_Hiring;
        private LecDataSet lecDataSet;
        private System.Windows.Forms.BindingSource employeeListBindingSource;
        private LecDataSetTableAdapters.EmployeeListTableAdapter employeeListTableAdapter;
        private LecDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator employeeListBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton EmployeeListBindingNavigatorSaveItem;
        private System.Windows.Forms.ToolStripButton BTN_AddEmployee;
        private System.Windows.Forms.DataGridView employeeListDataGridView;
        private System.Windows.Forms.Panel PNL_DGVcolumns;
        private System.Windows.Forms.CheckBox CB_Pagibig;
        private System.Windows.Forms.CheckBox CB_Philhealth;
        private System.Windows.Forms.CheckBox CB_Sss;
        private System.Windows.Forms.CheckBox CB_Tin;
        private System.Windows.Forms.CheckBox CB_SalaryType;
        private System.Windows.Forms.CheckBox CB_Salary;
        private System.Windows.Forms.CheckBox CB_DateSeparated;
        private System.Windows.Forms.CheckBox CB_EmploymentStatus;
        private System.Windows.Forms.CheckBox CB_DateHired;
        private System.Windows.Forms.CheckBox CB_Position;
        private System.Windows.Forms.CheckBox CB_SubDepartment;
        private System.Windows.Forms.CheckBox CB_Department;
        private System.Windows.Forms.CheckBox CB_Company;
        private System.Windows.Forms.CheckBox CB_Father;
        private System.Windows.Forms.CheckBox CB_Mother;
        private System.Windows.Forms.CheckBox CB_CivilStatus;
        private System.Windows.Forms.CheckBox CB_ContactNumber;
        private System.Windows.Forms.CheckBox CB_Address;
        private System.Windows.Forms.CheckBox CB_BirthPlace;
        private System.Windows.Forms.CheckBox CB_BirthDate;
        private System.Windows.Forms.CheckBox CB_NickName;
        private System.Windows.Forms.CheckBox CB_MiddleName;
        private System.Windows.Forms.Button BTN_DGVcolumns;
        private System.Windows.Forms.Button BTN_DGVexport;
        private System.Windows.Forms.ComboBox COMBOB_BirthdaySearch;
        private System.Windows.Forms.ToolStripButton BTN_EditEmployee;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
    }
}

