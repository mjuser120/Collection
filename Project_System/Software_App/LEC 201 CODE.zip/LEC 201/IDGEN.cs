﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ID_GENERATOR
{
    public partial class IDGEN : Form
    {
        public IDGEN()
        {
            InitializeComponent();
        }

        private void BTN_HomeCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BTN_HomeOk_Click(object sender, EventArgs e)
        {
            if (COMBOB_HomeCompany.Text == "LEC - Workers")
            {
                this.Close();
                LECW LECW = new LECW();
                LECW.ShowDialog();
            }
            else if (COMBOB_HomeCompany.Text == "BAI - Workers")
            {
                this.Close();
                BAIW BAIW = new BAIW();
                BAIW.ShowDialog();
            }
            else if (COMBOB_HomeCompany.Text == "LEC - Office")
            {
                this.Close();
                LECO LECO = new LECO();
                LECO.ShowDialog();
            }
            else if (COMBOB_HomeCompany.Text == "BAI - Office")
            {
                this.Close();
                BAIO BAIO = new BAIO();
                BAIO.ShowDialog();
            }
        }

        private void Home_Load(object sender, EventArgs e)
        {
            //BY: JEP PACHECO
        }

        private void Home_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && e.Shift && e.KeyCode == Keys.J)
            {
                MessageBox.Show("CREATED BY: JEP PACHECO", "PROGRAMMER", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }

        private void BTN_Open_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            System.Diagnostics.Process.Start(StringPathSave);
        }
    }
}
