﻿namespace ID_GENERATOR
{
    partial class BAIW
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BAIW));
            this.PNL_IDpreview = new System.Windows.Forms.Panel();
            this.LBL_Fullname = new System.Windows.Forms.Label();
            this.LBL_Position = new System.Windows.Forms.Label();
            this.LBL_ID = new System.Windows.Forms.Label();
            this.LBL_DateIssued = new System.Windows.Forms.Label();
            this.LBL_ExpirationDate = new System.Windows.Forms.Label();
            this.TXTB_FullName = new System.Windows.Forms.TextBox();
            this.TXTB_Position = new System.Windows.Forms.TextBox();
            this.TXTB_ID = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.TXTB_DateIssued = new System.Windows.Forms.TextBox();
            this.TXTB_ExpirationDate = new System.Windows.Forms.TextBox();
            this.BTN_Generate = new System.Windows.Forms.Button();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PNL_IDpreview.SuspendLayout();
            this.SuspendLayout();
            // 
            // PNL_IDpreview
            // 
            this.PNL_IDpreview.BackgroundImage = global::LEC_201.Properties.Resources.BAIWORKERS;
            this.PNL_IDpreview.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.PNL_IDpreview.Controls.Add(this.LBL_ExpirationDate);
            this.PNL_IDpreview.Controls.Add(this.LBL_DateIssued);
            this.PNL_IDpreview.Controls.Add(this.LBL_ID);
            this.PNL_IDpreview.Controls.Add(this.LBL_Position);
            this.PNL_IDpreview.Controls.Add(this.LBL_Fullname);
            this.PNL_IDpreview.Location = new System.Drawing.Point(17, 120);
            this.PNL_IDpreview.Name = "PNL_IDpreview";
            this.PNL_IDpreview.Size = new System.Drawing.Size(644, 507);
            this.PNL_IDpreview.TabIndex = 0;
            // 
            // LBL_Fullname
            // 
            this.LBL_Fullname.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Fullname.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Fullname.ForeColor = System.Drawing.Color.Black;
            this.LBL_Fullname.Location = new System.Drawing.Point(63, 344);
            this.LBL_Fullname.Name = "LBL_Fullname";
            this.LBL_Fullname.Size = new System.Drawing.Size(252, 30);
            this.LBL_Fullname.TabIndex = 0;
            this.LBL_Fullname.Text = "FULL NAME";
            this.LBL_Fullname.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_Position
            // 
            this.LBL_Position.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Position.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Position.ForeColor = System.Drawing.Color.Black;
            this.LBL_Position.Location = new System.Drawing.Point(63, 374);
            this.LBL_Position.Name = "LBL_Position";
            this.LBL_Position.Size = new System.Drawing.Size(252, 30);
            this.LBL_Position.TabIndex = 1;
            this.LBL_Position.Text = "POSITION";
            this.LBL_Position.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_ID
            // 
            this.LBL_ID.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ID.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ID.ForeColor = System.Drawing.Color.Blue;
            this.LBL_ID.Location = new System.Drawing.Point(63, 404);
            this.LBL_ID.Name = "LBL_ID";
            this.LBL_ID.Size = new System.Drawing.Size(252, 30);
            this.LBL_ID.TabIndex = 2;
            this.LBL_ID.Text = "ID NO: 0000-00";
            this.LBL_ID.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_DateIssued
            // 
            this.LBL_DateIssued.BackColor = System.Drawing.Color.Transparent;
            this.LBL_DateIssued.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_DateIssued.ForeColor = System.Drawing.Color.Black;
            this.LBL_DateIssued.Location = new System.Drawing.Point(505, 226);
            this.LBL_DateIssued.Name = "LBL_DateIssued";
            this.LBL_DateIssued.Size = new System.Drawing.Size(122, 30);
            this.LBL_DateIssued.TabIndex = 3;
            this.LBL_DateIssued.Text = "DATE";
            this.LBL_DateIssued.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // LBL_ExpirationDate
            // 
            this.LBL_ExpirationDate.BackColor = System.Drawing.Color.Transparent;
            this.LBL_ExpirationDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_ExpirationDate.ForeColor = System.Drawing.Color.Black;
            this.LBL_ExpirationDate.Location = new System.Drawing.Point(505, 265);
            this.LBL_ExpirationDate.Name = "LBL_ExpirationDate";
            this.LBL_ExpirationDate.Size = new System.Drawing.Size(122, 30);
            this.LBL_ExpirationDate.TabIndex = 4;
            this.LBL_ExpirationDate.Text = "DATE";
            this.LBL_ExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // TXTB_FullName
            // 
            this.TXTB_FullName.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_FullName.Location = new System.Drawing.Point(182, 12);
            this.TXTB_FullName.Name = "TXTB_FullName";
            this.TXTB_FullName.Size = new System.Drawing.Size(150, 25);
            this.TXTB_FullName.TabIndex = 1;
            this.TXTB_FullName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_FullName_KeyPress);
            // 
            // TXTB_Position
            // 
            this.TXTB_Position.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_Position.Location = new System.Drawing.Point(182, 43);
            this.TXTB_Position.Name = "TXTB_Position";
            this.TXTB_Position.Size = new System.Drawing.Size(150, 25);
            this.TXTB_Position.TabIndex = 2;
            this.TXTB_Position.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_Position_KeyPress);
            // 
            // TXTB_ID
            // 
            this.TXTB_ID.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ID.Location = new System.Drawing.Point(182, 74);
            this.TXTB_ID.Name = "TXTB_ID";
            this.TXTB_ID.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ID.TabIndex = 3;
            this.TXTB_ID.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ID_KeyPress);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(92, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "FULL NAME:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(103, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "POSITION:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(92, 77);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "ID NUMBER:";
            // 
            // TXTB_DateIssued
            // 
            this.TXTB_DateIssued.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_DateIssued.Location = new System.Drawing.Point(349, 12);
            this.TXTB_DateIssued.Name = "TXTB_DateIssued";
            this.TXTB_DateIssued.Size = new System.Drawing.Size(150, 25);
            this.TXTB_DateIssued.TabIndex = 7;
            this.TXTB_DateIssued.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_DateIssued_KeyPress);
            // 
            // TXTB_ExpirationDate
            // 
            this.TXTB_ExpirationDate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_ExpirationDate.Location = new System.Drawing.Point(349, 43);
            this.TXTB_ExpirationDate.Name = "TXTB_ExpirationDate";
            this.TXTB_ExpirationDate.Size = new System.Drawing.Size(150, 25);
            this.TXTB_ExpirationDate.TabIndex = 8;
            this.TXTB_ExpirationDate.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_ExpirationDate_KeyPress);
            // 
            // BTN_Generate
            // 
            this.BTN_Generate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Generate.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Generate.Location = new System.Drawing.Point(349, 74);
            this.BTN_Generate.Name = "BTN_Generate";
            this.BTN_Generate.Size = new System.Drawing.Size(70, 25);
            this.BTN_Generate.TabIndex = 9;
            this.BTN_Generate.Text = "GENERATE";
            this.BTN_Generate.UseVisualStyleBackColor = true;
            this.BTN_Generate.Click += new System.EventHandler(this.BTN_Generate_Click);
            // 
            // BTN_Save
            // 
            this.BTN_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Save.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Save.Location = new System.Drawing.Point(429, 74);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(70, 25);
            this.BTN_Save.TabIndex = 10;
            this.BTN_Save.Text = "SAVE";
            this.BTN_Save.UseVisualStyleBackColor = true;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(505, 15);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 17);
            this.label4.TabIndex = 11;
            this.label4.Text = "DATE ISSUED";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(505, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(121, 17);
            this.label5.TabIndex = 12;
            this.label5.Text = "EXPIRATION DATE";
            // 
            // BAIW
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(679, 649);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.BTN_Save);
            this.Controls.Add(this.BTN_Generate);
            this.Controls.Add(this.TXTB_ExpirationDate);
            this.Controls.Add(this.TXTB_DateIssued);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TXTB_ID);
            this.Controls.Add(this.TXTB_Position);
            this.Controls.Add(this.TXTB_FullName);
            this.Controls.Add(this.PNL_IDpreview);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimizeBox = false;
            this.Name = "BAIW";
            this.Text = "ID GENERATOR | BAI Workers";
            this.Load += new System.EventHandler(this.BAIW_Load);
            this.PNL_IDpreview.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel PNL_IDpreview;
        private System.Windows.Forms.Label LBL_ExpirationDate;
        private System.Windows.Forms.Label LBL_DateIssued;
        private System.Windows.Forms.Label LBL_ID;
        private System.Windows.Forms.Label LBL_Position;
        private System.Windows.Forms.Label LBL_Fullname;
        private System.Windows.Forms.TextBox TXTB_FullName;
        private System.Windows.Forms.TextBox TXTB_Position;
        private System.Windows.Forms.TextBox TXTB_ID;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TXTB_DateIssued;
        private System.Windows.Forms.TextBox TXTB_ExpirationDate;
        private System.Windows.Forms.Button BTN_Generate;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}