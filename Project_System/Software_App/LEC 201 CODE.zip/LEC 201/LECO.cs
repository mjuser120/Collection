﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ID_GENERATOR
{
    public partial class LECO : Form
    {
        public LECO()
        {
            InitializeComponent();
        }

        private void LECO_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lecDataSet.EmployeeList' table. You can move, or remove it, as needed.
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
            TEXTB_SearchEmployeeNumber.Text = "Employee Number..";
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }

        private void employeeListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeListBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.lecDataSet);

        }

        private void BTN_EmployeeNumber_Click(object sender, EventArgs e)
        {
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
            int RowCount = employeeListDataGridView.Rows.Count;
            if (RowCount == 2)
            {
                string S_FirstName = employeeListDataGridView.Rows[0].Cells[2].Value.ToString().Trim();
                string S_LastName = employeeListDataGridView.Rows[0].Cells[1].Value.ToString().Trim();
                string S_IdNumber = employeeListDataGridView.Rows[0].Cells[0].Value.ToString().Trim();
                string S_BirthDate = employeeListDataGridView.Rows[0].Cells[5].Value.ToString().Trim();
                string S_Address = employeeListDataGridView.Rows[0].Cells[7].Value.ToString().Trim();
                string S_Company = employeeListDataGridView.Rows[0].Cells[12].Value.ToString().Trim();
                string S_Position = employeeListDataGridView.Rows[0].Cells[15].Value.ToString().Trim();
                DateTime ExpirationDate = DateTime.Today;
                string S_Expiration = "DEC-31-" + ExpirationDate.ToString("yyyy");
                LBL_Fullname.Text = S_FirstName + " " + S_LastName;
                LBL_Position.Text = S_Position;
                LBL_ID.Text = S_IdNumber;
                LBL_Birthday.Text = S_BirthDate;
                LBL_Address.Text = S_Address;
                LBL_ExpirationDate.Text = S_Expiration;
                string StringPicturePath = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                string StringPathPicture = StringPicturePath + S_IdNumber + ".jpg";
                PICB_Photo.Image = Image.FromFile(StringPathPicture);
                PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
                string StringPathSignature = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
                if (S_Company == "NIL")
                {
                    LBL_CompanyInitials.Text = "NA";
                    LBL_CompanyBack.Text = "A B A N G G A N";
                    LBL_Signatory.Text = "NILO ABANGAN";
                    PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\NA.png");
                    PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else if (S_Company == "JOL")
                {
                    LBL_CompanyInitials.Text = "JE";
                    LBL_CompanyBack.Text = "E S P A R E S";
                    LBL_Signatory.Text = "JOEL ESPARES";
                    PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\JE.png");
                    PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else if (S_Company == "JOV")
                {
                    LBL_CompanyInitials.Text = "JS";
                    LBL_CompanyBack.Text = "S A L A Q U I N";
                    LBL_Signatory.Text = "JOVER SALAQUIN";
                    PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\JS.png");
                    PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else if (S_Company == "MAR")
                {
                    LBL_CompanyInitials.Text = "MP";
                    LBL_CompanyBack.Text = "P A N G A N I B A N";
                    LBL_Signatory.Text = "MARIANO PANGANIBAN";
                    PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\MP.png");
                    PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else if (S_Company == "LEC")
                {
                    LBL_CompanyInitials.Text = "LEC";
                    LBL_CompanyBack.Text = "L E C S T E E L";
                    LBL_Signatory.Text = "LOUIE MEDINA";
                    PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\LEC.png");
                    PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                }
            }
            else
            {
                MessageBox.Show("No record found!", "Search Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            if (LBL_CompanyInitials.Text == "-")
            {
                MessageBox.Show("Choose Company!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string StringFileName = LBL_ID.Text + "_" + LBL_Fullname.Text;
                StringFileName = StringFileName.Replace(",", "");
                StringFileName = StringFileName.Replace(".", "");
                int width = 643;
                int height = 506;
                Bitmap bitMap = new Bitmap(width, height);
                bitMap.SetResolution(150, 150);
                Rectangle rec = new Rectangle(0, 0, width, height);
                PNL_IDpreview.DrawToBitmap(bitMap, rec);
                bitMap.Save(StringPathSave + "LEC OFFICE\\" + StringFileName + ".png", ImageFormat.Png);
                MessageBox.Show("ID GENERATED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                System.Diagnostics.Process.Start(StringPathSave + "LEC OFFICE\\");
                LBL_Fullname.Text = "FULL NAME";
                LBL_Position.Text = "POSITION";
                LBL_ID.Text = "ID NO:";
                LBL_Birthday.Text = "01-01-2023";
                LBL_Address.Text = "A.Bonifacio Ave. Cor. Ligaya St. Balintawak, Quezon City";
                LBL_ExpirationDate.Text = "EXPIRATION DATE";
                PICB_Photo.Image = PICB_Photo.InitialImage;
                PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
                LBL_CompanyInitials.Text = "-";
                LBL_CompanyBack.Text = "C O M P A N Y";
                LBL_Signatory.Text = "SIGNATURE";
                PICB_Signature.Image = PICB_Signature.InitialImage;
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void TEXTB_SearchEmployeeNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_EmployeeNumber.PerformClick();
            }
        }

        private void TEXTB_SearchEmployeeNumber_Click(object sender, EventArgs e)
        {
            if (TEXTB_SearchEmployeeNumber.Text == "Employee Number..")
            {
                TEXTB_SearchEmployeeNumber.Text = "";
            }
        }

        /*private void BTN_Generate_Click(object sender, EventArgs e)
        {
            string StringPathSignature = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            string StringFullname = TXTB_Fullname.Text.ToUpper();
            string StringPosition = TXTB_Position.Text.ToUpper();
            string StringID = TXTB_ID.Text.ToUpper();
            string StringBirthday = TXTB_Birthday.Text.ToUpper();
            string StringAddress = TXTB_Address.Text;
            string StringExpirationDate = TXTB_ExpirationDate.Text.ToUpper();
            string StringPicturePath = TXTB_PicturePath.Text;
            if (COMBOB_Company.Text == "NA - Nilo Abanggan")
            {
                LBL_CompanyInitials.Text = "NA";
                LBL_CompanyBack.Text = "A B A N G G A N";
                LBL_Signatory.Text = "NILO ABANGAN";
                PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\NA.png");
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else if (COMBOB_Company.Text == "JE - Joel Espares")
            {
                LBL_CompanyInitials.Text = "JE";
                LBL_CompanyBack.Text = "E S P A R E S";
                LBL_Signatory.Text = "JOEL ESPARES";
                PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\JE.png");
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else if (COMBOB_Company.Text == "JS - Jover Salaquin")
            {
                LBL_CompanyInitials.Text = "JS";
                LBL_CompanyBack.Text = "S A L A Q U I N";
                LBL_Signatory.Text = "JOVER SALAQUIN";
                PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\JS.png");
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else if (COMBOB_Company.Text == "MP -Mariano Panganiban")
            {
                LBL_CompanyInitials.Text = "MP";
                LBL_CompanyBack.Text = "P A N G A N I B A N";
                LBL_Signatory.Text = "MARIANO PANGANIBAN";
                PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\MP.png");
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
            else if (COMBOB_Company.Text == "LEC - LEC Steel")
            {
                LBL_CompanyInitials.Text = "LEC";
                LBL_CompanyBack.Text = "L E C S T E E L";
                LBL_Signatory.Text = "LOUIE MEDINA";
                PICB_Signature.Image = Image.FromFile(StringPathSignature + "SIGNATURES\\LEC.png");
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
            }
            LBL_Fullname.Text = StringFullname;
            LBL_Position.Text = StringPosition;
            LBL_ID.Text = StringID;
            LBL_Birthday.Text = StringBirthday;
            LBL_Address.Text = StringAddress;
            LBL_ExpirationDate.Text = StringExpirationDate;
            if (StringPicturePath != "")
            {
                PICB_Photo.Image = Image.FromFile(StringPicturePath);
                PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
            }
        }

        private void BTN_BrowsePicture_Click(object sender, EventArgs e)
        {
            OpenFileDialog choofdlog = new OpenFileDialog
            {
                Filter = "Images (*.BMP;*.JPG;*.PNG)|*.BMP;*.JPG;*.PNG|" + "All files (*.*)|*.*",
                FilterIndex = 1,
                Multiselect = false,
                Title = "Choose ID Photo:"
            };
            if (choofdlog.ShowDialog() == DialogResult.OK)
            {
                string sFileName = choofdlog.FileName;
                //string[] arrAllFiles = choofdlog.FileNames; //used when Multiselect = true
                TXTB_PicturePath.Text = sFileName;
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            if (LBL_CompanyInitials.Text == "-")
            {
                MessageBox.Show("Choose Company!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string StringFileName = TXTB_Fullname.Text.ToUpper();
                StringFileName = StringFileName.Replace(",", "");
                StringFileName = StringFileName.Replace(".", "");
                int width = 643;
                int height = 506;
                Bitmap bitMap = new Bitmap(width, height);
                bitMap.SetResolution(150, 150);
                Rectangle rec = new Rectangle(0, 0, width, height);
                PNL_IDpreview.DrawToBitmap(bitMap, rec);
                bitMap.Save(StringPathSave + "LEC OFFICE\\" + StringFileName + ".png", ImageFormat.Png);
                MessageBox.Show("ID GENERATED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                System.Diagnostics.Process.Start(StringPathSave + "LEC OFFICE\\");
                LBL_Fullname.Text = "FULL NAME";
                LBL_Position.Text = "POSITION";
                LBL_ID.Text = "ID NO:";
                LBL_Birthday.Text = "01-01-2023";
                LBL_Address.Text = "A.Bonifacio Ave. Cor. Ligaya St. Balintawak, Quezon City";
                LBL_ExpirationDate.Text = "EXPIRATION DATE";
                PICB_Photo.Image = PICB_Photo.InitialImage;
                PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
                LBL_CompanyInitials.Text = "-";
                LBL_CompanyBack.Text = "C O M P A N Y";
                LBL_Signatory.Text = "SIGNATURE";
                PICB_Signature.Image = PICB_Signature.InitialImage;
                PICB_Signature.SizeMode = PictureBoxSizeMode.Zoom;
                TXTB_Fullname.Text = "";
                TXTB_Position.Text = "";
                TXTB_ID.Text = "";
                TXTB_Birthday.Text = "";
                TXTB_Address.Text = "";
                TXTB_ExpirationDate.Text = "";
                TXTB_PicturePath.Text = "";
            }
        }

        private void TXTB_Fullname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Position.Focus();
            }
        }

        private void TXTB_Position_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ID.Focus();
            }
        }

        private void TXTB_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Birthday.Focus();
            }
        }

        private void TXTB_Birthday_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Address.Focus();
            }
        }

        private void TXTB_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ExpirationDate.Focus();
            }
        }

        private void TXTB_ExpirationDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_PicturePath.Focus();
            }
        }

        private void TXTB_PicturePath_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_Browse.PerformClick();
            }
        }

        private void LECO_Load(object sender, EventArgs e)
        {

        }*/
    }
}
