﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LEC_201
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
        }
        LecDataSetTableAdapters.EmployeeListTableAdapter AddNewEmployee = new LecDataSetTableAdapters.EmployeeListTableAdapter();
        LecDataSetTableAdapters.EarningsDeductionTableAdapter AddEarningsDeductions = new LecDataSetTableAdapters.EarningsDeductionTableAdapter();
        private void AddEmployee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lecDataSet.EarningsDeduction' table. You can move, or remove it, as needed.
            this.earningsDeductionTableAdapter.Fill(this.lecDataSet.EarningsDeduction);
            // TODO: This line of code loads data into the 'lecDataSet.EmployeeList' table. You can move, or remove it, as needed.
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
            PNL_EmploymentDetails.Enabled = true;
            PNL_EmployeeDetails.Enabled = false;
            TEXTB_Position.Text = "";
            COMBOB_Company.Text = "Choose Company..";
            COMBOB_Department.Text = "Choose Department..";
            COMBOB_SubDepartment.Text = "Choose SubDepartment";
            string StringPath = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            string[] StringCompanyReader = File.ReadAllLines(StringPath + "CompanyList.c", Encoding.UTF8);
            COMBOB_Company.Items.Clear();
            COMBOB_Company.Items.AddRange(StringCompanyReader);
        }

        private void COMBOB_Company_SelectedValueChanged(object sender, EventArgs e)
        {
            string StringPathCompany = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            COMBOB_Department.Items.Clear();
            COMBOB_SubDepartment.Items.Clear();
            COMBOB_Department.Text = "Choose Department..";
            COMBOB_SubDepartment.Text = "Choose SubDepartment..";
            string StringCompany = COMBOB_Company.Text;
            string StringDepartment = COMBOB_Company.Text + "List.c";
            string[] StringDepartmentReader = File.ReadAllLines(StringPathCompany + StringCompany + "\\" + StringDepartment, Encoding.UTF8);
            COMBOB_Department.Items.AddRange(StringDepartmentReader);
        }

        private void COMBOB_Department_SelectedValueChanged(object sender, EventArgs e)
        {
            string StringHead = COMBOB_Department.Text;
            string StringPathDepartment = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8);
            COMBOB_SubDepartment.Items.Clear();
            COMBOB_SubDepartment.Text = "Choose SubDepartment..";
            string StringCompany = COMBOB_Company.Text;
            string StringSubDepartment = StringCompany + COMBOB_Department.Text + "List.c";
            string[] StringSubDepartmentReader = File.ReadAllLines(StringPathDepartment + StringCompany + "\\" + StringSubDepartment, Encoding.UTF8);
            COMBOB_SubDepartment.Items.Add(StringHead + " HEAD");
            COMBOB_SubDepartment.Items.AddRange(StringSubDepartmentReader);
        }

        private void BTN_GenerateEmployeeNumber_Click(object sender, EventArgs e)
        {
            string StringCompany = COMBOB_Company.Text;
            string StringDepartment = COMBOB_Department.Text;
            string StringSubDepartment = COMBOB_SubDepartment.Text;
            string StringCurrentYear = DateTime.Now.Year.ToString();
            string StringCompanyNumber = "";
            string StringDepartmentNumber = "";
            string StringSubDepartmentNumber = "";
            int IntEmployeeNumber;
            if (TEXTB_Position.Text == "")
            {
                MessageBox.Show("Must not be empty: POSITION", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (COMBOB_Company.Text == "" || COMBOB_Department.Text == "" || COMBOB_SubDepartment.Text == "")
                {
                    MessageBox.Show("FIELD ERROR: Company / Department / Sub Department", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    //GENERATE CODE HERE
                    if (StringCompany == "LEC")
                    {
                        StringCompanyNumber = "1";
                        if (StringDepartment == "ADMIN")
                        {
                            StringDepartmentNumber = "1";
                            if (StringSubDepartment == "ADMIN HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "HR")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "IT")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "PURCHASING")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: LEC ADMIN");
                            }
                        }
                        else if (StringDepartment == "ACCOUNTING")
                        {
                            StringDepartmentNumber = "2";
                            if (StringSubDepartment == "ACCOUNTING HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "PAYABLES")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "FINANCE")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "CREDIT AND COLLECTION")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: LEC ACCOUNTING");
                            }
                        }
                        else if (StringDepartment == "SALES")
                        {
                            StringDepartmentNumber = "3";
                            if (StringSubDepartment == "SALES HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "SALES")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: LEC SALES");
                            }
                        }
                        else if (StringDepartment == "OPERATIONS")
                        {
                            StringDepartmentNumber = "4";
                            if (StringSubDepartment == "OPERATIONS HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "PROJECT")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "QA/QC")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "RESEARCH AND DEVELOPMENT")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else if (StringSubDepartment == "ROLL UP SERVICE")
                            {
                                StringSubDepartmentNumber = "4";
                            }
                            else if (StringSubDepartment == "ENGINEERING")
                            {
                                StringSubDepartmentNumber = "5";
                            }
                            else if (StringSubDepartment == "WAREHOUSE")
                            {
                                StringSubDepartmentNumber = "6";
                            }
                            else if (StringSubDepartment == "PRODUCTION")
                            {
                                StringSubDepartmentNumber = "7";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: LEC OPERATIONS");
                            }
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: LEC");
                        }
                    }
                    else if (StringCompany == "BAI")
                    {
                        StringCompanyNumber = "2";
                        if (StringDepartment == "ADMIN")
                        {
                            StringDepartmentNumber = "1";
                            if (StringSubDepartment == "ADMIN HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "HR")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "PURCHASING")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "GENERAL SERVICES")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else if (StringSubDepartment == "LOGISTICS")
                            {
                                StringSubDepartmentNumber = "4";
                            }
                            else if (StringSubDepartment == "WAREHOUSE / INVENTORY")
                            {
                                StringSubDepartmentNumber = "5";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: BAI ADMIN");
                            }
                        }
                        else if (StringDepartment == "FINANCE")
                        {
                            StringDepartmentNumber = "2";
                            if (StringSubDepartment == "FINANCE HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "AR")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "AP")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "FS / PAYROLL")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: BAI FINANCE");
                            }
                        }
                        else if (StringDepartment == "SALES")
                        {
                            StringDepartmentNumber = "3";
                            if (StringSubDepartment == "SALES HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if(StringSubDepartment == "SALES")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: BAI SALES");
                            }
                        }
                        else if (StringDepartment == "OPERATIONS")
                        {
                            StringDepartmentNumber = "4";
                            if (StringSubDepartment == "OPERATIONS HEAD")
                            {
                                StringSubDepartmentNumber = "0";
                            }
                            else if (StringSubDepartment == "ENGINEERING")
                            {
                                StringSubDepartmentNumber = "1";
                            }
                            else if (StringSubDepartment == "PROJECTS")
                            {
                                StringSubDepartmentNumber = "2";
                            }
                            else if (StringSubDepartment == "QA/QC")
                            {
                                StringSubDepartmentNumber = "3";
                            }
                            else if (StringSubDepartment == "R & D")
                            {
                                StringSubDepartmentNumber = "4";
                            }
                            else
                            {
                                MessageBox.Show("ERROR IN Sub Department NUMBER: BAI OPERATIONS");
                            }
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: BAI");
                        }
                    }
                    else if (StringCompany == "JOV")
                    {
                        StringCompanyNumber = "3";
                        StringDepartmentNumber = "1";
                        if (StringSubDepartment == "JOV HEAD")
                        {
                            StringSubDepartmentNumber = "0";
                        }
                        else if (StringSubDepartment == "JOV")
                        {
                            StringSubDepartmentNumber = "1";
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: JOV");
                        }
                    }
                    else if (StringCompany == "JOL")
                    {
                        StringCompanyNumber = "4";
                        StringDepartmentNumber = "1";
                        if (StringSubDepartment == "JOL HEAD")
                        {
                            StringSubDepartmentNumber = "0";
                        }
                        else if (StringSubDepartment == "JOL")
                        {
                            StringSubDepartmentNumber = "1";
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: JOL");
                        }
                    }
                    else if (StringCompany == "NIL")
                    {
                        StringCompanyNumber = "5";
                        StringDepartmentNumber = "1";
                        if (StringSubDepartment == "NIL HEAD")
                        {
                            StringSubDepartmentNumber = "0";
                        }
                        else if (StringSubDepartment == "NIL")
                        {
                            StringSubDepartmentNumber = "1";
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: NIL");
                        }
                    }
                    else if (StringCompany == "MAR")
                    {
                        StringCompanyNumber = "6";
                        StringDepartmentNumber = "1";
                        if (StringSubDepartment == "MAR HEAD")
                        {
                            StringSubDepartmentNumber = "0";
                        }
                        else if (StringSubDepartment == "MAR")
                        {
                            StringSubDepartmentNumber = "1";
                        }
                        else
                        {
                            MessageBox.Show("ERROR IN Department NUMBER: MAR");
                        }
                    }
                    else
                    {
                        MessageBox.Show("ERROR IN COMPANY NUMBER");
                    }
                    //GENERATE BUTTON CODE HERE
                    int RowCount;
                    int EmpNumDone = 0;
                    IntEmployeeNumber = 1;
                    string StringEmployeeNumberLabel = "";
                    while (EmpNumDone == 0)
                    {
                        string tempStringEmployeeNumber = StringCurrentYear + "-" + StringCompanyNumber + StringDepartmentNumber + StringSubDepartmentNumber + "-" + IntEmployeeNumber.ToString();
                        //int IntEmployeeNameCount = tempStringEmployeeNumber.Length;
                        //IntEmployeeNameCount = 13 - IntEmployeeNameCount;
                        //int i = IntEmployeeNameCount;
                        //string StringEmployeeNumber = tempStringEmployeeNumber + new string('0', i);
                        string StringEmployeeNumber = tempStringEmployeeNumber;
                        //MessageBox.Show(StringEmployeeNumber);
                        string EmployeeNumberSearch = StringEmployeeNumber.Replace("'", "''");
                        string queryByEmployeeNumber = "(EmployeeNumber LIKE '%" + EmployeeNumberSearch + "%')";
                        StringBuilder joinQuery = new StringBuilder();
                        joinQuery.Append(queryByEmployeeNumber);
                        this.employeeListBindingSource.Filter = joinQuery.ToString();
                        RowCount = employeeListDataGridView.RowCount;
                        //MessageBox.Show(RowCount.ToString());
                        if (RowCount == 1)
                        {
                            EmpNumDone = 1;
                            StringEmployeeNumberLabel = tempStringEmployeeNumber;
                        }
                        else
                        {
                            IntEmployeeNumber++;
                            //MessageBox.Show(StringEmployeeNumberLabel);
                        }
                    }
                    LBL_EmployeeNumber.Text = StringEmployeeNumberLabel;
                    DialogResult ContinueAdd = MessageBox.Show("EMPLOYEE NUMBER: " + StringEmployeeNumberLabel + "\n\nCOMPANY: " + COMBOB_Company.Text + "\nDEPARTMENT: " + COMBOB_Department.Text + "\nSUBDEPARTMENT: " + COMBOB_SubDepartment.Text + "\nPOSITION: " + TEXTB_Position.Text + "\n\nIS THIS CORRECT?", "ADD NEW EMPLOYEE", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                    if (ContinueAdd == DialogResult.Yes)
                    {
                        PNL_EmployeeDetails.Enabled = true;
                        PNL_EmploymentDetails.Enabled = false;
                        LBL_PicturePath.Text = "";
                    }
                    //MessageBox.Show(StringEmployeeNumberLabel);

                    /* OLD GENERATE CODE
                    int RowCount;
                    string StringEmployeeNumber = StringCurrentYear + "-" + StringCompanyNumber + StringDepartmentNumber + StringSubDepartmentNumber + "-" + IntEmployeeNumber.ToString();
                    string EmployeeNumberSearch = StringEmployeeNumber.Replace("'", "''");
                    string queryByEmployeeNumber = "(EmployeeNumber LIKE '%" + EmployeeNumberSearch + "%')";
                    StringBuilder joinQuery = new StringBuilder();
                    joinQuery.Append(queryByEmployeeNumber);
                    this.employeeListBindingSource.Filter = joinQuery.ToString();
                    RowCount = employeeListDataGridView.RowCount;
                    RowCount--;
                    IntEmployeeNumber += RowCount;
                    string StringEmployeeNumberLabel = StringCurrentYear + "-" + StringCompanyNumber + StringDepartmentNumber + StringSubDepartmentNumber + "-" + IntEmployeeNumber.ToString();
                    LBL_EmployeeNumber.Text = StringEmployeeNumberLabel;
                    DialogResult ContinueAdd = MessageBox.Show("EMPLOYEE NUMBER: " + StringEmployeeNumberLabel + "\n\nCOMPANY: " + COMBOB_Company.Text + "\nDEPARTMENT: " + COMBOB_Department.Text + "\nSUBDEPARTMENT: " + COMBOB_SubDepartment.Text + "\nPOSITION: " + TEXTB_Position.Text + "\n\nIS THIS CORRECT?", "ADD NEW EMPLOYEE", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
                    if (ContinueAdd == DialogResult.Yes)
                    {
                        PNL_EmployeeDetails.Enabled = true;
                        PNL_EmploymentDetails.Enabled = false;
                        LBL_PicturePath.Text = "";
                    }*/
                }
            }
        }

        private void employeeListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeListBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.lecDataSet);
        }

        private void BTN_Cancel_Click(object sender, EventArgs e)
        {
            TEXTB_addSurname.Text = "";
            TEXTB_addGivenName.Text = "";
            TEXTB_addMiddleName.Text = "";
            TEXTB_addNickName.Text = "";
            TEXTB_addPresentAddress.Text = "";
            TEXTB_addContact.Text = "";
            TEXTB_addPlaceOfBirth.Text = "";
            TEXTB_addCivilStatus.Text = "";
            TEXTB_addMother.Text = "";
            TEXTB_addFather.Text = "";
            TEXTB_addTinNumber.Text = "";
            TEXTB_addSssNumber.Text = "";
            TEXTB_addPagibigNumber.Text = "";
            TEXTB_addPhilhealthNumber.Text = "";
            TEXTB_addSalary.Text = "";
            COMBOB_SalaryType.Text = "";
            COMBOB_EmployeeStatus.Text = "";
            PNL_EmploymentDetails.Enabled = true;
            PNL_EmployeeDetails.Enabled = false;
        }

        private void BTN_addPicturePath_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFilePath = new OpenFileDialog())
            {
                openFilePath.InitialDirectory = "c:\\";
                openFilePath.Filter = "jpg files (*.jpg)|*.jpg";
                openFilePath.FilterIndex = 2;
                openFilePath.RestoreDirectory = true;
                if (openFilePath.ShowDialog() == DialogResult.OK)
                {
                    LBL_PicturePath.Text = openFilePath.FileName;
                    PICB_addPicture.ImageLocation = LBL_PicturePath.Text;
                    PICB_addPicture.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else
                {
                    LBL_PicturePath.Text = "";
                }
            }
        }

        private void TEXTB_addSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string AddEmployeeNumber = LBL_EmployeeNumber.Text.ToUpper();
            string AddLastName = TEXTB_addSurname.Text.ToUpper();
            string AddFirstName = TEXTB_addGivenName.Text.ToUpper();
            string AddMiddleName = TEXTB_addMiddleName.Text.ToUpper();
            string AddNickName = TEXTB_addNickName.Text.ToUpper();
            DateTime BirthDate = TEXTB_addDateOfBirth.Value.Date;
            string AddBirthDate = BirthDate.ToString("MMM-dd-yyyy").ToUpper();
            string AddBirthPlace = TEXTB_addPlaceOfBirth.Text.ToUpper();
            string AddAddress = TEXTB_addPresentAddress.Text.ToUpper();
            string AddContactNumber = TEXTB_addContact.Text.ToUpper();
            string AddCivilStatus = TEXTB_addCivilStatus.Text.ToUpper();
            string AddMother = TEXTB_addMother.Text.ToUpper();
            string AddFather = TEXTB_addFather.Text.ToUpper();
            string AddCompany = COMBOB_Company.Text.ToUpper();
            string AddDepartment = COMBOB_Department.Text.ToUpper();
            string AddSubDepartment = COMBOB_SubDepartment.Text.ToUpper();
            string AddPosition = TEXTB_Position.Text.ToUpper();
            DateTime DateHired = TEXTB_addDateHired.Value.Date;
            string AddDateHired = DateHired.ToString("MM-dd-yyyy");
            string AddEmploymentStatus = COMBOB_EmployeeStatus.Text.ToUpper();
            string AddDateSeparated = "";
            string AddSalary = TEXTB_addSalary.Text.ToUpper();
            string AddSalaryType = COMBOB_SalaryType.Text.ToUpper();
            string AddTin = TEXTB_addTinNumber.Text.ToUpper();
            string AddSss = TEXTB_addSssNumber.Text.ToUpper();
            string AddPhilhealth = TEXTB_addPhilhealthNumber.Text.ToUpper();
            string AddPagibig = TEXTB_addPagibigNumber.Text.ToUpper();
            string AddFullName = AddLastName + ", " + AddFirstName;
            if (AddLastName != "" || AddFirstName != "" || AddAddress != "")
            {
                //MessageBox.Show(AddBirthDate + "\n" + AddDateHired);
                AddNewEmployee.InsertEmployee(AddEmployeeNumber, AddLastName, AddFirstName, AddMiddleName, AddNickName, AddBirthDate, AddBirthPlace, AddAddress, AddContactNumber, AddCivilStatus, AddMother, AddFather, AddCompany, AddDepartment, AddSubDepartment, AddPosition, AddDateHired, AddEmploymentStatus, AddDateSeparated, AddSalary, AddSalaryType, AddTin, AddSss, AddPhilhealth, AddPagibig);
                AddEarningsDeductions.InsertEarningsDeductions(AddEmployeeNumber, AddFullName, AddPosition, "0", "0", "0", "0", "0", "0", "0", "0");
                if (LBL_PicturePath.Text != "")
                {
                    string PicturePathFrom = LBL_PicturePath.Text;
                    string StringPathPicture = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                    string PicturePathSave = StringPathPicture + AddEmployeeNumber + ".jpg";
                    System.IO.File.Copy(PicturePathFrom, PicturePathSave);
                }
                else
                {
                    string PicturePathFrom = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8) + "DEFAULTPHOTO.jpg";
                    string StringPathPicture = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                    string PicturePathSave = StringPathPicture + AddEmployeeNumber + ".jpg";
                    System.IO.File.Copy(PicturePathFrom, PicturePathSave);
                }
                MessageBox.Show("EMPLOYEE: " + AddEmployeeNumber + "\n\n" + AddLastName + ", " + AddFirstName + " " + AddMiddleName,"SAVE SUCCESSFUL!",MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
                TEXTB_Position.Text = "";
                COMBOB_Company.Text = "";
                COMBOB_Department.Text = "";
                COMBOB_SubDepartment.Text = "";
                LBL_EmployeeNumber.Text = "0000-000-00";
                TEXTB_addSurname.Text = "";
                TEXTB_addGivenName.Text = "";
                TEXTB_addMiddleName.Text = "";
                TEXTB_addNickName.Text = "";
                TEXTB_addPresentAddress.Text = "";
                TEXTB_addContact.Text = "";
                TEXTB_addPlaceOfBirth.Text = "";
                TEXTB_addCivilStatus.Text = "";
                TEXTB_addMother.Text = "";
                TEXTB_addFather.Text = "";
                TEXTB_addTinNumber.Text = "";
                TEXTB_addSssNumber.Text = "";
                TEXTB_addPagibigNumber.Text = "";
                TEXTB_addPhilhealthNumber.Text = "";
                TEXTB_addSalary.Text = "";
                COMBOB_SalaryType.Text = "";
                COMBOB_EmployeeStatus.Text = "";
                LBL_PicturePath.Text = "";
                PICB_addPicture.Image = PICB_addPicture.InitialImage;
                PICB_addPicture.SizeMode = PictureBoxSizeMode.Zoom;
                PNL_EmploymentDetails.Enabled = true;
                PNL_EmployeeDetails.Enabled = false;
            }
            else
            {
                MessageBox.Show("* Must not be empty", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
