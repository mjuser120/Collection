﻿namespace LEC_201
{


    partial class LecDataSet
    {
    }
}

namespace LEC_201.LecDataSetTableAdapters {
    
    
    public partial class EmployeeListTableAdapter {
    }
}
