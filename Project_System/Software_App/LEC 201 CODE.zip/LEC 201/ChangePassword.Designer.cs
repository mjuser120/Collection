﻿namespace LEC_201
{
    partial class ChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangePassword));
            this.TXTB_OldPassword = new System.Windows.Forms.TextBox();
            this.TXTB_NewPassword1 = new System.Windows.Forms.TextBox();
            this.TXTB_NewPassword2 = new System.Windows.Forms.TextBox();
            this.BTN_ChangePasswordOk = new System.Windows.Forms.Button();
            this.BTN_ChangePasswordCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TXTB_OldPassword
            // 
            this.TXTB_OldPassword.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_OldPassword.Location = new System.Drawing.Point(166, 30);
            this.TXTB_OldPassword.Name = "TXTB_OldPassword";
            this.TXTB_OldPassword.PasswordChar = '*';
            this.TXTB_OldPassword.Size = new System.Drawing.Size(150, 22);
            this.TXTB_OldPassword.TabIndex = 0;
            this.TXTB_OldPassword.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_OldPassword_KeyPress);
            // 
            // TXTB_NewPassword1
            // 
            this.TXTB_NewPassword1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_NewPassword1.Location = new System.Drawing.Point(166, 58);
            this.TXTB_NewPassword1.Name = "TXTB_NewPassword1";
            this.TXTB_NewPassword1.PasswordChar = '*';
            this.TXTB_NewPassword1.Size = new System.Drawing.Size(150, 22);
            this.TXTB_NewPassword1.TabIndex = 1;
            this.TXTB_NewPassword1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_NewPassword1_KeyPress);
            // 
            // TXTB_NewPassword2
            // 
            this.TXTB_NewPassword2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_NewPassword2.Location = new System.Drawing.Point(166, 86);
            this.TXTB_NewPassword2.Name = "TXTB_NewPassword2";
            this.TXTB_NewPassword2.PasswordChar = '*';
            this.TXTB_NewPassword2.Size = new System.Drawing.Size(150, 22);
            this.TXTB_NewPassword2.TabIndex = 2;
            this.TXTB_NewPassword2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.TXTB_NewPassword2_KeyPress);
            // 
            // BTN_ChangePasswordOk
            // 
            this.BTN_ChangePasswordOk.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_ChangePasswordOk.Location = new System.Drawing.Point(166, 114);
            this.BTN_ChangePasswordOk.Name = "BTN_ChangePasswordOk";
            this.BTN_ChangePasswordOk.Size = new System.Drawing.Size(70, 23);
            this.BTN_ChangePasswordOk.TabIndex = 3;
            this.BTN_ChangePasswordOk.Text = "OK";
            this.BTN_ChangePasswordOk.UseVisualStyleBackColor = true;
            this.BTN_ChangePasswordOk.Click += new System.EventHandler(this.BTN_ChangePasswordOk_Click);
            // 
            // BTN_ChangePasswordCancel
            // 
            this.BTN_ChangePasswordCancel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_ChangePasswordCancel.Location = new System.Drawing.Point(246, 114);
            this.BTN_ChangePasswordCancel.Name = "BTN_ChangePasswordCancel";
            this.BTN_ChangePasswordCancel.Size = new System.Drawing.Size(70, 23);
            this.BTN_ChangePasswordCancel.TabIndex = 4;
            this.BTN_ChangePasswordCancel.Text = "CANCEL";
            this.BTN_ChangePasswordCancel.UseVisualStyleBackColor = true;
            this.BTN_ChangePasswordCancel.Click += new System.EventHandler(this.BTN_ChangePasswordCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(31, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "ENTER OLD PASSWORD:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(27, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(136, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "ENTER NEW PASSWORD:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(10, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 13);
            this.label3.TabIndex = 7;
            this.label3.Text = "CONFIRM NEW PASSWORD:";
            // 
            // ChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(336, 165);
            this.ControlBox = false;
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_ChangePasswordCancel);
            this.Controls.Add(this.BTN_ChangePasswordOk);
            this.Controls.Add(this.TXTB_NewPassword2);
            this.Controls.Add(this.TXTB_NewPassword1);
            this.Controls.Add(this.TXTB_OldPassword);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ChangePassword";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LEC 201 | Change Password";
            this.Load += new System.EventHandler(this.ChangePassword_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TXTB_OldPassword;
        private System.Windows.Forms.TextBox TXTB_NewPassword1;
        private System.Windows.Forms.TextBox TXTB_NewPassword2;
        private System.Windows.Forms.Button BTN_ChangePasswordOk;
        private System.Windows.Forms.Button BTN_ChangePasswordCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
    }
}