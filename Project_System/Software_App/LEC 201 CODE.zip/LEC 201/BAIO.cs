﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ID_GENERATOR
{
    public partial class BAIO : Form
    {
        public BAIO()
        {
            InitializeComponent();
        }

        private void BTN_Generate_Click(object sender, EventArgs e)
        {
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
            int RowCount = employeeListDataGridView.Rows.Count;
            if (RowCount == 2)
            {
                string StringContactPerson = TXTB_ContactPerson.Text.ToUpper();
                string StringContactNumber = TXTB_ContactNumber.Text.ToUpper();
                if (StringContactPerson != "" || StringContactNumber != "")
                {
                    DateTime ExpirationDate = DateTime.Today;
                    string StringExpirationDate = "DEC-31-" + ExpirationDate.ToString("yyyy");
                    string S_LastName = employeeListDataGridView.Rows[0].Cells[1].Value.ToString().Trim();
                    string S_FirstName = employeeListDataGridView.Rows[0].Cells[2].Value.ToString().Trim();
                    string S_FullName = S_FirstName + " " + S_LastName;
                    string S_Position = employeeListDataGridView.Rows[0].Cells[15].Value.ToString().Trim();
                    string S_NickName = employeeListDataGridView.Rows[0].Cells[4].Value.ToString().Trim();
                    string S_IdNumber = employeeListDataGridView.Rows[0].Cells[0].Value.ToString().Trim();
                    string S_Address = employeeListDataGridView.Rows[0].Cells[7].Value.ToString().Trim();
                    LBL_Fullname.Text = S_FullName;
                    LBL_Position.Text = S_Position;
                    LBL_Nickname.Text = S_NickName;
                    LBL_ID.Text = "ID NO: " + S_IdNumber;
                    LBL_ContactPerson.Text = StringContactPerson;
                    LBL_ContactNumber.Text = StringContactNumber;
                    LBL_Address.Text = S_Address;
                    LBL_ExpirationDate.Text = "This ID is valid until " + StringExpirationDate;
                    string StringPicturePath = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                    string StringPathPicture = StringPicturePath + S_IdNumber + ".jpg";
                    PICB_Photo.Image = Image.FromFile(StringPathPicture);
                    PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
                }
                else
                {
                    MessageBox.Show("ENTER CONTACT PERSON AND CONTACT NUMBER", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            
        }

        private void BTN_Browse_Click(object sender, EventArgs e)
        {
            OpenFileDialog choofdlog = new OpenFileDialog();
            choofdlog.Filter = "Images (*.BMP;*.JPG;*.PNG)|*.BMP;*.JPG;*.PNG|" + "All files (*.*)|*.*";
            choofdlog.FilterIndex = 1;
            choofdlog.Multiselect = false;
            choofdlog.Title = "Choose ID Photo:";
            if (choofdlog.ShowDialog() == DialogResult.OK)
            {
                string sFileName = choofdlog.FileName;
                //string[] arrAllFiles = choofdlog.FileNames; //used when Multiselect = true
                TXTB_PicturePath.Text = sFileName;
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathid.c", Encoding.UTF8);
            if (LBL_Fullname.Text == "FULL NAME")
            {
                MessageBox.Show("NAME MUST NOT BE EMPTY!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string S_IDNumberReplaced = LBL_ID.Text.Replace("ID NO: ", "");
                string StringFileName = S_IDNumberReplaced + "_" + LBL_Fullname.Text;
                int width = 755;
                int height = 555;
                Bitmap bitMap = new Bitmap(width, height);
                bitMap.SetResolution(150, 150);
                Rectangle rec = new Rectangle(0, 0, width, height);
                PNL_IDpreview.DrawToBitmap(bitMap, rec);
                bitMap.Save(StringPathSave + "BAI OFFICE\\" + StringFileName + ".png", ImageFormat.Png);
                MessageBox.Show("ID GENERATED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                System.Diagnostics.Process.Start(StringPathSave + "BAI OFFICE\\");
                LBL_Fullname.Text = "FULL NAME";
                LBL_Position.Text = "POSITION";
                LBL_Nickname.Text = "NICKNAME";
                LBL_ID.Text = "ID NO:";
                LBL_Address.Text = "A.Bonifacio Ave. Cor. Ligaya St. Balintawak, Quezon City";
                LBL_ExpirationDate.Text = "This ID is valid until";
                PICB_Photo.Image = PICB_Photo.InitialImage;
                PICB_Photo.SizeMode = PictureBoxSizeMode.Zoom;
                TXTB_Fullname.Text = "";
                TXTB_Position.Text = "";
                TXTB_Nickname.Text = "";
                TXTB_ContactPerson.Text = "";
                TXTB_ContactNumber.Text = "";
                TXTB_ID.Text = "";
                TXTB_Address.Text = "";
                TXTB_ExpirationDate.Text = "";
                TXTB_PicturePath.Text = "";
                TEXTB_SearchEmployeeNumber.Text = "";
            }
        }

        private void TXTB_Fullname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Position.Focus();
            }
        }

        private void TXTB_Position_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_Nickname.Focus();
            }
        }

        private void TXTB_Nickname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ID.Focus();
            }
        }

        private void TXTB_ID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ContactPerson.Focus();
            }
        }

        private void TXTB_ContactPerson_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ContactNumber.Focus();
            }
        }

        private void TXTB_ContactNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_Generate.PerformClick();
            }
        }

        private void TXTB_Address_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ExpirationDate.Focus();
            }
        }

        private void TXTB_ExpirationDate_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_PicturePath.Focus();
            }
        }

        private void TXTB_PicturePath_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_Browse.PerformClick();
            }
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                TXTB_ContactPerson.Focus();
            }
        }

        private void employeeListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeListBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.lecDataSet);

        }

        private void BAIO_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lecDataSet.EmployeeList' table. You can move, or remove it, as needed.
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
            TEXTB_SearchEmployeeNumber.Text = "";
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }
    }
}
