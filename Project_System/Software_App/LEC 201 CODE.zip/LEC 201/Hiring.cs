﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LECHIRING
{
    public partial class Hiring : Form
    {
        public Hiring()
        {
            InitializeComponent();
        }

        private void Hiring_Load(object sender, EventArgs e)
        {
            TXTB_Context.Text = "";
            TXTB_FontSize.Text = "";
            LBL_Context.Text = "";
        }

        private void BTN_Generate_Click(object sender, EventArgs e)
        {
            TXTB_FontSize.Text = "18";
            LBL_Context.Text = TXTB_Context.Text.ToUpper();
            string StringFontSize = TXTB_FontSize.Text;
            int IntFontSize = Convert.ToInt32(StringFontSize);
            LBL_Context.Font = new Font("Bell MT", IntFontSize, FontStyle.Bold);
        }

        private void BTN_Plus_Click(object sender, EventArgs e)
        {
            string StringFontSize = TXTB_FontSize.Text;
            if (StringFontSize != "")
            {
                int IntFontSize = Convert.ToInt32(StringFontSize);
                IntFontSize = IntFontSize + 1;
                LBL_Context.Font = new Font("Bell MT", IntFontSize, FontStyle.Bold);
                StringFontSize = IntFontSize.ToString();
                TXTB_FontSize.Text = StringFontSize;
            }
        }

        private void BTN_Minus_Click(object sender, EventArgs e)
        {
            string StringFontSize = TXTB_FontSize.Text;
            if (StringFontSize != "")
            {
                int IntFontSize = Convert.ToInt32(StringFontSize);
                IntFontSize = IntFontSize - 1;
                LBL_Context.Font = new Font("Bell MT", IntFontSize, FontStyle.Bold);
                StringFontSize = IntFontSize.ToString();
                TXTB_FontSize.Text = StringFontSize;
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string StringPathSave = File.ReadAllText(@"C:\LEC 201\pathhiring.c", Encoding.UTF8);
            if (LBL_Context.Text != "")
            {
                var DateToday = DateTime.Now;
                string StringFileName = DateToday.ToString("yyyyMMdd hhmmss");
                int width = 424;
                int height = 600;
                Bitmap bitMap = new Bitmap(width, height);
                bitMap.SetResolution(72, 72);
                Rectangle rec = new Rectangle(0, 0, width, height);
                PNL_Hiring.DrawToBitmap(bitMap, rec);
                bitMap.Save(StringPathSave + StringFileName + ".png", ImageFormat.Png);
                MessageBox.Show("SAVED SUCCESSFULLY: " + StringFileName + ".png", "SUCCESS", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                System.Diagnostics.Process.Start(StringPathSave);
                TXTB_Context.Text = "";
                TXTB_FontSize.Text = "";
                LBL_Context.Text = "";
            }
            else
            {
                MessageBox.Show("EMPTY!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BTN_Open_Click(object sender, EventArgs e)
        {
            string StringPathOpen = File.ReadAllText(@"C:\LEC 201\pathhiring.c", Encoding.UTF8);
            System.Diagnostics.Process.Start(StringPathOpen);
        }
    }
}
