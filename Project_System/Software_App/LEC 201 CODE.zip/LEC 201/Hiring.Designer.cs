﻿namespace LECHIRING
{
    partial class Hiring
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Hiring));
            this.TXTB_Context = new System.Windows.Forms.RichTextBox();
            this.BTN_Generate = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TXTB_FontSize = new System.Windows.Forms.TextBox();
            this.BTN_Minus = new System.Windows.Forms.Button();
            this.BTN_Plus = new System.Windows.Forms.Button();
            this.BTN_Save = new System.Windows.Forms.Button();
            this.PNL_Hiring = new System.Windows.Forms.Panel();
            this.LBL_Context = new System.Windows.Forms.Label();
            this.BTN_Open = new System.Windows.Forms.Button();
            this.PNL_Hiring.SuspendLayout();
            this.SuspendLayout();
            // 
            // TXTB_Context
            // 
            this.TXTB_Context.Location = new System.Drawing.Point(12, 32);
            this.TXTB_Context.Name = "TXTB_Context";
            this.TXTB_Context.Size = new System.Drawing.Size(200, 163);
            this.TXTB_Context.TabIndex = 0;
            this.TXTB_Context.Text = "";
            // 
            // BTN_Generate
            // 
            this.BTN_Generate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Generate.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Generate.Location = new System.Drawing.Point(12, 201);
            this.BTN_Generate.Name = "BTN_Generate";
            this.BTN_Generate.Size = new System.Drawing.Size(200, 25);
            this.BTN_Generate.TabIndex = 1;
            this.BTN_Generate.Text = "GENERATE";
            this.BTN_Generate.UseVisualStyleBackColor = true;
            this.BTN_Generate.Click += new System.EventHandler(this.BTN_Generate_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(124, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "ENTER POSITIONS:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(386, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(130, 17);
            this.label2.TabIndex = 4;
            this.label2.Text = "ADJUST FONT SIZE:";
            // 
            // TXTB_FontSize
            // 
            this.TXTB_FontSize.Enabled = false;
            this.TXTB_FontSize.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TXTB_FontSize.Location = new System.Drawing.Point(522, 4);
            this.TXTB_FontSize.Name = "TXTB_FontSize";
            this.TXTB_FontSize.Size = new System.Drawing.Size(59, 25);
            this.TXTB_FontSize.TabIndex = 5;
            // 
            // BTN_Minus
            // 
            this.BTN_Minus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Minus.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Minus.Location = new System.Drawing.Point(587, 4);
            this.BTN_Minus.Name = "BTN_Minus";
            this.BTN_Minus.Size = new System.Drawing.Size(25, 25);
            this.BTN_Minus.TabIndex = 6;
            this.BTN_Minus.Text = "-";
            this.BTN_Minus.UseVisualStyleBackColor = true;
            this.BTN_Minus.Click += new System.EventHandler(this.BTN_Minus_Click);
            // 
            // BTN_Plus
            // 
            this.BTN_Plus.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Plus.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Plus.Location = new System.Drawing.Point(622, 4);
            this.BTN_Plus.Name = "BTN_Plus";
            this.BTN_Plus.Size = new System.Drawing.Size(25, 25);
            this.BTN_Plus.TabIndex = 7;
            this.BTN_Plus.Text = "+";
            this.BTN_Plus.UseVisualStyleBackColor = true;
            this.BTN_Plus.Click += new System.EventHandler(this.BTN_Plus_Click);
            // 
            // BTN_Save
            // 
            this.BTN_Save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Save.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Save.Location = new System.Drawing.Point(12, 603);
            this.BTN_Save.Name = "BTN_Save";
            this.BTN_Save.Size = new System.Drawing.Size(200, 25);
            this.BTN_Save.TabIndex = 8;
            this.BTN_Save.Text = "SAVE";
            this.BTN_Save.UseVisualStyleBackColor = true;
            this.BTN_Save.Click += new System.EventHandler(this.BTN_Save_Click);
            // 
            // PNL_Hiring
            // 
            this.PNL_Hiring.BackgroundImage = global::LEC_201.Properties.Resources.HiringLayout;
            this.PNL_Hiring.Controls.Add(this.LBL_Context);
            this.PNL_Hiring.Location = new System.Drawing.Point(226, 32);
            this.PNL_Hiring.Name = "PNL_Hiring";
            this.PNL_Hiring.Size = new System.Drawing.Size(424, 600);
            this.PNL_Hiring.TabIndex = 3;
            // 
            // LBL_Context
            // 
            this.LBL_Context.BackColor = System.Drawing.Color.Transparent;
            this.LBL_Context.Font = new System.Drawing.Font("Bell MT", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_Context.ForeColor = System.Drawing.Color.White;
            this.LBL_Context.Location = new System.Drawing.Point(3, 169);
            this.LBL_Context.Name = "LBL_Context";
            this.LBL_Context.Size = new System.Drawing.Size(418, 319);
            this.LBL_Context.TabIndex = 0;
            this.LBL_Context.Text = "POSITIONS";
            this.LBL_Context.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BTN_Open
            // 
            this.BTN_Open.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Open.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Open.Location = new System.Drawing.Point(226, 3);
            this.BTN_Open.Name = "BTN_Open";
            this.BTN_Open.Size = new System.Drawing.Size(154, 25);
            this.BTN_Open.TabIndex = 9;
            this.BTN_Open.Text = "OPEN FILE FOLDER";
            this.BTN_Open.UseVisualStyleBackColor = true;
            this.BTN_Open.Click += new System.EventHandler(this.BTN_Open_Click);
            // 
            // Hiring
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(667, 640);
            this.Controls.Add(this.BTN_Open);
            this.Controls.Add(this.BTN_Save);
            this.Controls.Add(this.BTN_Plus);
            this.Controls.Add(this.BTN_Minus);
            this.Controls.Add(this.TXTB_FontSize);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.PNL_Hiring);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_Generate);
            this.Controls.Add(this.TXTB_Context);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Hiring";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "LEC STEEL HIRING";
            this.Load += new System.EventHandler(this.Hiring_Load);
            this.PNL_Hiring.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox TXTB_Context;
        private System.Windows.Forms.Button BTN_Generate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel PNL_Hiring;
        private System.Windows.Forms.Label LBL_Context;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TXTB_FontSize;
        private System.Windows.Forms.Button BTN_Minus;
        private System.Windows.Forms.Button BTN_Plus;
        private System.Windows.Forms.Button BTN_Save;
        private System.Windows.Forms.Button BTN_Open;
    }
}

