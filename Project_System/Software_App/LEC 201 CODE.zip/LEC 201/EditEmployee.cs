﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LEC_201
{
    public partial class EditEmployee : Form
    {
        public EditEmployee()
        {
            InitializeComponent();
        }
        LecDataSetTableAdapters.EmployeeListTableAdapter EditEmployeeDetails = new LecDataSetTableAdapters.EmployeeListTableAdapter();
        private void EditEmployee_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'lecDataSet.EmployeeList' table. You can move, or remove it, as needed.
            this.employeeListTableAdapter.Fill(this.lecDataSet.EmployeeList);
            PNL_EmploymentDetails.Enabled = false;
            PNL_EmployeeDetails.Enabled = false;
            LBL_DateSeparated.Visible = false;
            TEXTB_DateSeparated.Visible = false;
            TEXTB_SearchEmployeeNumber.Text = "Employee Number..";
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }

        private void employeeListBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.employeeListBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.lecDataSet);

        }

        private void BTN_SearcEmployeeNumber_Click(object sender, EventArgs e)
        {
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
            int RowCount = employeeListDataGridView.Rows.Count;
            if (RowCount == 2)
            {
                PNL_EmploymentDetails.Enabled = true;
                PNL_EmployeeDetails.Enabled = true;
                LBL_DateSeparated.Visible = false;
                TEXTB_DateSeparated.Visible = false;
                LBL_EmployeeNumber.Text = employeeListDataGridView.Rows[0].Cells[0].Value.ToString().Trim();
                TEXTB_addSurname.Text = employeeListDataGridView.Rows[0].Cells[1].Value.ToString().Trim();
                TEXTB_addGivenName.Text = employeeListDataGridView.Rows[0].Cells[2].Value.ToString().Trim();
                TEXTB_addMiddleName.Text = employeeListDataGridView.Rows[0].Cells[3].Value.ToString().Trim();
                TEXTB_addNickName.Text = employeeListDataGridView.Rows[0].Cells[4].Value.ToString().Trim();
                String StringBirthDate = employeeListDataGridView.Rows[0].Cells[5].Value.ToString().Trim();
                DateTime DT_BirthDate = Convert.ToDateTime(StringBirthDate);
                TEXTB_addDateOfBirth.Value = DT_BirthDate;
                TEXTB_addPlaceOfBirth.Text = employeeListDataGridView.Rows[0].Cells[6].Value.ToString().Trim();
                TEXTB_addPresentAddress.Text = employeeListDataGridView.Rows[0].Cells[7].Value.ToString().Trim();
                TEXTB_addContact.Text = employeeListDataGridView.Rows[0].Cells[8].Value.ToString().Trim();
                TEXTB_addCivilStatus.Text = employeeListDataGridView.Rows[0].Cells[9].Value.ToString().Trim();
                TEXTB_addMother.Text = employeeListDataGridView.Rows[0].Cells[10].Value.ToString().Trim();
                TEXTB_addFather.Text = employeeListDataGridView.Rows[0].Cells[11].Value.ToString().Trim();
                COMBOB_Company.Text = employeeListDataGridView.Rows[0].Cells[12].Value.ToString().Trim();
                COMBOB_Department.Text = employeeListDataGridView.Rows[0].Cells[13].Value.ToString().Trim();
                COMBOB_SubDepartment.Text = employeeListDataGridView.Rows[0].Cells[14].Value.ToString().Trim();
                TEXTB_Position.Text = employeeListDataGridView.Rows[0].Cells[15].Value.ToString().Trim();
                string StringDateHired = employeeListDataGridView.Rows[0].Cells[16].Value.ToString().Trim();
                DateTime DT_DateHired = Convert.ToDateTime(StringDateHired);
                TEXTB_addDateHired.Value = DT_DateHired;
                COMBOB_EmployeeStatus.Text = employeeListDataGridView.Rows[0].Cells[17].Value.ToString().Trim();
                string StringDateSeparated = employeeListDataGridView.Rows[0].Cells[18].Value.ToString().Trim();
                if (StringDateSeparated != string.Empty)
                {
                    LBL_DateSeparated.Visible = true;
                    TEXTB_DateSeparated.Visible = true;
                    DateTime DT_DateSeparated = Convert.ToDateTime(StringDateSeparated);
                    TEXTB_DateSeparated.Value = DT_DateSeparated;
                }
                else
                {
                    LBL_DateSeparated.Visible = false;
                    TEXTB_DateSeparated.Visible = false;
                }
                TEXTB_addSalary.Text = employeeListDataGridView.Rows[0].Cells[19].Value.ToString().Trim();
                COMBOB_SalaryType.Text = employeeListDataGridView.Rows[0].Cells[20].Value.ToString().Trim();
                TEXTB_addTinNumber.Text = employeeListDataGridView.Rows[0].Cells[21].Value.ToString().Trim();
                TEXTB_addSssNumber.Text = employeeListDataGridView.Rows[0].Cells[22].Value.ToString().Trim();
                TEXTB_addPhilhealthNumber.Text = employeeListDataGridView.Rows[0].Cells[23].Value.ToString().Trim();
                TEXTB_addPagibigNumber.Text = employeeListDataGridView.Rows[0].Cells[24].Value.ToString().Trim();
                string StringPathPicture = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                string StringPicturePath = StringPathPicture + LBL_EmployeeNumber.Text + ".jpg";
                PICB_addPicture.ImageLocation = StringPicturePath;
                LBL_PicturePath.Text = StringPicturePath;
                LBL_PicturePathNew.Text = StringPicturePath;
            }
            else
            {
                PNL_EmploymentDetails.Enabled = false;
                PNL_EmployeeDetails.Enabled = false;
                LBL_DateSeparated.Visible = false;
                TEXTB_DateSeparated.Visible = false;
                MessageBox.Show("Cannot find EMPLOYEE: " + TEXTB_SearchEmployeeNumber.Text + " in the Database.","ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void COMBOB_EmployeeStatus_SelectedValueChanged(object sender, EventArgs e)
        {
            if (COMBOB_EmployeeStatus.Text == "SEPARATED")
            {
                LBL_DateSeparated.Visible = true;
                TEXTB_DateSeparated.Visible = true;
            }
            else
            {
                LBL_DateSeparated.Visible = true;
                TEXTB_DateSeparated.Visible = true;
            }
        }

        private void BTN_addPicturePath_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFilePath = new OpenFileDialog())
            {
                openFilePath.InitialDirectory = "c:\\";
                openFilePath.Filter = "jpg files (*.jpg)|*.jpg";
                openFilePath.FilterIndex = 2;
                openFilePath.RestoreDirectory = true;
                if (openFilePath.ShowDialog() == DialogResult.OK)
                {
                    LBL_PicturePathNew.Text = openFilePath.FileName;
                    PICB_addPicture.ImageLocation = LBL_PicturePathNew.Text;
                    PICB_addPicture.SizeMode = PictureBoxSizeMode.StretchImage;
                }
                else
                {
                    LBL_PicturePathNew.Text = LBL_PicturePath.Text;
                }
            }
        }

        private void BTN_Save_Click(object sender, EventArgs e)
        {
            string AddEmployeeNumber = LBL_EmployeeNumber.Text.ToUpper();
            string AddLastName = TEXTB_addSurname.Text.ToUpper();
            string AddFirstName = TEXTB_addGivenName.Text.ToUpper();
            string AddMiddleName = TEXTB_addMiddleName.Text.ToUpper();
            string AddNickName = TEXTB_addNickName.Text.ToUpper();
            DateTime BirthDate = TEXTB_addDateOfBirth.Value.Date;
            string AddBirthDate = BirthDate.ToString("MMM-dd-yyyy").ToUpper();
            string AddBirthPlace = TEXTB_addPlaceOfBirth.Text.ToUpper();
            string AddAddress = TEXTB_addPresentAddress.Text.ToUpper();
            string AddContactNumber = TEXTB_addContact.Text.ToUpper();
            string AddCivilStatus = TEXTB_addCivilStatus.Text.ToUpper();
            string AddMother = TEXTB_addMother.Text.ToUpper();
            string AddFather = TEXTB_addFather.Text.ToUpper();
            string AddCompany = COMBOB_Company.Text.ToUpper();
            string AddDepartment = COMBOB_Department.Text.ToUpper();
            string AddSubDepartment = COMBOB_SubDepartment.Text.ToUpper();
            string AddPosition = TEXTB_Position.Text.ToUpper();
            DateTime DateHired = TEXTB_addDateHired.Value.Date;
            string AddDateHired = DateHired.ToString("MMM-dd-yyyy");
            string AddEmploymentStatus = COMBOB_EmployeeStatus.Text.ToUpper();
            string AddDateSeparated;
            if (AddEmploymentStatus == "SEPARATED")
            {
                AddDateSeparated = TEXTB_DateSeparated.Text.ToString().ToUpper();
            }
            else
            {
                AddDateSeparated = "";
            }
            string AddSalary = TEXTB_addSalary.Text.ToUpper();
            string AddSalaryType = COMBOB_SalaryType.Text.ToUpper();
            string AddTin = TEXTB_addTinNumber.Text.ToUpper();
            string AddSss = TEXTB_addSssNumber.Text.ToUpper();
            string AddPhilhealth = TEXTB_addPhilhealthNumber.Text.ToUpper();
            string AddPagibig = TEXTB_addPagibigNumber.Text.ToUpper();
            if (AddLastName != "" || AddFirstName != "" || AddAddress != "")
            {
                //MessageBox.Show(AddBirthDate + "\n" + AddDateHired);
                EditEmployeeDetails.UpdateEmployee(AddEmployeeNumber, AddLastName, AddFirstName, AddMiddleName, AddNickName, AddBirthDate, AddBirthPlace, AddAddress, AddContactNumber, AddCivilStatus, AddMother, AddFather, AddCompany, AddDepartment, AddSubDepartment, AddPosition, AddDateHired, AddEmploymentStatus, AddDateSeparated, AddSalary, AddSalaryType, AddTin, AddSss, AddPhilhealth, AddPagibig, AddEmployeeNumber);
                if (LBL_PicturePathNew.Text != LBL_PicturePath.Text)
                {
                    string PicturePathFrom = LBL_PicturePathNew.Text;
                    string StringPathPicture = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                    string PicturePathSave = StringPathPicture + AddEmployeeNumber + ".jpg";
                    System.IO.File.Delete(PicturePathSave);
                    System.IO.File.Copy(PicturePathFrom, PicturePathSave);
                }
                else
                {
                    /*string PicturePathFrom = File.ReadAllText(@"C:\LEC 201\path.c", Encoding.UTF8) + "DEFAULTPHOTO.jpg";
                    string StringPathPicture = File.ReadAllText(@"C:\LEC 201\pathpics.c", Encoding.UTF8);
                    string PicturePathSave = StringPathPicture + AddEmployeeNumber + ".jpg";
                    System.IO.File.Move(PicturePathFrom, PicturePathSave);*/
                }
                MessageBox.Show("EMPLOYEE: " + AddEmployeeNumber + "\n\n" + AddLastName + ", " + AddFirstName + " " + AddMiddleName, "SAVE SUCCESSFUL!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                TEXTB_Position.Text = "";
                COMBOB_Company.Text = "";
                COMBOB_Department.Text = "";
                COMBOB_SubDepartment.Text = "";
                LBL_EmployeeNumber.Text = "0000-000-00";
                TEXTB_addSurname.Text = "";
                TEXTB_addGivenName.Text = "";
                TEXTB_addMiddleName.Text = "";
                TEXTB_addNickName.Text = "";
                TEXTB_addPresentAddress.Text = "";
                TEXTB_addContact.Text = "";
                TEXTB_addPlaceOfBirth.Text = "";
                TEXTB_addCivilStatus.Text = "";
                TEXTB_addMother.Text = "";
                TEXTB_addFather.Text = "";
                TEXTB_addTinNumber.Text = "";
                TEXTB_addSssNumber.Text = "";
                TEXTB_addPagibigNumber.Text = "";
                TEXTB_addPhilhealthNumber.Text = "";
                TEXTB_addSalary.Text = "";
                COMBOB_SalaryType.Text = "";
                COMBOB_EmployeeStatus.Text = "";
                LBL_PicturePath.Text = "";
                PICB_addPicture.Image = PICB_addPicture.InitialImage;
                PICB_addPicture.SizeMode = PictureBoxSizeMode.Zoom;
                PNL_EmploymentDetails.Enabled = true;
                PNL_EmployeeDetails.Enabled = false;
                Close();
            }
            else
            {
                MessageBox.Show("* Must not be empty", "Save Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void TEXTB_SearchEmployeeNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BTN_SearcEmployeeNumber.PerformClick();
            }
        }

        private void TEXTB_addSalary_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }

        private void BTN_Cancel_Click(object sender, EventArgs e)
        {
            TEXTB_addSurname.Text = "";
            TEXTB_addGivenName.Text = "";
            TEXTB_addMiddleName.Text = "";
            TEXTB_addNickName.Text = "";
            TEXTB_addPresentAddress.Text = "";
            TEXTB_addContact.Text = "";
            TEXTB_addPlaceOfBirth.Text = "";
            TEXTB_addCivilStatus.Text = "";
            TEXTB_addMother.Text = "";
            TEXTB_addFather.Text = "";
            TEXTB_addTinNumber.Text = "";
            TEXTB_addSssNumber.Text = "";
            TEXTB_addPagibigNumber.Text = "";
            TEXTB_addPhilhealthNumber.Text = "";
            TEXTB_addSalary.Text = "";
            COMBOB_Company.Text = "";
            COMBOB_Department.Text = "";
            COMBOB_SubDepartment.Text = "";
            LBL_EmployeeNumber.Text = "0000-000-00";
            COMBOB_SalaryType.Text = "";
            COMBOB_EmployeeStatus.Text = "";
            TEXTB_SearchEmployeeNumber.Text = "Employee Number..";
            PNL_EmploymentDetails.Enabled = false;
            PNL_EmployeeDetails.Enabled = false;
            LBL_DateSeparated.Visible = false;
            TEXTB_DateSeparated.Visible = false;
            PICB_addPicture.Image = PICB_addPicture.InitialImage;
            PICB_addPicture.SizeMode = PictureBoxSizeMode.Zoom;
            //QUERY START
            string EmployeeNumberSearch = this.TEXTB_SearchEmployeeNumber.Text.Replace("'", "''");
            string queryByDepartment = "(EmployeeNumber LIKE '" + EmployeeNumberSearch + "')";
            StringBuilder joinQuery = new StringBuilder();
            joinQuery.Append(queryByDepartment);
            this.employeeListBindingSource.Filter = joinQuery.ToString();
            //QUERY END
        }
    }
}
