﻿namespace LECHIRING
{
    internal class Properties
    {
    }
}