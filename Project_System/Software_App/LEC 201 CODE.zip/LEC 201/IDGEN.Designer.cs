﻿namespace ID_GENERATOR
{
    partial class IDGEN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(IDGEN));
            this.COMBOB_HomeCompany = new System.Windows.Forms.ComboBox();
            this.BTN_HomeOk = new System.Windows.Forms.Button();
            this.BTN_HomeCancel = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.BTN_Open = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // COMBOB_HomeCompany
            // 
            this.COMBOB_HomeCompany.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.COMBOB_HomeCompany.FormattingEnabled = true;
            this.COMBOB_HomeCompany.Items.AddRange(new object[] {
            "LEC - Workers",
            "BAI - Workers",
            "LEC - Office",
            "BAI - Office"});
            this.COMBOB_HomeCompany.Location = new System.Drawing.Point(172, 50);
            this.COMBOB_HomeCompany.Name = "COMBOB_HomeCompany";
            this.COMBOB_HomeCompany.Size = new System.Drawing.Size(120, 21);
            this.COMBOB_HomeCompany.TabIndex = 0;
            // 
            // BTN_HomeOk
            // 
            this.BTN_HomeOk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeOk.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_HomeOk.Location = new System.Drawing.Point(172, 86);
            this.BTN_HomeOk.Name = "BTN_HomeOk";
            this.BTN_HomeOk.Size = new System.Drawing.Size(60, 23);
            this.BTN_HomeOk.TabIndex = 1;
            this.BTN_HomeOk.Text = "OK";
            this.BTN_HomeOk.UseVisualStyleBackColor = true;
            this.BTN_HomeOk.Click += new System.EventHandler(this.BTN_HomeOk_Click);
            // 
            // BTN_HomeCancel
            // 
            this.BTN_HomeCancel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_HomeCancel.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_HomeCancel.Location = new System.Drawing.Point(232, 86);
            this.BTN_HomeCancel.Name = "BTN_HomeCancel";
            this.BTN_HomeCancel.Size = new System.Drawing.Size(60, 23);
            this.BTN_HomeCancel.TabIndex = 2;
            this.BTN_HomeCancel.Text = "CLOSE";
            this.BTN_HomeCancel.UseVisualStyleBackColor = true;
            this.BTN_HomeCancel.Click += new System.EventHandler(this.BTN_HomeCancel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(34, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(132, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "CHOOSE COMPANY:";
            // 
            // BTN_Open
            // 
            this.BTN_Open.Cursor = System.Windows.Forms.Cursors.Hand;
            this.BTN_Open.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BTN_Open.Location = new System.Drawing.Point(37, 86);
            this.BTN_Open.Name = "BTN_Open";
            this.BTN_Open.Size = new System.Drawing.Size(105, 23);
            this.BTN_Open.TabIndex = 4;
            this.BTN_Open.Text = "OPEN ID FOLDER";
            this.BTN_Open.UseVisualStyleBackColor = true;
            this.BTN_Open.Click += new System.EventHandler(this.BTN_Open_Click);
            // 
            // IDGEN
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ClientSize = new System.Drawing.Size(350, 150);
            this.ControlBox = false;
            this.Controls.Add(this.BTN_Open);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.BTN_HomeCancel);
            this.Controls.Add(this.BTN_HomeOk);
            this.Controls.Add(this.COMBOB_HomeCompany);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.MaximizeBox = false;
            this.Name = "IDGEN";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ID GENERATOR | Home";
            this.Load += new System.EventHandler(this.Home_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Home_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox COMBOB_HomeCompany;
        private System.Windows.Forms.Button BTN_HomeOk;
        private System.Windows.Forms.Button BTN_HomeCancel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BTN_Open;
    }
}

